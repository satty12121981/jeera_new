<?php 
####################Activity Rsvp Table Model #################################
//Created by Shail
#########################################################################
namespace Activity\Model;
use Zend\Db\Sql\Select;
use Zend\Db\TableGateway\AbstractTableGateway;
use Zend\Db\Adapter\Adapter;
use Zend\Db\ResultSet\ResultSet;
class ActivityRsvpTable extends AbstractTableGateway
{
    protected $table = 'y2m_group_activity_rsvp'; 
	
    public function __construct(Adapter $adapter)
    {
        $this->adapter = $adapter;
        $this->resultSetPrototype = new ResultSet();
        $this->resultSetPrototype->setArrayObjectPrototype(new ActivityRsvp());
        $this->initialize();
    }
	
	#this will fetch all activity RSVP
    public function fetchAll($where=Null, $order=Null, $limit=Null, $offset=Null)
    {
     	$resultSet = $this->select(function (Select $select) use ($where, $order, $limit, $offset) {		 
			$select->join('y2m_group_activity', 'y2m_group_activity.group_activity_id = y2m_group_activity_rsvp.group_activity_rsvp_activity_id', array('*'));
			$select->join('y2m_user', 'y2m_user.user_id = y2m_group_activity_rsvp.group_activity_rsvp_user_id', array('user_id','user_given_name', 'user_first_name', 'user_middle_name', 'user_last_name', 'user_email'));				
			$select->join('y2m_photo', 'y2m_photo.photo_id = y2m_user.user_profile_photo_id', array('photo_name'),$select::JOIN_LEFT);	
			$select->join('y2m_group', 'y2m_group.group_id = y2m_group_activity.group_activity_group_id', array('group_title', 'group_seo_title'));		
			$select->join(array('p' => 'y2m_group'), 'p.group_id = y2m_group.group_parent_group_id', array('parent_group_id' => 'group_id', 'parent_group_title' => 'group_title', 'parent_group_seo_title' => 'group_seo_title'));			
			if($where){	$select->where($where); }
			if($order){ $select->order($order); }
			if($limit){ $select->limit($limit); }
			//if($offset){ $select->offset($offset);  }		
				//echo $select->getSqlString();exit;
		});	
		return $resultSet;
    }

	#this will fetch activity details based primary key. Group ActivityRsvp Id
   public function getActivityRsvp($group_activity_rsvp_id)
    {
        $group_activity_rsvp_id  = (int) $group_activity_rsvp_id;
        $rowset = $this->select(array('group_activity_rsvp_id' => $group_activity_rsvp_id));
        $row = $rowset->current();
        return $row;
    }
	
	#this will fetch activity details based primary key. Group ActivityRsvp Id
   public function getActivityRsvpOfUser($group_activity_rsvp_user_id, $group_activity_rsvp_activity_id)
    {
        $group_activity_rsvp_user_id  = (int) $group_activity_rsvp_user_id;
		$group_activity_rsvp_activity_id  = (int) $group_activity_rsvp_activity_id;
        $rowset = $this->select(array('group_activity_rsvp_user_id' => $group_activity_rsvp_user_id, 'group_activity_rsvp_activity_id' => $group_activity_rsvp_activity_id));
        $row = $rowset->current();
        return $row;
    } 

	// this function will save activity in database
    public function saveActivityRsvp(ActivityRsvp $activityRsvp)
    {        
	   $data = array(
            'group_activity_rsvp_user_id' => $activityRsvp->group_activity_rsvp_user_id,
            'group_activity_rsvp_activity_id'  => $activityRsvp->group_activity_rsvp_activity_id,
			'group_activity_rsvp_added_timestamp'  => $activityRsvp->group_activity_rsvp_added_timestamp,			
			'group_activity_rsvp_added_ip_address'  => $activityRsvp->group_activity_rsvp_added_ip_address,
			'group_activity_rsvp_group_id'  => $activityRsvp->group_activity_rsvp_group_id		
        );
		 
        $group_activity_rsvp_id = (int)$activityRsvp->group_activity_rsvp_id;
        if ($group_activity_rsvp_id == 0) {
            $this->insert($data);
			return $this->adapter->getDriver()->getConnection()->getLastGeneratedValue();
        } else {
            if ($this->getActivityRsvp($group_activity_rsvp_id)) {
                $this->update($data, array('group_activity_rsvp_id' => $group_activity_rsvp_id));
            } else {
                throw new \Exception('Form id does not exist');
            }
        }
    }

	#this function will delete activity in database
    public function deleteActivityRsvp($group_activity_rsvp_id)
    {
        $this->delete(array('group_activity_rsvp_id' => $group_activity_rsvp_id));
    }
	public function removeActivityRsvp($activity_id,$user_id){
		return $this->delete(array('group_activity_rsvp_activity_id' => $activity_id,'group_activity_rsvp_user_id'=>$user_id));
	}
}