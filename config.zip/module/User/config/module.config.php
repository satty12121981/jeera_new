<?php
return array(
    'controllers' => array(
        'invokables' => array(
            'User\Controller\User' => 'User\Controller\UserController',
			'Groups\Controller\Groups' => 'Groups\Controller\GroupsController',
			'Country\Controller\Country' => 'Country\Controller\CountryController',		
			'User\Controller\UserProfile' => 'User\Controller\UserProfileController',	
			'Calender\Controller\Calender' => 'Calender\Controller\CalenderController',	
			'Activity\Controller\Calender' => 'Activity\Controller\CalenderController',	
			'Photo\Controller\Photo' => 'Photo\Controller\PhotoController',	
			'Tag\Controller\Tag' => 'Tag\Controller\TagController',	
			'User\Auth\BcryptDbAdapter'=>'User\Auth\BcryptDbAdapter',
			),
    ),

    // The following section is new and should be added to your file
    'router' => array(
        'routes' => array(
            'user' => array(
                'type' => 'Literal',
                'priority' => 1000,
                'options' => array(
                    'route' => '/user',
                    'defaults' => array(
						'__NAMESPACE__' => 'User\Controller',
                        'controller' => 'user',
                        'action'     => 'index',
                    ),
                ),
                'may_terminate' => true,
                'child_routes' => array(
                    'login' => array(
                        'type' => 'Literal',
                        'options' => array(
                            'route' => '/login',
                            'defaults' => array(
								'__NAMESPACE__' => 'User\Controller',
                                'controller' => 'user',
                                'action'     => 'login',
                            ),
                        ),
                    ),    
					'ajax_login' => array(
                        'type' => 'Literal',
                        'options' => array(
                            'route' => '/ajaxlogin',
                            'defaults' => array(
								'__NAMESPACE__' => 'User\Controller',
                                'controller' => 'user',
                                'action'     => 'ajaxlogin',
                            ),
                        ),
                    ),
                    'logout' => array(
                        'type' => 'Literal',
                        'options' => array(
                            'route' => '/logout',
                            'defaults' => array(
                                'controller' => 'user',
                                'action'     => 'logout',
                            ),
                        ),
                    ),
					'forgotPassword' => array(
                        'type' => 'Literal',
                        'options' => array(
                            'route' => '/forgotPassword',
                            'defaults' => array(
                                'controller' => 'user',
                                'action'     => 'forgotPassword',
                            ),
                        ),
                    ),
					'varifyemail' => array(
                        'type' => 'Segment',
                        'options' => array(
                            'route' => '/varifyemail[/:key][/:id]',
                            'defaults' => array(
                                'controller' => 'user',
                                'action'     => 'varifyemail',
                            ),
                        ),
                    ),
					'resetpassword' => array(
                        'type' => 'Segment',
                        'options' => array(
                            'route' => '/resetpassword[/:key][/:id]',
                            'defaults' => array(
                                'controller' => 'user',
                                'action'     => 'resetpassword',
                            ),
                        ),
                    ),
					'resendverification' => array(
                        'type' => 'Segment',
                        'options' => array(
                            'route' => '/resendverification',
                            'defaults' => array(
                                'controller' => 'user',
                                'action'     => 'resendverification',
                            ),
                        ),
                    ),
                    'register' => array(
                        'type' => 'Literal',
                        'options' => array(
                            'route' => '/register',
                            'defaults' => array(
                                'controller' => 'user',
                                'action'     => 'register',
                            ),
                        ),
                    ),
                    'changepassword' => array(
                        'type' => 'Literal',
                        'options' => array(
                            'route' => '/change-password',
                            'defaults' => array(
                                'controller' => 'user',
                                'action'     => 'changepassword',
                            ),
                        ),                        
                    ),
					'ajaxgettag' => array(
                        'type' => 'Literal',
                        'options' => array(
                            'route' => '/ajaxgettag',
                            'defaults' => array(
                                'controller' => 'user',
                                'action'     => 'ajaxgettag',
                            ),
                        ),                        
                    ),
					'tagsearch' => array(
                        'type' => 'Literal',
                        'options' => array(
                            'route' => '/tagsearch',
                            'defaults' => array(
                                'controller' => 'user',
                                'action'     => 'tagsearch',
                            ),
                        ),                        
                    ),
                    'changeemail' => array(
                        'type' => 'Literal',
                        'options' => array(
                            'route' => '/change-email',
                            'defaults' => array(
                                'controller' => 'user',
                                'action' => 'changeemail',
                            ),
                        ),                        
                    ),
                ),
            ),
			//userProfileRoutes
			
            'profile' => array(
                'type' => 'Literal',
                'priority' => 1000,
                'options' => array(
                    'route' => '/profile',
                    'defaults' => array(
						'__NAMESPACE__' => 'User\Controller',
                        'controller' => 'userProfile',
                        'action'     => 'index',
                    ),
                ),
                'may_terminate' => true,
                'child_routes' => array(
                    'load' => array(
                        'type' => 'Literal',
                        'options' => array(
                            'route' => '/load',
                            'defaults' => array(
								'__NAMESPACE__' => 'User\Controller',
                                'controller' => 'userprofile',
                                'action'     => 'load',
                            ),
                        ),
                    ), 
					'user' => array(
                        'type' => 'Literal',
                        'options' => array(
                            'route' => '/user',
                            'defaults' => array(
								'__NAMESPACE__' => 'User\Controller',
                                'controller' => 'userprofile',
                                'action'     => 'user',
                            ),
                        ),
						'may_terminate' => true,
							'child_routes' => array(
								'load' => array(
									'type' => 'segment',
									'options' => array(
										'route' => '/[:user_url_identifier]',
											'constraints' => array(
												'user_url_identifier' => '[a-zA-Z0-9_-]*',												 
											),
										'defaults' => array(
											'controller' => 'userprofile',
											'action'     => 'user',
										),
									),
								),
							),
                    ),                    
                    'cal' => array(
                        'type' => 'Literal',
                        'options' => array(
                            'route' => '/cal',
                            'defaults' => array(
                                'controller' => 'userprofile',
                                'action'     => 'cal',
                            ),
                        ),
						
						'may_terminate' => true,
							'child_routes' => array(
								'load' => array(
									'type' => 'segment',
									'options' => array(
										'route' => '/[:month_id]/[:year_id]',
											'constraints' => array(
												'month_id' => '[0-9]+',
												'year_id' => '[0-9]+'
											),
										'defaults' => array(
											'controller' => 'userprofile',
											'action'     => 'cal',
										),
									),
								),
							),		   
				   		),
					
                    'register' => array(
                        'type' => 'Literal',
                        'options' => array(
                            'route' => '/register',
                            'defaults' => array(
                                'controller' => 'UserProfile',
                                'action'     => 'register',
                            ),
                        ),
                    ),					 
                    'changepassword' => array(
                        'type' => 'Literal',
                        'options' => array(
                            'route' => '/change-password',
                            'defaults' => array(
                                'controller' => 'UserProfile',
                                'action'     => 'changepassword',
                            ),
                        ),                        
                    ),
                    'changeemail' => array(
                        'type' => 'Literal',
                        'options' => array(
                            'route' => '/change-email',
                            'defaults' => array(
                                'controller' => 'UserProfile',
                                'action' => 'changeemail',
                            ),
                        ),                        
                    ),
                ),
            ),
			
        ),
    ),

    'view_manager' => array(
        'template_path_stack' => array(
            'user' => __DIR__ . '/../view',
        ),
    ),
);

