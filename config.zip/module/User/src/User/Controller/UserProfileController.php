<?php 
#namespance Define
namespace User\Controller;
use Zend\View\Helper\HeadScript;
use \Exception;
#zend Library
use Zend\Mvc\Controller\AbstractActionController;
use Zend\View\Model\ViewModel;
use Zend\View\Renderer\PhpRenderer;	//using set template
#session
use Zend\Session\Container; // We need this when using sessions     
use Zend\Authentication\AuthenticationService;
use Zend\Authentication\Adapter\DbTable as AuthAdapter; 

#Custom classes
use Calender\Controller\Calender;
use Calender\Model\CalenderTable; #calender
use User\Model\User;
use User\Model\UserProfile;
use Tag\Model\UserTagTable; #calender
use Group\Model\UserGroup;
use Activity\Model\Activity; 

class UserProfileController extends AbstractActionController
{
    protected $userTable;
	protected $userProfileTable;
	protected $groupTable;
	protected $userGroupTable;
	protected $userTagTable;
	protected $countryTable;
	protected $activityTable;	
	protected $photoTable;	
	protected $headScript;	#javascript addition object
	
	#routing contact
	const PROFILE_PATH     = 'datagd/profile';  
	const TIMELINE_PATH     = 'datagd/timeline';  
    //<?php echo Application\Model\Application::TIMELINE_PATH;    
	
	#this function will load the css and javascript need for perticular action
	protected function getViewHelper($helperName)
	{
    	return $this->getServiceLocator()->get('viewhelpermanager')->get($helperName);
	} 
   
    public function indexAction()
    {	
		
		#loading the configration
		$sm = $this->getServiceLocator(); 
		$basePath = $sm->get('Request')->getBasePath();	#get the base path
		
		$this->getViewHelper('HeadScript')->appendFile($basePath.'/js/jquery.min.js','text/javascript');
		$this->getViewHelper('HeadScript')->appendFile($basePath.'/js/1625.js','text/javascript');
		
		$auth = new AuthenticationService();
		$userGroupWidget =array();	
		$identity = null;        
		if ($auth->hasIdentity()) {
            // Identity exists; get it
           	$identity = $auth->getIdentity();
			
			$userData =array();	///this will hold data from y2m_user table
			$userProfileData =array();//this will hold data of profile table
			$userTimelinePhotoData =array();//this will hold the timeline photo
			$userProfilePhotoData =array();//this will hold the profile photo
			#check the identity againts the DB
			$userData = $this->getUserTable()->getUser($identity->user_id);	
			$userAge =0;
			$userTag =array();	
			$userGroups =array();	
			//echo "<pre>";print_r($userData);exit;	
			if(isset($userData->user_id) && !empty($userData->user_id)){				
				#fetch the user pic
				if(isset($userData->user_id) && !empty($userData->user_id) && trim($userData->user_id)!='0'){
					#fetch user profile data
					$userProfileData = $this->getUserProfileTable()->getUserProfileForUserId($userData->user_id);
					$userObj =new User();
					$userAge =$userObj->calculateUserAge($userProfileData->user_profile_dob);	
					 
					#fetch user timeline photo
					if(isset($userData->user_timeline_photo_id) && !empty($userData->user_timeline_photo_id) && trim($userData->user_timeline_photo_id)!='0'){
						$userTimelinePhotoData = $this->getPhotoTable()->getPhoto($userData->user_timeline_photo_id);						
					} //if(isset($userData->user_timeline_photo_id) && !empty($userData->user_timeline_photo_id) && trim($userData->user_timeline_photo_id)!='0')
					
					#fetch user profile photo
					if(isset($userData->user_profile_photo_id) && !empty($userData->user_profile_photo_id) && trim($userData->user_profile_photo_id)!='0'){
						$userProfilePhotoData = $this->getPhotoTable()->getPhoto($userData->user_profile_photo_id);	
					} //if(isset($userData->user_timeline_photo_id) && !empty($userData->user_timeline_photo_id) && trim($userData->user_timeline_photo_id)!='0')
					
					#fetch all user tags
					$userTag =	$this->getUserTagTable()->fetchAllTagsOfUser($userData->user_id);	
					
					#call the user group Widget
					$userGroupWidget = $this->forward()->dispatch('Group\Controller\UserGroup', array('action' => 'index'));					
				} //if(isset($userData->user_id) && !empty($userData->user_id) && trim($userData->user_id)!='0')				
				//echo "<pre>";print_r($userProfileData);exit;			
			}//if($userData->user_id)	 
			
        } 
		$this->layout()->identity = $identity;	//assign Identity to layout 	 
		$viewModel = new ViewModel(array('users' => $userData,'userData' => $userData,'userProfileData' => $userProfileData,'userTimelinePhotoData' => $userTimelinePhotoData,'userProfilePhotoData' => $userProfilePhotoData,'userAge' => $userAge, 'userTag' => $userTag, 'userGroups' => $userGroups));
    	$viewModel->addChild($userGroupWidget, 'userGroupWidget');		 
    	return $viewModel;	
	}
	
	#this function will load subgroups for the user as suggestion on his home page
	public function loadAction()
    {		
		$suggestSubGroup =array();
		try {	
			$auth = new AuthenticationService();	
			$identity = null;        
			if ($auth->hasIdentity()) {
            	// Identity exists; get it
           		$identity = $auth->getIdentity();			
				 #check the identity againts the DB
				$userData = $this->getUserTable()->getUser($identity->user_id);					
				if(isset($userData->user_id) && !empty($userData->user_id)){					 
					#fetch the user Galaxy
					$suggestSubGroup = $this->getUserGroupTable()->fetchAllSubGroupUserNotRegisterInGroup($userData->user_id);				 
				} //if(isset($userData->user_id) && !empty($userData->user_id))   
	    	} //if ($auth->hasIdentity()) 		
		} catch (\Exception $e) {
         	#DOO  OUR LOGGED ERROR FUNCTION
			 
   		}	
		$viewModel = new ViewModel(array('suggestSubGroup' => $suggestSubGroup));
    	$viewModel->setTerminal(true);
    	return $viewModel;	
    
			
	}
	
	
	 public function userAction()
    {
		$auth = new AuthenticationService();	
		$identity = null;        
		if ($auth->hasIdentity()) {
            // Identity exists; get it
           	$identity = $auth->getIdentity();
			
			$userData =array();	///this will hold data from y2m_user table
			$userProfileData =array();//this will hold data of profile table
			$userTimelinePhotoData =array();//this will hold the timeline photo
			$userProfilePhotoData =array();//this will hold the profile photo
			#check the identity againts the DB
			$userData = $this->getUserTable()->getUser($identity->user_id);	
			$userAge =0;
			$userTag =array();	
			$userGroups =array();	
			//echo "<pre>";print_r($userData);exit;	
			if(isset($userData->user_id) && !empty($userData->user_id)){				
				#fetch the user pic
				if(isset($userData->user_id) && !empty($userData->user_id) && trim($userData->user_id)!='0'){
					#fetch user profile data
					$userProfileData = $this->getUserProfileTable()->getUserProfileForUserId($userData->user_id);
					$userObj =new User();
					$userAge =$userObj->calculateUserAge($userProfileData->user_profile_dob);	
					 
					#fetch user timeline photo
					if(isset($userData->user_timeline_photo_id) && !empty($userData->user_timeline_photo_id) && trim($userData->user_timeline_photo_id)!='0'){
						$userTimelinePhotoData = $this->getPhotoTable()->getPhoto($userData->user_timeline_photo_id);	
						//echo "<pre>";print_r($userTimelinePhotoData); 
					} //if(isset($userData->user_timeline_photo_id) && !empty($userData->user_timeline_photo_id) && trim($userData->user_timeline_photo_id)!='0')
					
					#fetch user profile photo
					if(isset($userData->user_profile_photo_id) && !empty($userData->user_profile_photo_id) && trim($userData->user_profile_photo_id)!='0'){
						$userProfilePhotoData = $this->getPhotoTable()->getPhoto($userData->user_profile_photo_id);	
						//echo "<pre>";print_r($userProfilePhotoData); 
					} //if(isset($userData->user_timeline_photo_id) && !empty($userData->user_timeline_photo_id) && trim($userData->user_timeline_photo_id)!='0')
					
					#fetch all user tags
					$userTag =	$this->getUserTagTable()->fetchAllTagsOfUser($userData->user_id);	
					
					#fetch all groups of users
					$userGroups = $this->getUserGroupTable()->fetchAllUserGroup($userData->user_id);					
					 
										
				
				} //if(isset($userData->user_id) && !empty($userData->user_id) && trim($userData->user_id)!='0')				
				//echo "<pre>";print_r($userProfileData);exit;			
			}//if($userData->user_id)	 
			
        } 
		$this->layout()->identity = $identity;	//assign Identity to layout   		  
		
		 
		
		return new ViewModel(array(
            'users' => $userData,'userData' => $userData,'userProfileData' => $userProfileData,'userTimelinePhotoData' => $userTimelinePhotoData,'userProfilePhotoData' => $userProfilePhotoData,'userAge' => $userAge, 'userTag' => $userTag, 'userGroups' => $userGroups, 
        ));
    }
	 
	
	 
 public function calAction(){ 		 
		 $month_id= $this->params('month_id');
		 $month_id= $this->params('year_id');
		 
		 #fetch the user Galaxy
			$suggestSubGroup =array();		
			$suggestSubGroup = $this->getUserGroupTable()->fetchAllSubGroupUserNotRegisterInGroup();
			
			#call the calender module in zend
			//$calender = new CalenderTable();
			$monthNames = Array("January", "February", "March", "April", "May", "June", "July","August", "September", "October", "November", "December");
			if (!isset($_REQUEST["month"])) $_REQUEST["month"] = date("n");
			if (!isset($_REQUEST["year"])) $_REQUEST["year"] = date("Y");
			
			$cMonth = $_REQUEST["month"];
			$cYear = $_REQUEST["year"];
			
			$prev_year = $cYear;
			$next_year = $cYear;
			$prev_month = $cMonth-1;
			$next_month = $cMonth+1;
			 
			if ($prev_month == 0 ) {
				$prev_month = 12;
				$prev_year = $cYear - 1;
			}
			if ($next_month == 13 ) {
				$next_month = 1;
				$next_year = $cYear + 1;
			}
			
			
			$allUpcommingActivity =array();		
			$allUpcommingActivity = $this->getActivityTable()->getUserJoinedActivityForCalender($cYear, $cMonth,28);
			
			$result = new ViewModel();
			$result->setTerminal(true);
			$result->setVariables(array('suggestSubGroup' => $suggestSubGroup, 'allUpcommingActivity' => $allUpcommingActivity, 'cMonth' => $cMonth, 'cYear' => $cYear,'prev_year' => $prev_year, 'next_year' => $next_year,'prev_month' => $prev_month, 'next_month' => $next_month, 'monthNames' => $monthNames));
			return $result;
		 
		 
		 
 	
 }

  

	#access User Module 
    public function getUserTable()
    {
        if (!$this->userTable) {
            $sm = $this->getServiceLocator();
            $this->userTable = $sm->get('User\Model\UserTable');
        }
        return $this->userTable;
    } 
	
	#access User Profile Module
    public function getUserProfileTable()
    {
        if (!$this->userProfileTable) {
            $sm = $this->getServiceLocator();
            $this->userProfileTable = $sm->get('User\Model\UserProfileTable');
        }
        return $this->userProfileTable;
    } 
	
	#access Galaxy/Planet Table Module
	 public function getGroupTable()
    {
        if (!$this->groupTable) {
            $sm = $this->getServiceLocator();
			$this->groupTable = $sm->get('Group\Model\GroupTable');
        }
        return $this->groupTable;
    } 
	
	#access User Galaxy/Planet Module
	 public function getUserGroupTable()
    {
        if (!$this->userGroupTable) {
            $sm = $this->getServiceLocator();
			$this->userGroupTable = $sm->get('Group\Model\UserGroupTable');
        }
        return $this->userGroupTable;
    } 
	#accessing the country table module
	 public function getCountryTable()
    {
        if (!$this->countryTable) {
            $sm = $this->getServiceLocator();
            $this->countryTable = $sm->get('Country\Model\CountryTable');
        }
        return $this->countryTable;
    }  
	
	#access Activity Table Module
	 public function getActivityTable()
    {
        if (!$this->activityTable) {
            $sm = $this->getServiceLocator();
            $this->activityTable = $sm->get('Activity\Model\ActivityTable');
        }
        return $this->activityTable;
    } 
	
	#access Photo Module Model
	 public function getPhotoTable()
    {
        if (!$this->photoTable) {
            $sm = $this->getServiceLocator();
            $this->photoTable = $sm->get('Photo\Model\PhotoTable');
        }
        return $this->photoTable;
    } 
	
	#access User Tag Module Model
	 public function getUserTagTable()
    {
        if (!$this->userTagTable) {
            $sm = $this->getServiceLocator();
            $this->userTagTable = $sm->get('Tag\Model\UserTagTable');
        }
        return $this->userTagTable;
    } 
	
	
}
