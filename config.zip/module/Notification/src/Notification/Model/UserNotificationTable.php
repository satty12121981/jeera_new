<?php
namespace Notification\Model;
use Zend\Db\Sql\Select;
use Zend\Db\TableGateway\AbstractTableGateway;
use Zend\Db\Adapter\Adapter;
use Zend\Db\ResultSet\ResultSet;

class UserNotificationTable extends AbstractTableGateway
{
    protected $table = 'y2m_user_notification'; 

    public function __construct(Adapter $adapter)
    {
        $this->adapter = $adapter;
        $this->resultSetPrototype = new ResultSet();
        $this->resultSetPrototype->setArrayObjectPrototype(new UserNotification());
        $this->initialize();
    }
	
    public function fetchAll()
    {
       $resultSet = $this->select();
       return $resultSet;
    }

    public function getUserNotification($user_notification_id)
    {
        $user_notification_id  = (int) $user_notification_id;
        $rowset = $this->select(array('user_notification_id' => $user_notification_id));
        $row = $rowset->current();
        return $row;
    }
	
	public function getUserNotificationForUser($user_notification_user_id)
    {
        $user_notification_user_id  = (int) $user_notification_user_id;
	
		$resultSet = $this->select(function (Select $select) use ($user_notification_user_id) {
			$select->where(array('user_notification_user_id'=>$user_notification_user_id));
			$select->order('user_notification_added_timestamp DESC');
		});		
		
        return $resultSet;
    }
	
	public function getUserNotificationCountForUserUnread($user_notification_user_id)
    {
        $user_notification_user_id  = (int) $user_notification_user_id;
		$select = new Select;
		$select->columns(array('num' => new \Zend\Db\Sql\Expression('COUNT(*)')))
					->from('y2m_user_notification')
					->where(array('user_notification_user_id'=>$user_notification_user_id,'user_notification_status' => 1))
					->order('user_notification_added_timestamp DESC');
		
		$statement = $this->adapter->createStatement();
		$select->prepareStatement($this->adapter, $statement);
		$resultSet = new ResultSet();
		$resultSet->initialize($statement->execute());	
		$row = $resultSet->current();
		return $row['num'];
    }  	

    public function saveUserNotification(UserNotification $notification)
    {	   
		$data = array(
            'user_notification_user_id' => $notification->user_notification_user_id,
            'user_notification_content'  => $notification->user_notification_content,
			'user_notification_added_timestamp'  => $notification->user_notification_added_timestamp,
			'user_notification_status'  => $notification->user_notification_status,
			'user_notification_notification_type_id'  => $notification->user_notification_notification_type_id 
        );

        $user_notification_id = (int)$notification->user_notification_id;
        if ($user_notification_id == 0) {
            $this->insert($data);
			return $this->adapter->getDriver()->getConnection()->getLastGeneratedValue();
        } else {
            if ($this->getUserNotification($user_notification_id)) {
                $this->update($data, array('user_notification_id' => $user_notification_id));
            } else {
                throw new \Exception('Form id does not exist');
            }
        }
    }
	
	public function saveUserNotificationStatus(UserNotification $notification)
    {	   
		$data = array(
			'user_notification_status'  => $notification->user_notification_status
        );
 
		if ($this->getUserNotificationForUser($notification->user_notification_user_id)) {
			$this->update($data, array('user_notification_user_id' => $notification->user_notification_user_id));
		} else {
			throw new \Exception('Form id does not exist');
		}
        
    }

    public function deleteUserNotification($user_notification_id)
    {
        $this->delete(array('user_notification_id' => $user_notification_id));
    }
	
}