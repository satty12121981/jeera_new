<?php
return array(
    'controllers' => array(
        'invokables' => array(
            'Groups\Controller\Groups' => 'Groups\Controller\GroupsController',
        ),
    ),
	 // The following section is new and should be added to your file
    'router' => array(
        'routes' => array(
            'groups' => array(
                'type'    => 'Literal',
                'options' => array(
                    'route'    => '/groups',
                   'defaults' => array(
						'__NAMESPACE__' => 'Groups\Controller',
                        'controller' => 'groups',
                        'action'     => 'index',
                    ),
                ),
				'may_terminate' => true,
				'child_routes' => array(
					'planet' => array(
									'type' => 'segment',
									'options' => array(
										'route' => '/[:group_id]',										
											'constraints' => array(
												'group_id' => '[a-zA-Z0-9_-]*',										 
											),
										'defaults' => array(
											'__NAMESPACE__' => 'Groups\Controller',
											'controller' => 'groups',
											'action'     => 'planet',
										),
									),
								),
					'planethome' => array(
									'type' => 'segment',
									'options' => array(
										'route' => '/[:group_id]/[:planet_id]',										
											'constraints' => array(
												'group_id' => '[a-zA-Z0-9_-]*',
												'planet_id' => '[a-zA-Z0-9_-]*',												
											),
										'defaults' => array(
											'__NAMESPACE__' => 'Groups\Controller',
											'controller' => 'groups',
											'action'     => 'planethome',
										),
									),
								),
					'join' => array(
									'type' => 'segment',
									'options' => array(
										'route' => '/join/[:gid]',										
											'constraints' => array(
												'gid' => '[a-zA-Z0-9_-]*',																	
											),
										'defaults' => array(
											'__NAMESPACE__' => 'Groups\Controller',
											'controller' => 'groups',
											'action'     => 'join',
										),
									),
								),
					'group-discussion' => array(
									'type' => 'segment',
									'options' => array(
										'route' => '/[:group_id]/[:sub_group_id]/discussion',										
											'constraints' => array(
												'group_id' => '[a-zA-Z0-9_-]*',	
												'sub_group_id' => '[a-zA-Z0-9_-]*',										 
											),
										'defaults' => array(
											'__NAMESPACE__' => 'Discussion\Controller',
											'controller' => 'discussion',
											'action'     => 'index',
										),
									),
								),
					'group-members' => array(
                        'type' => 'segment',
                        'options' => array(
                            'route' => '/[:group_id]/[:sub_group_id]/members',
                            'constraints' => array(
                                'group_id' => '[a-zA-Z0-9_-]*',
                                'sub_group_id' => '[a-zA-Z0-9_-]*',
                            ),
                            'defaults' => array(
                                '__NAMESPACE__' => 'Groups\Controller',
                                'controller' => 'groups',
                                'action'     => 'loadPlanetMembers',
                            ),
                        ),
                    ),
								
				),
            ),
        ),
    ),

    'view_manager' => array(
        'template_path_stack' => array(
            'groups' => __DIR__ . '/../view',
        ),
    ),
);