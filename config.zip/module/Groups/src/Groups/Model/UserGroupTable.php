<?php 
namespace Groups\Model;
use Zend\Db\Sql\Select;
use Zend\Db\TableGateway\AbstractTableGateway;
use Zend\Db\Adapter\Adapter;
use Zend\Db\ResultSet\ResultSet;
use Zend\Db\Sql\Sql;
use Zend\Db\Sql\Where;

class UserGroupTable extends AbstractTableGateway
{
    protected $table = 'y2m_user_group';  
    public function __construct(Adapter $adapter)
    {
        $this->adapter = $adapter;
        $this->resultSetPrototype = new ResultSet();
        $this->resultSetPrototype->setArrayObjectPrototype(new UserGroup());
        $this->initialize();
    }

    public function fetchAll()
    {
        $resultSet = $this->select();
        return $resultSet;
    }
	
	#this will check user is registered for which group
	 public function getUserGroup($user_id, $group_id)
    {      	 
		$user_id  = (int) $user_id;
		$group_id  = (int) $group_id; 
        $rowset = $this->select(array('user_group_user_id' => $user_id,'user_group_group_id' => $group_id ));
        $row = $rowset->current();		 
        return $row;
    }
		
	#fetch the groups for which user is registered
	 public function fetchAllUserGroup($user_id)
    {	   
	  	$select = new Select;
		$select->from('y2m_user_group')
    		->join('y2m_group', 'y2m_group.group_id = y2m_user_group.user_group_group_id', array('*'))
			->join('y2m_user', 'y2m_user.user_id = y2m_user_group.user_group_user_id', array('*'))
			->where(array('y2m_group.group_parent_group_id' => "0", 'y2m_user_group.user_group_user_id' => "$user_id")); 
		$statement = $this->adapter->createStatement();
		$select->prepareStatement($this->adapter, $statement);
		$resultSet = new ResultSet();
		$resultSet->initialize($statement->execute());	  
	  	return $resultSet;
	 
    }
	
	#fetch the user list for a group
	 public function fetchAllUserListForGroup($group_id)
    {	   
		$select = new Select;
		$select->from('y2m_user_group')
    		->join('y2m_group', 'y2m_group.group_id = y2m_user_group.user_group_group_id', array('*'))
			->join('y2m_user', 'y2m_user.user_id = y2m_user_group.user_group_user_id', array('*'))
			->join('y2m_photo', 'y2m_photo.photo_id = y2m_user.user_profile_photo_id', array('*'),'left')
			->where(array('y2m_user_group.user_group_group_id' => $group_id));
		$statement = $this->adapter->createStatement();
		$select->prepareStatement($this->adapter, $statement);
		//echo $select->getSqlString();exit;
		$resultSet = new ResultSet();
		$resultSet->initialize($statement->execute());	  
	  	return $resultSet; 
    }
	
	#This function will fetch all galaxy and planets for for a Group Id.Used in admin
	 public function fetchAllUserForGeneralGroup($group_id)
    {	   
	  	$select = new Select;
		$select->from('y2m_user_group')
    		->join('y2m_group', 'y2m_group.group_id = y2m_user_group.user_group_group_id', array('*'))
			->join('y2m_user', 'y2m_user.user_id = y2m_user_group.user_group_user_id', array('*'))
			->where(array('y2m_user_group.user_group_group_id' => "$group_id")); 
		$statement = $this->adapter->createStatement();
		$select->prepareStatement($this->adapter, $statement);
		$resultSet = new ResultSet();
		$resultSet->initialize($statement->execute());	  
	  	return $resultSet;	 
    }
	
	#fetch the planet for which user is registered
	 public function fetchAllUserSubGroup($user_id, $group_id)
    {	     
	  	$select = new Select;
	  	$predicate = new  \Zend\Db\Sql\Where();
		$select->from('y2m_user_group')
    		->join('y2m_group', 'y2m_group.group_id = y2m_user_group.user_group_group_id', array('*'))
			->join('y2m_user', 'y2m_user.user_id = y2m_user_group.user_group_user_id', array('*'))
			//->where(array($predicate->greaterThan('y2m_group.group_parent_group_id' , "0"), 'y2m_user_group.user_group_user_id' => "$user_id", 'y2m_user_group.user_group_group_id' => "$group_id"));		
			->where(array('y2m_user_group.user_group_user_id' => "$user_id", 'y2m_group.group_parent_group_id' => "$group_id"));			 	
		$statement = $this->adapter->createStatement();		 
		$select->prepareStatement($this->adapter, $statement);		
		$resultSet = new ResultSet();
		$resultSet->initialize($statement->execute());	  
	  	return $resultSet;	 
    }
	
	#fetch the owner user information of a group
	 public function findGroupOwner($group_id)
    {	     
	  	$select = new Select;
	  	$predicate = new  \Zend\Db\Sql\Where();
		$select->from('y2m_user_group')
    		->join('y2m_group', 'y2m_group.group_id = y2m_user_group.user_group_group_id', array('*'))
			->join('y2m_user', 'y2m_user.user_id = y2m_user_group.user_group_user_id', array('*'))
			//->where(array($predicate->greaterThan('y2m_group.group_parent_group_id' , "0"), 'y2m_user_group.user_group_user_id' => "$user_id", 'y2m_user_group.user_group_group_id' => "$group_id"));		
			->where(array('y2m_user_group.user_group_is_owner' => "1", 'y2m_user_group.user_group_group_id' => "$group_id"));		
		$statement = $this->adapter->createStatement();		 
		$select->prepareStatement($this->adapter, $statement);			 	
		$resultSet = new ResultSet();
		$resultSet->initialize($statement->execute());	  
	   	$row = $resultSet->current();
    	//echo "<pre>";print_R($row);exit;    
		return $row;
    }
	
	
	#fetch the planet for which user is registered
	 public function fetchAllSubGroupUserNotRegisterInGroup($user_id)
    {      
	  	
		$allUserGroups =array();		
		$allUserGroups = $this->fetchAllUserGroup($user_id);
		
		#load a Group randoly for that User has not register
		$userRegisterGroupsIds =array();	#it will hold the comma seperated value of users
		$groupString ="";
		
		if(isset($allUserGroups) && count($allUserGroups)){ 
			foreach ($allUserGroups as $userGroupRow) {
			 	array_push($userRegisterGroupsIds, $userGroupRow->group_id);			 
			}	 
			$groupString = implode (", ", $userRegisterGroupsIds);
		}
		
		if($groupString){
			$sql = "SELECT y2m_user.user_id, y2m_user.user_given_name,y2m_user.user_first_name,y2m_user.user_middle_name,y2m_user.user_last_name,		
		y2m_group.group_id, y2m_group.group_title 
				FROM y2m_user 
				CROSS JOIN y2m_group
				LEFT OUTER JOIN y2m_user_group ON y2m_user_group.user_group_user_id =  y2m_user.user_id  AND y2m_group.group_id = y2m_user_group.user_group_group_id  
				WHERE y2m_user.user_id = $user_id
				AND y2m_group.group_parent_group_id In ($groupString)
				AND y2m_user_group.user_group_id IS NULL ORDER BY rand() LIMIT 1 ";
		$statement = $this->adapter->query($sql);
		$resultSet = new ResultSet();
		$resultSet->initialize($statement->execute());	 
	  	return $resultSet;	
		
		}else{
				return array();
		}
		
		 
    } 

    public function saveUserGroup(UserGroup $userGroup)
    {
       $data = array(
            'user_group_user_id' => $userGroup->user_group_user_id,
            'user_group_group_id'  => $userGroup->user_group_group_id,
			'user_group_added_timestamp'  => $userGroup->user_group_added_timestamp,
			'user_group_added_ip_address'  => $userGroup->user_group_added_ip_address,
			'user_group_status'  => $userGroup->user_group_status,
			'user_group_is_owner'  => $userGroup->user_group_is_owner
		);

        $user_group_id = (int)$userGroup->user_group_id;
        if ($user_group_id == 0) {
            $this->insert($data);
			return $this->adapter->getDriver()->getConnection()->getLastGeneratedValue();
        } else {
            if ($this->getUserGroup($user_group_id)) {
                $this->update($data, array('user_group_id' => $user_group_id));
            } else {
                throw new \Exception('Form id does not exist');
            }
        }
    }

    public function deleteUserGroup($user_group_id)
    {
        $this->delete(array('user_group_id' => $user_group_id));
    }
	
	 
	
	

    
}