<?php
namespace Groups;
use Groups\Model\GroupsTable;
use Tag\Model\GroupTagTable;
class Module
{
    public function getAutoloaderConfig()
    {
        return array(
            'Zend\Loader\ClassMapAutoloader' => array(
                __DIR__ . '/autoload_classmap.php',
            ),
            'Zend\Loader\StandardAutoloader' => array(
                'namespaces' => array(
                    __NAMESPACE__ => __DIR__ . '/src/' . __NAMESPACE__,
                ),
            ),
        );
    }

    public function getConfig()
    {
        return include __DIR__ . '/config/module.config.php';
    }
	public function getServiceConfig()
    {
		return array(
            'factories' => array(
                  
				'Groups\Model\GroupsTable' =>  function($sm) {
                    $dbAdapter = $sm->get('Zend\Db\Adapter\Adapter');
                    $table = new GroupsTable($dbAdapter);
                    return $table;
                }, 
				'Tag\Model\GroupTagTable' =>  function($sm) {
                    $dbAdapter = $sm->get('Zend\Db\Adapter\Adapter');
                    $table = new GroupTagTable($dbAdapter);
					return $table;
                },
            ),
        );
	}
}