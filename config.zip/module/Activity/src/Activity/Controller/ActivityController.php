<?php   
####################Activity Controller #################################

namespace Activity\Controller;
use Zend\Mvc\Controller\AbstractActionController;
use Zend\View\Model\ViewModel;	//Return model 
use Zend\Session\Container; // We need this when using sessions     
use Zend\Authentication\AuthenticationService;	//Needed for checking User sessi on
use Zend\Authentication\Adapter\DbTable as AuthAdapter;	//Db apaptor 
use Zend\View\Renderer\PhpRenderer;

use Zend\Crypt\BlockCipher;		# For encryption
#Group classs 
use Groups\Model\Groups;  	#Planet/Galaxy  class
use User\Model\User;  	#User  class
use Groups\Model\GroupsTable; #Planet/Galaxy table class
use Groups\Model\UserGroup;	#user group class
use \Exception;		#Exception class for handling exception
use Activity\Model\Activity; #Activity class for loading activity
use Activity\Model\ActivityInvite; #Activity class for loading activity Invite
use Activity\Model\ActivityRsvp; #Activity class for loading activity Rsvp
use Notification\Model\UserNotification; 
 
 
use Zend\Mail;
use Zend\Mime\Message as MimeMessage;
use Zend\Mime\Part as MimePart;
#activity form
use Activity\Form\ActivityAddForm;
use Activity\Form\ActivityAddFormFilter;   

class ActivityController extends AbstractActionController
{
    protected $groupTable;		#variable to hold the group model configration
	protected $userGroupTable;	#variable to hold the user group model configration
	protected $userTable;		#variable to hold the user model configration
	protected $userProfileTable;	#variable to hold the user profile model configration
	protected $activityTable;		#variable to hold the activity model confirgration
	protected $activityInviteTable;		#variable to hold the activity Invite model configration
	protected $activityRsvpTable;		#variable to hold the activity Rsvp configration
	protected $userNotificationTable;
		
	#this function will load the css and javascript need for particular action
	protected function getViewHelper($helperName)
	{
    	return $this->getServiceLocator()->get('viewhelpermanager')->get($helperName);
	}  
   
 	#This function will load all activites.if you supply planet Id then it will load Id of Planet else it will load all activitiws
    public function indexAction()
    { 
		$error =array(); 
		$success =array(); 
		$identity ="";
		$userData =array();
		$subGroupId ="";
		$groupData =array();
		$subGroupData =array();	
		$activities =array();	
		$finalActivity =array();
		$activityData_upcoming = 	array();	
		$order =array();
		$where =array();
		$auth = new AuthenticationService();	
		$identity = null;    
		$incVar = 0;
		$userRegisteredGroup =array();    
		if ($auth->hasIdentity()) {  
			$sm = $this->getServiceLocator();		
			$request   = $this->getRequest();            
           	$identity = $auth->getIdentity();			
			$userData = $this->getUserTable()->getUser($identity->user_id);		
			$subGroupId= $this->params('group_id'); 		
			if(!empty($subGroupId)){			
				$subGroupData = $this->getGroupTable()->getSubGroup($subGroupId);				
				if(isset($subGroupData->group_id) && !empty($subGroupData->group_id) && isset($subGroupData->group_parent_group_id) && !empty($subGroupData->group_parent_group_id)){				 
					$groupData = $this->getGroupTable()->getGroup($subGroupData->group_parent_group_id);				 
					$userRegisteredGroup =$this->getUserGroupTable()->getUserGroup($userData->user_id, $subGroupData->group_id);		
				}
				$page = 0;
				$request   = $this->getRequest();				 		
				$post = $request->getPost();		
				if ($request->isPost()){
					$page =$post->get('page');
					if(!$page)
					$page = 0;
				}
				$offset = $page*10;
				$activities_upcoming   = $this->getActivityTable()->fetchAll_upcomingWithLikes($subGroupData->group_id,1,$identity->user_id,$offset);
				if($activities_upcoming->count()){
					foreach($activities_upcoming as $row){
				
						$row = get_object_vars($row);					 
						$blockCipher = BlockCipher::factory('mcrypt', array('algo' => 'aes'));
						$blockCipher->setKey('sfds^&*%(^$%^$%^KMNVHDrt#$$$%#@@');
						$row['encrypted_activity_id'] = $blockCipher->encrypt($row['group_activity_id']);				 
						$activityData_upcoming[$incVar] = $row;					
						$order = array();
						$order = array("group_activity_rsvp_id DESC");						
						$whereRsvp =array();
						$whereRsvp =array('y2m_group_activity_rsvp.group_activity_rsvp_activity_id'=> $row['group_activity_id']);				
						$rsvpactivityData_upcoming = $this->getActivityRsvpTable()->fetchAll($whereRsvp, $order, 6);
						if($rsvpactivityData_upcoming->count()){
							$jncVar = 0;
							foreach($rsvpactivityData_upcoming as $rsvpRow){
								$activityData_upcoming[$incVar]['rsvp'][$jncVar] =	get_object_vars($rsvpRow);
								$jncVar++;
							} 
						}	
						$incVar++;			
					}
				
				}else{
					$error[] ='No upcoming activities found in this group';
				}
			}else{
				$error[] ='This group is corrently not existing';
			}			
        }else{
			$error[] ='Invalid access';
		} 
 
	
		$viewModel = new ViewModel(array('identity' => $identity, 'groupData' => $groupData, 'userData' => $userData, 'userRegisteredGroup' =>$userRegisteredGroup, 'subGroupData' => $subGroupData, 'activityData_upcoming' => $activityData_upcoming,'error' => $error, 'success' => $success, 'flashMessages' => $this->flashMessenger()->getMessages(),'page'=>$page));
    	$viewModel->setTerminal($request->isXmlHttpRequest());
    	return $viewModel;	 
    }
	
	
	#this fuction will save user rsvp
	function activityrsvpAction(){
		$error =array();
		$success =array();
		$identity ="";		 		
		$auth = new AuthenticationService();	
		$identity = null;        
		if ($auth->hasIdentity()) {
			$identity = $auth->getIdentity();			 		 
			if(isset($identity->user_id) && !empty($identity->user_id)){ 
				$request   = $this->getRequest();				 		
				$post = $request->getPost();		
				if ($request->isPost()){
					$activity_id =$post->get('aId');					
					$activityData =$this->getActivityTable()->getActivity($activity_id);				 
					if(!empty($activityData)&& $activityData->group_activity_id!=''){
						$subGroupData = $this->getGroupTable()->getSubGroup($activityData->group_activity_group_id);
						if(isset($subGroupData->group_id) && !empty($subGroupData->group_id) && isset($subGroupData->group_parent_group_id) && !empty($subGroupData->group_parent_group_id)){					
							$groupData = $this->getGroupTable()->getGroup($subGroupData->group_parent_group_id);	
							$rsvpUser =$this->getActivityRsvpTable()->getActivityRsvpOfUser($identity->user_id, $activityData->group_activity_id);							
							if(isset($rsvpUser->group_activity_rsvp_id) && !empty($rsvpUser->group_activity_rsvp_id)){						 
								$error[] ='already attending';	
							}else{ 
								$activityRsvpData = array();
								$activityRsvpData['group_activity_rsvp_user_id'] = $identity->user_id;
								$activityRsvpData['group_activity_rsvp_activity_id'] =  $activityData->group_activity_id; 
								$activityRsvpData['group_activity_rsvp_added_ip_address'] = User::getUserIp();
								$activityRsvpData['group_activity_rsvp_group_id'] = $activityData->group_activity_group_id; 
								$activityRsvpObject = new ActivityRsvp();
								$activityRsvpObject->exchangeArray($activityRsvpData);
								$insertedActivityRsvpId =""; 
								$insertedActivityRsvpId = $this->getActivityRsvpTable()->saveActivityRsvp($activityRsvpObject); 
								if(isset($insertedActivityRsvpId) && !empty($insertedActivityRsvpId)){
									$success[] ='Rsvp done Succesfully';
									if($identity->user_id!=$activityData->group_activity_owner_user_id){
										$UserGroupNotificationData = array();						
										$UserGroupNotificationData['user_notification_user_id'] = $activityData->group_activity_owner_user_id;							
										$UserGroupNotificationData['user_notification_content'] = $identity->user_given_name." joined the activity of Planet <a href='".$this->url()->fromRoute('groups/subgroupmain-activity', array('action' => 'subgroupdetail', 'group_id'=>$groupData->group_seo_title, 'cgroup_id'=>$subGroupData->group_seo_title), $options=array())."'>".$subGroupData->group_title."</a>";								 
										$userObject = new user(array());
										$UserGroupNotificationData['user_notification_notification_type_id'] = "2";
										$UserGroupNotificationData['user_notification_status'] = 0;									
										$UserGroupNotificationSaveObject = new UserNotification();
										$UserGroupNotificationSaveObject->exchangeArray($UserGroupNotificationData);							
										$insertedUserGroupNotificationId ="";
										$insertedUserGroupNotificationId = $this->getUserNotificationTable()->saveUserNotification($UserGroupNotificationSaveObject);	
									}
								}else{
									$error[] ='Error in Rsvp';						
								}							
							}				
						}else{
							$error[] ="Invalid Planet";						
						}
					 }else{
					 	$error[] ="Activity Does not Exist";					 
					 }			 
				 }else{
					$error[] ='Invalid access';
				 }
			 }else{
				$error[] ='User Not Found';			
			 }
		}else{
			$error[] ='Invalid access';
		}		
		if($request->isXmlHttpRequest()){
			if(isset($error[0]) && !empty($error[0])){
				$arr = array('error' => "yes", 'status' => $error[0]);
				echo json_encode($arr);	
			}elseif(isset($success[0]) && !empty($success[0])){ //if(isset($error[0]) && !empty($error[0]))
				$arr = array('error' => "no", 'status' => $success[0]);
				echo json_encode($arr);
			}	
		}	
		$viewModel = new ViewModel(array('error' => $error, 'success' => $success, 'flashMessages' => $this->flashMessenger()->getMessages()));
    	$viewModel->setTerminal($request->isXmlHttpRequest());
    	return $viewModel;	 
	}
	public function quitrsvpAction(){
		$error =array();
		$success =array();
		$identity ="";		 		
		$auth = new AuthenticationService();	
		$identity = null;        
		if ($auth->hasIdentity()) {
			$identity = $auth->getIdentity();
			if(isset($identity->user_id) && !empty($identity->user_id)){ 
				$request   = $this->getRequest();				 		
				$post = $request->getPost();
				if ($request->isPost()){
					$activity_id =$post->get('aId');
					$activityData =$this->getActivityTable()->getActivity($activity_id);
					if(!empty($activityData)&& $activityData->group_activity_id!=''){		
						$subGroupData = $this->getGroupTable()->getSubGroup($activityData->group_activity_group_id);
						if(isset($subGroupData->group_id) && !empty($subGroupData->group_id) && isset($subGroupData->group_parent_group_id) && !empty($subGroupData->group_parent_group_id)){
							$groupData = $this->getGroupTable()->getGroup($subGroupData->group_parent_group_id);	
							$rsvpUser =$this->getActivityRsvpTable()->getActivityRsvpOfUser($identity->user_id, $activityData->group_activity_id);
							if(isset($rsvpUser->group_activity_rsvp_id) && !empty($rsvpUser->group_activity_rsvp_id)){
								if($this->getActivityRsvpTable()->removeActivityRsvp($activity_id,$identity->user_id)){
									$success[] ='You are removed from rsvp list';
									if($identity->user_id!=$activityData->group_activity_owner_user_id){
										$UserGroupNotificationData = array();						
										$UserGroupNotificationData['user_notification_user_id'] = $activityData->group_activity_owner_user_id;							
										$UserGroupNotificationData['user_notification_content'] = $identity->user_given_name." quit from the activity of Planet <a href='".$this->url()->fromRoute('groups/subgroupmain-activity', array('action' => 'subgroupdetail', 'group_id'=>$groupData->group_seo_title, 'cgroup_id'=>$subGroupData->group_seo_title), $options=array())."'>".$subGroupData->group_title."</a>";								 
										$userObject = new user(array());
										$UserGroupNotificationData['user_notification_notification_type_id'] = "2";
										$UserGroupNotificationData['user_notification_status'] = 0;									
										$UserGroupNotificationSaveObject = new UserNotification();
										$UserGroupNotificationSaveObject->exchangeArray($UserGroupNotificationData);							
										$insertedUserGroupNotificationId ="";
										$insertedUserGroupNotificationId = $this->getUserNotificationTable()->saveUserNotification($UserGroupNotificationSaveObject);	
									}
								}else{
									$error[] ='Error in Rsvp';		
								}
							}else{
								$error[] ='You are not joined in this event';	
							}
						}else{
							$error[] ="Invalid Planet";	
						}
					}else{
						$error[] ="Activity Does not Exist";
					}					
				}else{
					$error[] ='Invalid access';
				}
			}else{
				$error[] ='User Not Found';
			}
		}else{
			$error[] ='Invalid access';
		}
		if($request->isXmlHttpRequest()){
			if(isset($error[0]) && !empty($error[0])){
				$arr = array('error' => "yes", 'status' => $error[0]);
				echo json_encode($arr);	
			}elseif(isset($success[0]) && !empty($success[0])){ //if(isset($error[0]) && !empty($error[0]))
				$arr = array('error' => "no", 'status' => $success[0]);
				echo json_encode($arr);
			}	
		}	
		if(isset($error[0]) && !empty($error[0])){
			$arr = array('error' => "yes", 'status' => $error[0]);
			echo json_encode($arr);	
		}die();
	}
	public function viewAction(){	  
		$auth = new AuthenticationService();	
		$identity = null;
		$error = array();
		if ($auth->hasIdentity()) {
			$identity = $auth->getIdentity();
			if(isset($identity->user_id) && !empty($identity->user_id)){
				$this->layout()->identity = $identity;
				$sm = $this->getServiceLocator();
				$ActivityTable = $sm->get('Activity\Model\ActivityTable');			
				$id = (int)$this->params('id'); 
				if (!$id) {
					return $this->redirect()->toRoute('admin/admin-activity', array('action'=>'index'));
				}
				$view_activity = array();	
				$view_activity = $ActivityTable->getActivity($id); 
				if(!empty($view_activity)){
					$LikeTable = $sm->get('Like\Model\LikeTable');
					$activity_like_count = $LikeTable->fetchLikesCountByReference(1,$view_activity->group_activity_id);
					$check_user_like =  $LikeTable->LikeExistsCheck(1,$view_activity->group_activity_id,$identity->user_id);
					$subGroupData = $this->getGroupTable()->getSubGroup($view_activity->group_activity_group_id);
					if(!empty($subGroupData)){				
						$groupData = $this->getGroupTable()->getGroup($subGroupData->group_parent_group_id);
						if(!empty($groupData)){
							$whereRsvp =array('y2m_group_activity_rsvp.group_activity_rsvp_activity_id'=> $view_activity->group_activity_id);
							$rsvpactivityData = $this->getActivityRsvpTable()->fetchAll($whereRsvp);
							$user_join_status = $this->getActivityRsvpTable()->getActivityRsvpOfUser($identity->user_id,$view_activity->group_activity_id);
							return array('view_activity' => $view_activity,'activity_like_count'=>$activity_like_count,'check_user_like'=>$check_user_like,'subGroupData'=>$subGroupData,'groupData'=>$groupData,'error'=>$error,'rsvpactivityData'=>$rsvpactivityData,'identity' => $identity,'user_join_status'=>$user_join_status);
						}
						else{
							$error[] = 'Selected group is no longer active!';
							return array('error'=>$error);
						}
					}
					else{
						$error[] = 'Selected group is no longer active!';
						return array('error'=>$error);
					}
				}
				else{
					$error[] = 'Selected activity is no longer active!';
					return array('error'=>$error);
				}
				
			}
			else{
				return $this->redirect()->toRoute('user/login', array('action' => 'login'));
			}
		}
		else{
			return $this->redirect()->toRoute('user/login', array('action' => 'login'));
		}
	}
	
	public function calendarAction(){
	
	$year = date('Y');
	$month = date('m'); 

	echo json_encode(array(
	
		array(
			'id' => 111,
			'title' => "Event1",
			'start' => "$year-$month-10",
			'url' => "http://yahoo.com/"
		),
		
		array(
			'id' => 222,
			'title' => "Event2",
			'start' => "$year-$month-20",
			'end' => "$year-$month-22",
			'url' => "http://yahoo.com/"
		),
		array(
			'id' => 333,
			'title' => "My custom event",
			'start' => "$year-$month-26",
			'end' => "$year-$month-30",
			'url' => "http://yahoo.com/"
		),
		array(
			'id' => 444,
			'title' => "My custom event on same date",
			'start' => "$year-12-26",
			'end' => "$year-12-28",
			'url' => "http://yahoo.com/"
		),
		array(
			'id' => 555,
			'title' => "My custom event on october",
			'start' => "2014-01-26",
			'url' => "http://yahoo.com/"
		)
	
	));
	die();
	
	
	}
	#Activity tab for Planet Main page
	
    public function activitydetailAction()
    {
		
		$error =array();
		$success =array();
		$identity = null;
		$form = '';
		$auth = new AuthenticationService();
		$selectAllUserForPlanet = '';
		if ($auth->hasIdentity()) {
			$identity = $auth->getIdentity();
			$request   = $this->getRequest();
			$subGroupId= $this->params('group_id');
			if(isset($identity->user_id) && !empty($identity->user_id) && isset($subGroupId) && !empty($subGroupId)){
				$subGroupData = $this->getGroupTable()->getSubGroup($subGroupId);
				$GroupData = $this->getGroupTable()->getGroup($subGroupData->group_parent_group_id);				 
				if(!empty($subGroupData)){
					$userRegisteredGroup =$this->getUserGroupTable()->getUserGroup($identity->user_id, $subGroupData->group_id);
					if(!empty($userRegisteredGroup)){
						$userList =$this->getUserGroupTable()->fetchAllUserListForGroup($subGroupData->group_id);					
						$excludeUser =array();						
						$excludeUser['user_id'] = $identity->user_id;
						$selectAllUserForPlanet = UserGroup::selectFormatAllUserListGroupEncrypted($userList, $excludeUser); 
						$form = new ActivityAddForm($selectAllUserForPlanet);
						$form->get('submit')->setAttribute('value', 'Add');	
					}
					$order = array("group_activity_id DESC");				
					$where =array('y2m_group_activity.group_activity_group_id'=> $subGroupData->group_id);
					$activities_past       =$this->getActivityTable()->getAllActivityWithLikes($subGroupData->group_id,1,$identity->user_id);
					//$activities_past       = $this->getActivityTable()->fetchAll_past($where, $order, 10);
					$activityData_past     = array();
					$incVar=0;				
					if($activities_past->count()){
						foreach($activities_past as $row){				
							$row = get_object_vars($row);					
							$blockCipher = BlockCipher::factory('mcrypt', array('algo' => 'aes'));
							$blockCipher->setKey('sfds^&*%(^$%^$%^KMNVHDrt#$$$%#@@');
							$row['encrypted_activity_id'] = $blockCipher->encrypt($row['group_activity_id']);				 
							$activityData_past[$incVar] = $row;
							$order = array();
							$order = array("group_activity_rsvp_id DESC");
							$whereRsvp =array();
							$whereRsvp =array('y2m_group_activity_rsvp.group_activity_rsvp_activity_id'=> $row['group_activity_id']);
							$rsvpactivityData_past = $this->getActivityRsvpTable()->fetchAll($whereRsvp, $order, 6);
							if($rsvpactivityData_past->count()){
								$jncVar = 0;
								foreach($rsvpactivityData_past as $rsvpRow){
									$activityData_past[$incVar]['rsvp'][$jncVar] =	get_object_vars($rsvpRow);
									$jncVar++;
								} 
							}	
							$incVar++;			
						}
					}else{
				
					}//	echo "<pre>";	print_r($activityData_past);die();
					$order = array("group_activity_id DESC");				
					$where =array('y2m_group_activity.group_activity_group_id'=> $subGroupData->group_id);
					$activities            = $this->getActivityTable()->fetchAll($where, $order, 10);
					$activityData          = array();
					$incVar=0;			
					if($activities->count()){ 
						foreach($activities as $row){				
							$row = get_object_vars($row);					
							$blockCipher = BlockCipher::factory('mcrypt', array('algo' => 'aes'));
							$blockCipher->setKey('sfds^&*%(^$%^$%^KMNVHDrt#$$$%#@@');
							$row['encrypted_activity_id'] = $blockCipher->encrypt($row['group_activity_id']);				 
							$activityData[$incVar] = $row;					
							$order = array();
							$order = array("group_activity_rsvp_id DESC");					
							$whereRsvp =array();
							$whereRsvp =array('y2m_group_activity_rsvp.group_activity_rsvp_activity_id'=> $row['group_activity_id']);		
							$rsvpActivityData = $this->getActivityRsvpTable()->fetchAll($whereRsvp, $order, 6);
							if($rsvpActivityData->count()){
								$jncVar = 0;
								foreach($rsvpActivityData as $rsvpRow){
									$activityData[$incVar]['rsvp'][$jncVar] =	get_object_vars($rsvpRow);
									$jncVar++;
								} 
							}	
							$incVar++;			
						}				
					} 		
					$return_arr = array();	 
					foreach($activityData as $row) { 
						$year = date('Y',strtotime($row['group_activity_start_timestamp']));
						$month = date('m',strtotime($row['group_activity_start_timestamp'])); 
						$date = date('d',strtotime($row['group_activity_start_timestamp']));
						$url =  $this->url()->fromRoute('activity/activity-view', array('action' => 'view', 'id'=> $row['group_activity_id']), $options=array());
						$row_array['id'] = $row['group_activity_id'];
						$row_array['title'] = $row['group_activity_title'];
						$row_array['start'] = "$year-$month-$date";
						$row_array['url'] = $url; 
						array_push($return_arr,$row_array);
					}
					$json_events = json_encode($return_arr);
					$viewModel = new ViewModel(array('form' => $form,'json'=> $json_events, 'selectAllUserForPlanet' => $selectAllUserForPlanet, 'userRegisteredGroup' => $userRegisteredGroup ,'activityData_past'=>$activityData_past,'userData' => $identity, 'subGroupData' => $subGroupData,'groupData' => $GroupData,'activities' =>$activities,'error' => $error, 'success' => $success, 'flashMessages' => $this->flashMessenger()->getMessages(),'pastactivity_page'=>1));
					$viewModel->setTerminal($request->isXmlHttpRequest());
					return $viewModel;	   
				}
				else{
					$error[] = 'Planet is not existing';
				}				
			}
			else{
				$error[] = 'Unauthorized access';
			}
		}
		else{
			return $this->redirect()->toRoute('user/login', array('action' => 'login'));
		}
		   
    }	
	public function joinAction(){
		$planet = $this->params('planet_id');
		if($planet!=''){
			$auth = new AuthenticationService();
			if ($auth->hasIdentity()) {
				$identity = $auth->getIdentity();
				$planetdetails       = $this->getGroupTable()->getGroupIdFromSEO($planet);
				$groupseoTitle		 = $this->getGroupTable()->getSeotitle($planetdetails->group_parent_group_id);
				if($planetdetails->group_id!=''){
					$request   = $this->getRequest();
					$userList = $this->getUserGroupTable()->fetchAllUserListForGroup($planetdetails->group_id);
					
					$excludeUser =array();
					$excludeUser['user_id'] = $identity->user_id;
					$selectAllUserForPlanet = UserGroup::selectFormatAllUserListGroupEncrypted($userList, $excludeUser); 
					$form = new ActivityAddForm($selectAllUserForPlanet);
					$form->get('submit')->setAttribute('value', 'Add');	
					if ($request->isPost()) {
						$activity = new Activity();
						$form->setInputFilter(new ActivityAddFormFilter());	
						$form->setData($request->getPost());
						if ($form->isValid()) {
							$post = $request->getPost();						 									
							$InviteAct =array();
							$InviteAct =$post->get('InviteAct');
					
							$activityData = array();
							$activityData['group_activity_title'] = $post->get('group_activity_title');
							$activityData['group_activity_content'] = $post->get('group_activity_content');
							$activityData['group_activity_type'] = $post->get('group_activity_type');								 
							$activityData['group_activity_start_timestamp'] = $post->get('group_activity_start_timestamp');
							$activityData['group_activity_owner_user_id'] = $identity->user_id;
							$activityData['group_activity_location'] = $post->get('group_activity_location');
							$activityData['group_activity_group_id'] = $planetdetails->group_id;							
							$activityData['group_activity_added_ip_address'] =  User::getUserIp();
							$activityData['group_activity_added_timestamp'] =  date('Y-m-d');
							$activityData['group_activity_status'] = "1";							 
							$activityObject = new Activity();
							$activityObject->exchangeArray($activityData);
							$insertedActivityId ="";	#this will hold the latest inserted id value
							$insertedActivityId = $this->getActivityTable()->saveActivity($activityObject);
							if(isset($insertedActivityId) && !empty($insertedActivityId)){
								$success[] = 'Activity saved successfully';
								if($post->get('group_activity_type') == "public") { 
									$userList = $this->getUserGroupTable()->fetchAllUserListForGroup($planetdetails->group_id);
									foreach ($userList as $row){
										if($row->user_id!=$identity->user_id){
											$isMember = $this->userGroupTable->getUserGroup($row->user_id, $planetdetails->group_id);
											if(isset($isMember->user_group_id) && !empty($isMember->user_group_id)){
												$this->activityInvitation($identity->user_id,$row->user_id,$insertedActivityId,$planetdetails->group_id);												
											}
											else{												
												$error[] = $row->user_given_name.' not a member in this group';
											}
										}
									}
								}
								else{
									if(isset($InviteAct) && count($InviteAct)) {
										foreach($InviteAct as $row) {
											$filter = new \Zend\Filter\StripTags();
											$row =$filter->filter($row);									
											$filter = new \Zend\Filter\StringTrim();
											$row =$filter->filter($row);
											$filter = new \Zend\Filter\HtmlEntities();
											$row =$filter->filter($row);
											$blockCipher = BlockCipher::factory('mcrypt', array('algorithm' => 'aes')); 
											$blockCipher->setKey('JHHU98789*&^&^%^$^^&g53$@8');  
											$decryptTagId = $blockCipher->decrypt($row); 							
											$user_id = (int) $decryptTagId;
											$isMember = $this->userGroupTable->getUserGroup($user_id, $planetdetails->group_id);	
											if(isset($isMember->user_group_id) && !empty($isMember->user_group_id)){
												$this->activityInvitation($identity->user_id,$user_id,$insertedActivityId,$planetdetails->group_id);												 
											}
											else{												
												$error[] = $row->user_given_name.' not a member in this group';
											}
										}
									}
								}
								$this->flashMessenger()->addMessage('Activity Added Successfully');		//echo $planetdetails->group_seo_title;die();
								$this->redirect()->toRoute('groups/planethome', array('action' => 'planethome','group_id'=>$groupseoTitle->group_seo_title,'planet_id'=>$planetdetails->group_seo_title));
							}
							else {
								 $error[] = 'Oops an error is occured while saving activity';	
							}
						}
						else{
							$this->flashMessenger()->addMessage('Field validation failed');												
							return $this->redirect()->toRoute('groups/planethome', array('action' => 'planethome','group_id'=>$groupseoTitle->group_seo_title,'planet_id'=>$planetdetails->group_seo_title));
						}
					}
					else{
						$this->flashMessenger()->addMessage('Unautherized access');												
						return $this->redirect()->toRoute('groups/planethome', array('action' => 'planethome','group_id'=>$groupseoTitle->group_seo_title,'planet_id'=>$planetdetails->group_seo_title));
					}
				}
				else{
					$this->flashMessenger()->addMessage('Unautherized access');
					return $this->redirect()->toRoute('groups/index', array('action' => 'index'));		 
				}
			 }
			 else{
				return $this->redirect()->toRoute('user/login', array('action' => 'login'));
			 }
		}
		else{			
			$this->flashMessenger()->addMessage('Unautherized access');
			return $this->redirect()->toRoute('groups/index', array('action' => 'index'));
		}
	}
	public function activityInvitation($sender_id,$user_id,$ActivityId,$planet_id){ 
		$userData = $this->getUserTable()->getUser($sender_id);	
		$subGroupData = $this->getGroupTable()->getSubGroup($planet_id);
		$activityInviteData = array();
		$activityInviteData['group_activity_invite_sender_user_id'] = $userData->user_id;
		$activityInviteData['group_activity_invite_receiver_user_id'] = $user_id;
		$activityInviteData['group_activity_invite_status'] = 0;
		$activityInviteData['group_activity_invite_added_date'] =  date('Y-m-d');					
		$activityInviteData['group_activity_invite_added_ip_address'] =  User::getUserIp();
		$activityInviteData['group_activity_invite_activity_id'] = $ActivityId;
		$activityInviteObject = new ActivityInvite();
		$activityInviteObject->exchangeArray($activityInviteData); 
		$insertedActivityInviteId ="";	#this will hold the latest inserted id value
		$insertedActivityInviteId = $this->getActivityInviteTable()->saveActivityInvite($activityInviteObject); 
		if(isset($ActivityId) && !empty($ActivityId)){ 
			$UserGroupNotificationData = array();						
			$UserGroupNotificationData['user_notification_user_id'] = $userData->user_id;
			$msg	= $userData->user_first_name." ".$userData->user_last_name." has invited you for activity of Planet <a href='".$this->url()->fromRoute('activity/activity-view', array('action' => 'view', 'id'=>$ActivityId), $options=array())."'>".$subGroupData->group_title."</a>";
			$UserGroupNotificationData['user_notification_content']  = $msg;
			$UserGroupNotificationData['user_notification_added_timestamp'] = date('Y-m-d H:i:s');			
			$UserGroupNotificationData['user_notification_notification_type_id'] = "2";
			$UserGroupNotificationData['user_notification_status'] = 0;		
			#lets Save the User Notification
			$UserGroupNotificationSaveObject = new UserNotification();
			$UserGroupNotificationSaveObject->exchangeArray($UserGroupNotificationData);	
			$insertedUserGroupNotificationId ="";	#this will hold the latest inserted id value
			$insertedUserGroupNotificationId = $this->getUserNotificationTable()->saveUserNotification($UserGroupNotificationSaveObject);
			$reciver_data = $this->getUserTable()->getUser($user_id);	
			$this->sendNotificationMail($msg,'Activity Invitation',$reciver_data->user_email);
			
		}
		return true;		
	}
	public function loadpasteventsAction(){
		$error = array();
		$success = array();
		$auth = new AuthenticationService();
		if ($auth->hasIdentity()) {
			$identity = $auth->getIdentity();
			$planet_id= $this->params('planet_id');
			if(isset($identity->user_id) && !empty($identity->user_id) && isset($planet_id) && !empty($planet_id)){
				$subGroupData = $this->getGroupTable()->getSubGroup($planet_id);
				$GroupData = $this->getGroupTable()->getGroup($subGroupData->group_parent_group_id);	
				if(!empty($subGroupData)){
					$page = 0;
					$request   = $this->getRequest();				 		
					$post = $request->getPost();		
					if ($request->isPost()){
						$page =$post->get('page');
						if(!$page)
						$page = 0;
					}
					$offset = $page*10;
					$order = array("group_activity_id DESC");				
					$where =array('y2m_group_activity.group_activity_group_id'=> $subGroupData->group_id);
					$activities_past       =$this->getActivityTable()->getAllActivityWithLikes($subGroupData->group_id,1,$identity->user_id,$offset);
					$activityData_past     = array();
					$incVar=0;				
					if($activities_past->count()){
						foreach($activities_past as $row){				
							$row = get_object_vars($row);					
							$blockCipher = BlockCipher::factory('mcrypt', array('algo' => 'aes'));
							$blockCipher->setKey('sfds^&*%(^$%^$%^KMNVHDrt#$$$%#@@');
							$row['encrypted_activity_id'] = $blockCipher->encrypt($row['group_activity_id']);				 
							$activityData_past[$incVar] = $row;
							$order = array();
							$order = array("group_activity_rsvp_id DESC");
							$whereRsvp =array();
							$whereRsvp =array('y2m_group_activity_rsvp.group_activity_rsvp_activity_id'=> $row['group_activity_id']);
							$rsvpactivityData_past = $this->getActivityRsvpTable()->fetchAll($whereRsvp, $order, 6);
							if($rsvpactivityData_past->count()){
								$jncVar = 0;
								foreach($rsvpactivityData_past as $rsvpRow){
									$activityData_past[$incVar]['rsvp'][$jncVar] =	get_object_vars($rsvpRow);
									$jncVar++;
								} 
							}	
							$incVar++;			
						}
						$viewModel = new ViewModel(array('activityData_past'=>$activityData_past,'userData' => $identity, 'subGroupData' => $subGroupData,'groupData' => $GroupData,'error' => $error, 'success' => $success, 'flashMessages' => $this->flashMessenger()->getMessages(),'pastactivity_page'=>$page+1));
						$viewModel->setTerminal($request->isXmlHttpRequest());
						return $viewModel;	 
					}
				}else{
					$error[] = 'Planet is not existing';
				}
			}else{
				$error[] = 'Unauthorized access';
			}
		}
		else{
			return $this->redirect()->toRoute('user/login', array('action' => 'login'));
		}
	}
	public function sendNotificationMail($msg,$subject,$emailId){
		$this->renderer = $this->getServiceLocator()->get('ViewRenderer');
		
		$body = $this->renderer->render('activity/email/emailinvitation.phtml', array('msg'=>$msg));
		$htmlPart = new MimePart($body);
		$htmlPart->type = "text/html";

		$textPart = new MimePart($body);
		$textPart->type = "text/plain";

		$body = new MimeMessage();
		$body->setParts(array($textPart, $htmlPart));

		$message = new Mail\Message();
		$message->setFrom('admin@jeera.com');
		$message->addTo($emailId);
		//$message->addReplyTo($reply);							 
		$message->setSender("Jeera");
		$message->setSubject($subject);
		$message->setEncoding("UTF-8");
		$message->setBody($body);
		$message->getHeaders()->get('content-type')->setType('multipart/alternative');

		$transport = new Mail\Transport\Sendmail();
		$transport->send($message);
		return true;
	}
	#access Activity Table Module
	public function getActivityTable()
    {
        if (!$this->activityTable) {
            $sm = $this->getServiceLocator();
            $this->activityTable = $sm->get('Activity\Model\ActivityTable');
        }
        return $this->activityTable;
    }	
	#access Activity Invite Table Module
	public function getActivityInviteTable()
    {
        if (!$this->activityInviteTable) {
            $sm = $this->getServiceLocator();
            $this->activityInviteTable = $sm->get('Activity\Model\ActivityInviteTable');
        }
        return $this->activityInviteTable;
    }
	
	#access Activity Rsvp Table Module
	public function getActivityRsvpTable()
    {
        if (!$this->activityRsvpTable) {
            $sm = $this->getServiceLocator();
            $this->activityRsvpTable = $sm->get('Activity\Model\ActivityRsvpTable');
        }
        return $this->activityRsvpTable;
    }
	
	#access Galaxy/Planet Table Module
	 public function getGroupTable()
    {
        if (!$this->groupTable) {
            $sm = $this->getServiceLocator();
			$this->groupTable = $sm->get('Groups\Model\GroupsTable');
        }
        return $this->groupTable;
    } 
	
	#access User Galaxy/Planet Module
	 public function getUserGroupTable()
    {
        if (!$this->userGroupTable) {
            $sm = $this->getServiceLocator();
			$this->userGroupTable = $sm->get('Groups\Model\UserGroupTable');
        }
        return $this->userGroupTable;
    } 
	
	#access User Module 
    public function getUserTable()
    {
        if (!$this->userTable) {
            $sm = $this->getServiceLocator();
            $this->userTable = $sm->get('User\Model\UserTable');
        }
        return $this->userTable;
    } 
	
	#access User Profile Module
    public function getUserProfileTable()
    {
        if (!$this->userProfileTable) {
            $sm = $this->getServiceLocator();
            $this->userProfileTable = $sm->get('User\Model\UserProfileTable');
        }
        return $this->userProfileTable;
    } 
	
	#access User Notification
    public function getUserNotificationTable()
    {
        if (!$this->userNotificationTable) {
            $sm = $this->getServiceLocator();
            $this->userNotificationTable = $sm->get('Notification\Model\UserNotificationTable');
        }
        return $this->userNotificationTable;
    }
	 
}