<?php
namespace City\Controller;
use Zend\Mvc\Controller\AbstractActionController;
use Zend\View\Model\ViewModel;	//Return model 
use Zend\Session\Container; // We need this when using sessions     
use Zend\Authentication\AuthenticationService;
use Zend\Authentication\Adapter\DbTable as AuthAdapter;
/*use Zend\Authentication\Result as Result;
use Zend\Authentication\Storage;*/ 
#Country classs
use Zend\Crypt\BlockCipher;	#for encryption
use City\Model\City;  
class CityController extends AbstractActionController
{
    protected $cityTable;		#variable to hold the country model confirgration 
   
 	#it is not using right now   
    public function indexAction()
    {
		
		//echo "<pre>";print_r($shail);exit;
					
		$auth = new AuthenticationService();	
		$identity = null;        
		if ($auth->hasIdentity()) {
            // Identity exists; get it
           	$identity = $auth->getIdentity();
        } 
		$this->layout()->identity = $identity;	//assign Identity to layout    
        return array('identity' => $identity,);	 
    }
	public function citiesAction(){
		$error = array();
		$request   = $this->getRequest();
		if ($request->isPost()){
			$post = $request->getPost();
			$country_id = $post->get('country_id');
			$blockCipher = BlockCipher::factory('mcrypt', array('algorithm' => 'aes')); 
			$blockCipher->setKey('*&hhjj()_$#(&&^$%^$%^KMNVHDrt#$$$%#@@');
			$decryptCountryId = $blockCipher->decrypt($country_id); 	
			$first_country_id = (int) $decryptCountryId;  
			$selectCity = $this->getCityTable()->selectFormatAllCity($first_country_id);
			$city_selectbox = '<select name="user_profile_city" id="user_profile_city" class="styled">';
			foreach($selectCity as $key => $city){
				$city_selectbox.= '<option value="'.$key.'">'.$city.'</option>';
			}
			$city_selectbox.= '</select>';
			echo $city_selectbox;die();
		}else{
			echo $error = 'Invalid access';die();
		}		
	}
	#accessing the country table module
	public function getCityTable()
    {
        if (!$this->cityTable) {
            $sm = $this->getServiceLocator();
            $this->cityTable = $sm->get('City\Model\CityTable');
        }
        return $this->cityTable;
    }
	 
}