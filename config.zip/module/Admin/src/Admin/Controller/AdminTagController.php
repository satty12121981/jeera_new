<?php
namespace Admin\Controller; 
use Zend\Mvc\Controller\AbstractActionController;
use Zend\View\Model\ViewModel;	//Return model 
use Zend\Session\Container; // We need this when using sessions     
use Zend\Authentication\AuthenticationService;
use Zend\Authentication\Adapter\DbTable as AuthAdapter;
use Zend\Db\Sql\Select;
/*use Zend\Authentication\Result as Result;
use Zend\Authentication\Storage;*/ 
#Tag classs
use Tag\Model\Tag;
use Admin\Form\AdminTagForm;
use Admin\Form\AdminTagFilter;   
use Admin\Form\AdminTagEditFilter;   
class AdminTagController extends AbstractActionController
{   
	protected $userTable;			#variable to hold the User model configration 
	protected $userProfileTable;	#variable to hold the User Profile model configration 
	protected $tagTable;			#variable to hold the Tag configration 
	protected $groupTagTable;		#variable to hold the Group Tag model configration 
	protected $userTagTable;		#variable to hold the User Tag model configration 
	protected $groupTable;			#variable to hold the User Group model configration 
   
 	#Displaying Tag Grid
    public function indexAction()
    {		 
		$error = array();	#Error variable
		$success = array();	#success message variable
		
		$select = new Select();
        $order_by = $this->params()->fromRoute('order_by') ?  $this->params()->fromRoute('order_by') : 'tag_id';
        $order = $this->params()->fromRoute('order') ? $this->params()->fromRoute('order') : Select::ORDER_ASCENDING;
        $select->order($order_by . ' ' . $order);		
		
		#fetch all the tag
		$allTagData = array();	
		$allTagData = $this->getTagTable()->fetchAll();		  
        return array('allTagData' => $allTagData,'order_by' => $order_by,'order' => $order,'error' => $error, 'success' => $success, 'flashMessages' => $this->flashMessenger()->getMessages());	 
    }
	
	public function addAction()
    {        
	    $error = array();	#Error variable
		$success = array();	#success message variable
		
		#db connectivity
		$sm = $this->getServiceLocator();
		$dbAdapter = $sm->get('Zend\Db\Adapter\Adapter');
		
		$form = new AdminTagForm();
        $form->get('submit')->setAttribute('value', 'Add');

        $request = $this->getRequest();
        if ($request->isPost()) {
      		$tag = new Tag();
          	$form->setInputFilter(new AdminTagFilter($dbAdapter));					 
           	$form->setData($request->getPost());
            if ($form->isValid()) {
                $tag->exchangeArray($form->getData());
                $this->getTagTable()->saveTag($tag);
                // Redirect to list of tags
                return $this->redirect()->toRoute('admin/admin-tags');
            } 
        }

        return array('form' => $form, 'error' => $error, 'success' => $success, 'flashMessages' => $this->flashMessenger()->getMessages());
    }

    public function editAction()
    {
        $error = array();	#Error variable
		$success = array();	#success message variable
		
		#db connectivity
		$sm = $this->getServiceLocator();
		$dbAdapter = $sm->get('Zend\Db\Adapter\Adapter');
		
		$id = (int)$this->params('id');
        if (!$id) {
            return $this->redirect()->toRoute('admin/admin-tags', array('action'=>'add'));
        }
        $tag = $this->getTagTable()->getTag($id); 
		if(isset($tag->tag_id) && !empty($tag->tag_id)){
			
		}else{
			return $this->redirect()->toRoute('admin/admin-tags', array('action'=>'index'));
		} 

        $form = new AdminTagForm();
        $form->bind($tag);
        $form->get('submit')->setAttribute('value', 'Edit');
        
        $request = $this->getRequest();
        if ($request->isPost()) {
			$form->setInputFilter(new AdminTagEditFilter($dbAdapter, $id));		
            $form->setData($request->getPost());
            if ($form->isValid()) {
                $this->getTagTable()->saveTag($tag);

                // Redirect to list of tags
                return $this->redirect()->toRoute('admin/admin-tags');
            }else{
				echo "error in form";
			}
        }

        return array(
            'id' => $id,
            'form' => $form,
			'error' => $error, 
			'success' => $success, 
			'flashMessages' => $this->flashMessenger()->getMessages()
        );
    }

    public function deleteAction()
    {
		$error = array();	#Error variable
		$success = array();	#success message variable
		
	    $id = (int)$this->params('id');
        if (!$id) {
            return $this->redirect()->toRoute('admin/admin-tags');
        }
		$tag = $this->getTagTable()->getTag($id); 
		if(isset($tag->tag_id) && !empty($tag->tag_id)){
			
		}else{
			return $this->redirect()->toRoute('admin/admin-tags', array('action'=>'index'));
		} 	

        $request = $this->getRequest();
        if ($request->isPost()) {
            $del = $request->getPost()->get('del', 'No');
            if ($del == 'Yes') {
                $id = (int)$request->getPost()->get('id');
                $this->getTagTable()->deleteTag($id);
            }
            // Redirect to list of tags
            return $this->redirect()->toRoute('admin/admin-tags');
        }
	 
        return array(
            'id' => $id,
            'tag' => $this->getTagTable()->getTag($id),
			'usersList' => $this->getUserTagTable()->fetchAllUsersOfTag($id),
			'groupList' => $this->getGroupTagTable()->fetchAllGroupsOfTag($id),
			'error' => $error, 
			'success' => $success, 
			'flashMessages' => $this->flashMessenger()->getMessages()
        );
    }	 
	
	#accessing the user table module
	public function getUserTable()
    {
        if (!$this->userTable) {
            $sm = $this->getServiceLocator();
            $this->userTable = $sm->get('User\Model\UserTable');
        }
        return $this->userTable;
    }
	
	#accessing the user profile table module
	public function getUserProfileTable()
    {
        if (!$this->userProfileTable) {
            $sm = $this->getServiceLocator();
            $this->userProfileTable = $sm->get('User\Model\UserProfileTable');
        }
        return $this->userProfileTable;
    }
	
	#Accessing the tag table
	public function getTagTable()
    {
        if (!$this->tagTable) {
            $sm = $this->getServiceLocator();
            $this->tagTable = $sm->get('Tag\Model\TagTable');
        }
        return $this->tagTable;
    }
	
	#Accessing the Group tag table
	public function getGroupTagTable()
    {
        if (!$this->groupTagTable) {
            $sm = $this->getServiceLocator();
            $this->groupTagTable = $sm->get('Tag\Model\GroupTagTable');
        }
        return $this->groupTagTable;
    }
	
	#Accessing the Group tag table
	public function getUserTagTable()
    {
        if (!$this->userTagTable) {
            $sm = $this->getServiceLocator();
            $this->userTagTable = $sm->get('Tag\Model\UserTagTable');
        }
        return $this->userTagTable;
    }
	
	
	 
}