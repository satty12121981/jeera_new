<?php 
 
namespace User\Model;

use Zend\Db\TableGateway\AbstractTableGateway;
use Zend\Db\Adapter\Adapter;
use Zend\Db\ResultSet\ResultSet;


class UserTable extends AbstractTableGateway
{
    protected $table = 'y2m_user';

    public function __construct(Adapter $adapter)
    {
        $this->adapter = $adapter;
        $this->resultSetPrototype = new ResultSet();
        $this->resultSetPrototype->setArrayObjectPrototype(new User());

        $this->initialize();
    }

    public function fetchAll()
    {
        $resultSet = $this->select();
        return $resultSet;
    }

    public function getUser($user_id)
    {
        $user_id  = (int) $user_id;
        $rowset = $this->select(array('user_id' => $user_id));
        $row = $rowset->current();
         
        return $row;
    }
	
	

    public function saveUser(User $user)
    {
       $data = array(
            'user_given_name' => $user->user_given_name,
            'user_first_name'  => $user->user_first_name,
			'user_middle_name'  => $user->user_middle_name,
			'user_last_name'  => $user->user_last_name,
			'user_status'  => $user->user_status,
			'user_added_ip_address'  => $user->user_added_ip_address,
			'user_email'  => $user->user_email,
			'user_password'  => $user->user_password,
			'user_gender'  => $user->user_gender,
			'user_timeline_photo_id'  => $user->user_timeline_photo_id,
			'user_language_id'  => $user->user_language_id,
			'user_user_type_id'  => $user->user_user_type_id,
			'user_profile_photo_id'  => $user->user_profile_photo_id,
			'user_friend_request_reject_count'  => $user->user_friend_request_reject_count,
			'user_mobile'  => $user->user_mobile,
			'user_verification_key'  => $user->user_verification_key,
			'user_added_timestamp'  => $user->user_added_timestamp,
			'user_modified_timestamp'  => $user->user_modified_timestamp,
			'user_modified_ip_address'  => $user->user_modified_ip_address,	
			'user_register_type'  => $user->user_register_type,			
        );
		 $user_id = (int)$user->user_id;
        if ($user_id == 0) {
            $this->insert($data);
			return $this->adapter->getDriver()->getConnection()->getLastGeneratedValue();
						 		 
        } else {
            if ($this->getUser($user_id)) {
                $this->update($data, array('user_id' => $user_id));
            } else {
                throw new \Exception('Form id does not exist');
            }
        }
    }
	public function updateUser($data,$user_id){
		if ($this->getUser($user_id)) {
			$this->update($data, array('user_id' => $user_id));
			return true;
		} else {
			throw new \Exception('Form id does not exist');
		}
		
	}
    public function deleteUser($user_id)
    {
        $this->delete(array('user_id' => $user_id));
    }
	public function checkUserVarification($code,$user){ 
		$rowset = $this->select(array('user_verification_key'=>$code));
        $row = $rowset->current();
		if($row){
			if($row->user_status==0&&md5(md5('userId~'.$row->user_id))==$user)
			return $row->user_id;
			else
			return false;
		}
		else{	
			return false;
		}
	}
	public function getUserFromEmail($email)
    {
       
        $rowset = $this->select(array('user_email' => $email));
        $row = $rowset->current();
         
        return $row;
    }
	

}
