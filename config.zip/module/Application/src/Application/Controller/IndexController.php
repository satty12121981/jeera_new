<?php
namespace Application\Controller;

use Zend\Mvc\Controller\AbstractActionController;
use Zend\View\Model\ViewModel;
use Zend\Authentication\AuthenticationService;
use Zend\Authentication\Adapter\DbTable as AuthAdapter;

class IndexController extends AbstractActionController
{
	public function indexAction()
    {
		ini_set('display_errors',1);
		ini_set('display_startup_errors',1);	 
		$auth = new AuthenticationService();	
		$identity = NULL;
		$vm = new ViewModel();	 
        if ($auth->hasIdentity()) {
            $identity = $auth->getIdentity();
			$this->layout()->identity = $identity;
			$vm->setTemplate('application/index/home');	
			$vm->setVariable('userData', $identity);			
        }else{
			$this->layout()->identity = $identity;	//assign Identity to layout			
		}
		return $vm;
    }
}
