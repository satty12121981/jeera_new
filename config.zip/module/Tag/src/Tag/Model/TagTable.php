<?php
namespace Tag\Model;
use Zend\Db\Sql\Select , \Zend\Db\Sql\Where;
use Zend\Db\TableGateway\AbstractTableGateway;
use Zend\Db\Adapter\Adapter;
use Zend\Db\ResultSet\ResultSet;
use Zend\Crypt\BlockCipher;	#for encryption
use Zend\Db\Sql\Expression;
class TagTable extends AbstractTableGateway
{
    protected $table = 'y2m_tag'; 

    public function __construct(Adapter $adapter)
    {
        $this->adapter = $adapter;
        $this->resultSetPrototype = new ResultSet();
        $this->resultSetPrototype->setArrayObjectPrototype(new Tag());

        $this->initialize();
    }
    public function fetchAll()
    {
       $resultSet = $this->select();
        return $resultSet;
    }

   public function getTag($tag_id)
    {
        $tag_id  = (int) $tag_id;
        $rowset = $this->select(array('tag_id' => $tag_id));
        $row = $rowset->current();
        
        return $row;
    }

    public function saveTag(Tag $tag)
    {
       $data = array(
            'tag_title' => $tag->tag_title,
            'tag_added_timestamp'  => $tag->tag_added_timestamp,
			'tag_added_ip_address'  => $tag->tag_added_ip_address			
        );

        $tag_id = (int)$tag->tag_id;
        if ($tag_id == 0) {
            $this->insert($data);
			return $this->adapter->getDriver()->getConnection()->getLastGeneratedValue();
        } else {
            if ($this->getTag($tag_id)) {
                $this->update($data, array('tag_id' => $tag_id));
            } else {
                throw new \Exception('Form id does not exist');
            }
        }
    }

    public function deleteTag($tag_id)
    {
        $this->delete(array('tag_id' => $tag_id));
    }	
	
	//This function will encrypt the tag id for form
	public function encryptTagArray(){
		$data = $this->fetchAll();
		//This function will return the format of  '0' => 'Apple', '1' => 'Mango' of tag but in encrypted format				 
		$blockCipher = BlockCipher::factory('mcrypt', array('algo' => 'aes'));
		$blockCipher->setKey('*&hhjj()_$#(&&^$%gdgfd^&*%fgfg'); 		
		$selectObject =array();				
		foreach($data as $tag){
			$selectObject[$blockCipher->encrypt($tag->tag_id)] = $tag->tag_title;
			//print_r($row);
		}		
		return $selectObject;	//return blank array
	
	}
	public function getPopularUserTags($page_start,$limit,$tag_string=''){
		$inner_select = new Select;
		$inner_select->from('y2m_user_tag')
					 ->columns(array(new Expression('COUNT(y2m_user_tag.user_tag_tag_id) as tag_count'),'user_tag_tag_id'=>'user_tag_tag_id'));
		$inner_select->group('y2m_user_tag.user_tag_tag_id');			 
		$select = new Select;
		$select->from('y2m_tag')
			   ->columns(array('tag_id'=>'tag_id','tag_title'=>'tag_title'))
			   ->join(array('temp' => $inner_select), 'y2m_tag.tag_id = temp.user_tag_tag_id',array(),'left');
		if($tag_string!=''){
			$select->where->like('tag_title','%'.$tag_string.'%');
		}
		$select->order(array('tag_count DESC'));
		$select->limit($limit);
		$select->offset($page_start);
		$statement = $this->adapter->createStatement();
		$select->prepareStatement($this->adapter, $statement);
		
		//echo $select->getSqlString();die();
		$resultSet = new ResultSet();
		$resultSet->initialize($statement->execute());	
		return $resultSet;	
	}
	
	
 
}