<?php
namespace Admin\Controller; 
use Zend\Mvc\Controller\AbstractActionController;
use Zend\View\Model\ViewModel;	//Return model 
use Zend\Session\Container; // We need this when using sessions     
use Zend\Authentication\AuthenticationService;
use Zend\Authentication\Adapter\DbTable as AuthAdapter;
use Zend\Db\Sql\Select;
use Zend\Validator\File\Size;
/*use Zend\Authentication\Result as Result;
use Zend\Authentication\Storage;*/ 
use Group\Model\Group;
use Photo\Model\Photo;
use User\Model\User; 
use Group\Model\UserGroup;
use Group\Model\UserGroupAddSuggestion;
use Notification\Model\UserNotification;
use Admin\Form\AdminPlanetForm;
use Admin\Form\AdminPlanetFilter;   
use Admin\Form\AdminPlanetEditFilter; 
class AdminPlanetController extends AbstractActionController
{   
	protected $userTable;			#variable to hold the User model configuration 
	protected $groupTable;			#variable to hold the group model configuration 
	protected $userGroupTable;
	protected $userProfileTable;	#variable to hold the User Profile model configuration 
	protected $photoTable;		    #variable to hold the Photo model configuration
	protected $userGroupAddSuggestionTable;	
	protected $userNotificationTable;
	protected $Group_Thumb_Path = "";	//Image path of Group Timelime
	protected $Group_Timeline_Path = "";	//Image path of Group Timelime
	protected $Group_Thumb_Smaller = "";	//Image path of Group small Thumb
	protected $Group_Minumum_Bytes = "";	//Image path of Group small Thumb 
	
	public function __construct()
    {
        // do some stuff!
		$this->Group_Thumb_Path = Group::Group_Thumb_Path;  
		$this->Group_Timeline_Path = Group::Group_Timeline_Path;  
		$this->Group_Thumb_Smaller = Group::Group_Thumb_Smaller;  		
		$this->Group_Minumum_Bytes = Group::Group_Minumum_Bytes;  	
    }
	
   
 	#Displaying Tag Grid
    public function indexAction()
    {		 
		$select = new Select();
        $order_by = $this->params()->fromRoute('order_by') ?  $this->params()->fromRoute('order_by') : 'tag_id';
        $order = $this->params()->fromRoute('order') ? $this->params()->fromRoute('order') : Select::ORDER_ASCENDING;
        $select->order($order_by . ' ' . $order);		
		
		#fetch all the tag
		$allSubGroupData = array();	
		$allSubGroupData = $this->getGroupTable()->fetchAllSubGroups();	
		  
        return array('allSubGroupData' => $allSubGroupData,'order_by' => $order_by,'order' => $order,);	 
    }
	
	public function addAction()
    {   
	    #db connectivity
		$sm = $this->getServiceLocator();
		$dbAdapter = $sm->get('Zend\Db\Adapter\Adapter');
		
		#fetch the upload path		
		$config = $this->getServiceLocator()->get('Config');
		
		#fetch all Galaxy  
		$allGroupData = array();	
		$allGroupData = $this->getGroupTable()->fetchAllGroups();
		$selectAllGroup =array();
		$selectAllGroup = Group::selectFormatAllGroup($allGroupData);	
		
		$form = new AdminPlanetForm($selectAllGroup);
        $form->get('submit')->setAttribute('value', 'Add');

        $request = $this->getRequest();
        if ($request->isPost()) {
      		$group = new Group();
          	$form->setInputFilter(new AdminPlanetFilter($dbAdapter));					 
           	$form->setData($request->getPost());
            if ($form->isValid()) {
				
				##File upload pre settings starts here
				$nonFile = $request->getPost()->toArray();
				$File    = $this->params()->fromFiles('group_image');
				$data = array_merge(
					 $nonFile, //POST
					 array('group_image'=> $File['name']) //FILE...
				 );
				
				$size = new Size(array('min'=>$this->Group_Minumum_Bytes)); //minimum bytes filesize
		 
				$adapter = new \Zend\File\Transfer\Adapter\Http();
				//validator can be more than one....Adding validator for Size
				$adapter->setValidators(array($size), $File['name']);
				//Adding Validator for Extension
				$adapter->addValidator('Extension', false, 'jpg,png,gif');
				##File upload pre settings ends here
				
				if ( !$adapter->isValid() ) {
					$dataError = $adapter->getMessages();
					$error = array();
					foreach($dataError as $key=>$row) {
						$error[] = $row;
					} //set formElementErrors
					
					$form->setMessages( array('group_image'=>$error ));
				} 
				else {
					##upload The Planet Image
					$fileName = "";
					$fileName = group::uploadGroupImage('Planet',$File, $config['pathInfo']['UploadPath'], $adapter, $this->params()->fromPost('group_title'));
					
					if (!$fileName) {
						$fileName = "no-image.jpg";
					}
					
					//add photo table for group(planet) cover pic
					$photo = new Photo();
					$photoData['photo_name'] = $fileName;
					$photoData['photo_added_ip_address'] = user::getUserIp();
					$photoData['photo_caption'] = $this->params()->fromPost('group_seo_title');
					$photoData['photo_status'] = "1";
					$photoData['photo_discription'] = $this->params()->fromPost('group_discription');					 
					$photoData['photo_added_ip_address'] = user::getUserIp();	
					$photoData['photo_user_id'] = "1";
					$photoData['photo_location'] = "";
					$photoData['photo_visible'] = "1";				 
					$photoData['photo_view_counter'] = "0";	
					
					#save the planet cover photo
					$photo->exchangeArray($photoData);
					$last_insert_photo_id = $this->getPhotoTable()->savePhoto($photo); // label photo id
			
					$groupData = array();      
					$groupData['group_title'] = $this->params()->fromPost('group_title');
					$groupData['group_seo_title'] = $this->params()->fromPost('group_seo_title');
					$groupData['group_status'] = "1";
					$groupData['group_discription'] = $this->params()->fromPost('group_discription');      
					$groupData['group_location'] = $this->params()->fromPost('group_location');
					$groupData['group_added_ip_address'] = user::getUserIp();
					$groupData['group_parent_group_id'] = $this->params()->fromPost('group_parent_group_id');
					$groupData['group_photo_id'] = $last_insert_photo_id; // label photo id
					$groupData['group_view_counter'] = "0";     

					#save the group(planet)
					$group->exchangeArray($groupData); 
					$this->getGroupTable()->saveSubGroup($group);
				}
                // Redirect to list of tags
                return $this->redirect()->toRoute('admin/admin-planet');
            } 
        }

        return array('form' => $form);
    }

    public function editAction()
    {
		$success =array();	#success message variable
        #db connectivity
		$sm = $this->getServiceLocator();
		$dbAdapter = $sm->get('Zend\Db\Adapter\Adapter');
		
		#fetch the upload path		
		$config = $this->getServiceLocator()->get('Config');
		
		$id = (int)$this->params('id');
        if (!$id) {
            return $this->redirect()->toRoute('admin/admin-planet', array('action'=>'add'));
        }
		
        $group = $this->getGroupTable()->getSubGroup($id); 
		if(isset($group->group_id) && !empty($group->group_id)){
			
		}else{
			return $this->redirect()->toRoute('admin/admin-planet', array('action'=>'index'));
		}
		
		$groupPhoto = array();
		$groupPhoto = $this->getPhotoTable()->getPhoto($group->group_photo_id);
		
		#fetch all Galaxy  
		$allGroupData = array();	
		$allGroupData = $this->getGroupTable()->fetchAllGroups();
		$selectAllGroup =array();
		$selectAllGroup = Group::selectFormatAllGroup($allGroupData);	

        $form = new AdminPlanetForm($selectAllGroup);
        $form->bind($group);
        $form->get('submit')->setAttribute('value', 'Edit');
        
        $request = $this->getRequest();
		
        if ($request->isPost()) {
		
			$group = new Group();
			$form->setInputFilter(new AdminPlanetEditFilter($dbAdapter, $id));	
			##File upload pre settings starts here			
            $form->setData($request->getPost());
			$nonFile = $request->getPost()->toArray();
            $File = $this->params()->fromFiles('group_image');
            $data = array_merge(
				$nonFile, //POST
                 array('group_image'=> $File['name']) //FILE...
             );  
			 
			$group_photo_id = "";
			
            if ($form->isValid()) {
					
					if(isset($File['name']) && !empty($File['name'])) {
						####################################### IF user has upload New File###########################################
						$size = new Size(array('min'=>$this->Group_Minumum_Bytes)); //minimum bytes filesize
						$adapter = new \Zend\File\Transfer\Adapter\Http();					
						$adapter->setValidators(array($size), $File['name']);//validator can be more than one....Adding validtor for Size
						$adapter->addValidator('Extension', false, 'jpg,png,gif');//validattion for extension
					
						if (!$adapter->isValid()) {
							#error in file Upload
							$dataError = $adapter->getMessages();
							$error = array();
							foreach($dataError as $key=>$row)
							{
								$error[] = $row;
							} //set formElementErrors
							$addGroup = false; //stop adding group since there is a error in file upload
							$form->setMessages(array('group_image'=>$error ));
						} 
						else { 
						
							#no error. Upload the file
							$fileName = "";
							$fileName = group::uploadGroupImage('Planet',$File, $config['pathInfo']['UploadPath'], $adapter, $this->params()->fromPost('group_title'));
							if(!$fileName) { 
								$fileName = "no-image.jpg";
							} 
						
							//Edit photo table for planet cover pic
							$photo = new Photo();
							$photoData['photo_name'] = $fileName;
							$photoData['photo_added_ip_address'] = user::getUserIp();
							$photoData['photo_caption'] = $this->params()->fromPost('group_seo_title');
							$photoData['photo_status'] = "1";
							$photoData['photo_discription'] = $this->params()->fromPost('group_discription');					 
							$photoData['photo_added_ip_address'] = user::getUserIp();	
							$photoData['photo_user_id'] = "1";
							$photoData['photo_location'] = "";
							$photoData['photo_visible'] = "1";				 
							$photoData['photo_view_counter'] = "0";	
							$photo->exchangeArray($photoData);
							$group_photo_id = $this->getPhotoTable()->savePhoto($photo);
						}
					}
					else{ //if(isset($File['name']) && !empty($File['name']))
						########################################If User has not Upload Any fiile#######################################
						//$addGroup = true; 
						$group_photo_id = $this->params()->fromPost('group_photo_id');
				    } //else of  if(isset($File['name']) && !empty($File['name']))
				  
					$groupData = array();      
					$groupData['group_id'] = $this->params()->fromPost('group_id');
					$groupData['group_title'] = $this->params()->fromPost('group_title');
					$groupData['group_seo_title'] = $this->params()->fromPost('group_seo_title');
					$groupData['group_status'] = "1";
					$groupData['group_discription'] = $this->params()->fromPost('group_discription');      
					$groupData['group_location'] = $this->params()->fromPost('group_location');
					$userObj = new User();
					$groupData['group_added_ip_address'] = $userObj->getUserIp();
					$groupData['group_parent_group_id'] = $this->params()->fromPost('group_parent_group_id');
					$groupData['group_photo_id'] = $group_photo_id ;
					$groupData['group_view_counter'] = "0";     
					
					$group->exchangeArray($groupData); 
					$this->getGroupTable()->saveSubGroup($group);
					
					// Redirect to list of tags
					return $this->redirect()->toRoute('admin/admin-planet');	
            } else {
				echo "Error in Form";
			}
        }

        return array(
            'id' => $id,
            'form' => $form,
			'success' => $success, 'flashMessages' => $this->flashMessenger()->getMessages(),
			'group' => $group,
			'groupPhoto' => $groupPhoto,
			'groupThumb' => $this->Group_Thumb_Path
        );
    }

    public function deleteAction()
    {
		$error = array();
		$success = array();	#success message variable
	
	    $id = (int)$this->params('id');
        if (!$id) {
            return $this->redirect()->toRoute('admin/admin-planet');
        }
		
		$group = $this->getGroupTable()->getSubGroup($id); 
		if(isset($group->group_id) && !empty($group->group_id)){
			
		}else{
			return $this->redirect()->toRoute('admin/admin-planet', array('action'=>'index'));
		}

        $request = $this->getRequest();
        if ($request->isPost()) {
		   
            $del = $request->getPost()->get('del', 'No');
            if ($del == 'Yes') {
                $id = (int)$request->getPost()->get('id');
				$grp = $this->getGroupTable()->getSubGroup($id);
				$this->getPhotoTable()->deletePhoto($grp->group_photo_id); //delete cover pic of planet(group)
				$this->getGroupTable()->deleteSubGroup($id); //delete actual planet
            }

            // Redirect to list of tags
            return $this->redirect()->toRoute('admin/admin-planet');
        }
	 
        return array(
            'id' => $id,
            'group' => $this->getGroupTable()->getSubGroup($id),		 
			'error' => $error, 'success' => $success, 'flashMessages' => $this->flashMessenger()->getMessages()
        );
    }	
	
	
	
	
	public function approvelistAction()
    { 
		$select = new Select();
        $order_by = $this->params()->fromRoute('order_by') ?  $this->params()->fromRoute('order_by') : 'tag_id';
        $order = $this->params()->fromRoute('order') ? $this->params()->fromRoute('order') : Select::ORDER_ASCENDING;
        $select->order($order_by . ' ' . $order);		
		
		#fetch all the suggested Planets
		$allSuggestSubGroupData = array();	
		$allSuggestSubGroupData = $this->getUserGroupAddSuggestionTable()->fetchAllUserGroupAddSuggestion();	 
        return array('allSuggestSubGroupData' => $allSuggestSubGroupData,'order_by' => $order_by,'order' => $order,);	 	
	
	} 
	
	#Approved the Sugggest Planet
	 public function approveplanetAction()
    {    
		$error = array();
		$success = array();	#success message variable
	
	    $id = (int)$this->params('id');
        if (!$id) {
            return $this->redirect()->toRoute('admin/admin-planet');
        }
		
		$approvegroup =array();
		$approvegroup =$this->getUserGroupAddSuggestionTable()->getUserGroupAddSuggestion($id);
		if(isset($approvegroup->group_add_suggestion_id) && !empty($approvegroup->group_add_suggestion_id)){
			
		}else{
			return $this->redirect()->toRoute('admin/admin-planet', array('action'=>'approvelist'));
		}
		
		
        $request = $this->getRequest();
        if ($request->isPost()) {
		
            $del = $request->getPost()->get('del', 'No');
			if ($del == 'Approve') {
                $id = (int)$request->getPost()->get('id');
				
				#first check if suggest name is already exist in galaxy
				$groupData =array();
				$groupData = $this->getGroupTable()->getGroupForName($approvegroup->group_add_suggestion_name);	
					
				if(isset($groupData->group_id) && !empty($groupData->group_id)){	
					#Galaxy already exist	
					
					$error[] ='Planet already exist for this name';					
				}else{ //if(isset($groupData->group_id) && !empty($groupData->group_id))
					#approve the Request
					
					$userGroupAddSuggestData = array();
					$userGroupAddSuggestData['group_add_suggestion_id'] = $approvegroup->group_add_suggestion_id;
					$userGroupAddSuggestData['group_add_suggestion_user_id'] = $approvegroup->group_add_suggestion_user_id;
					$userGroupAddSuggestData['group_add_suggestion_name'] = $approvegroup->group_add_suggestion_name;
					$userGroupAddSuggestData['group_add_suggestion_status'] = "1";
					$userGroupAddSuggestData['group_add_suggestion_parent_group_id'] = $approvegroup->group_add_suggestion_parent_group_id;
					#create object of User class
					$user = new User();
					$userGroupAddSuggestData['group_add_suggestion_added_ip_address'] = $user->getUserIp();				
					
					
					#Approved User Suggestion
					$userGroupAddSuggest = new UserGroupAddSuggestion();
					$userGroupAddSuggest->exchangeArray($userGroupAddSuggestData);
					if($this->getUserGroupAddSuggestionTable()->saveUserGroupAddSuggestionForApproval($userGroupAddSuggest)){
						#Save this Planet				
						$fileName = "no-image.jpg";
						//add photo table for group(planet) cover pic
						$photo = new Photo();
						$photoData['photo_name'] = $fileName;
						$photoData['photo_added_ip_address'] = user::getUserIp();
						$photoData['photo_caption'] = $approvegroup->group_add_suggestion_name;
						$photoData['photo_status'] = "1";
						$photoData['photo_discription'] = $approvegroup->group_add_suggestion_name;					 
						$photoData['photo_user_id'] = "1";
						$photoData['photo_location'] = "";
						$photoData['photo_visible'] = "1";				 
						$photoData['photo_view_counter'] = "0";	
						
						#save the planet cover photo
						$photo->exchangeArray($photoData);
						$last_insert_photo_id ="";
						$last_insert_photo_id = $this->getPhotoTable()->savePhoto($photo); // label photo id
						
						if(!empty($last_insert_photo_id)){
							#remove the spaces from name
							$seo_group_name ="";
							$seo_group_name = str_replace(' ', '', $approvegroup->group_add_suggestion_name);
							#For all whitespace, use preg_replace:
							$seo_group_name = preg_replace('/\s+/', '', $approvegroup->group_add_suggestion_name);						
							
							$groupData = array();      
							$groupData['group_title'] = $approvegroup->group_add_suggestion_name;
							$groupData['group_seo_title'] = $seo_group_name;
							$groupData['group_status'] = "1";
							$groupData['group_discription'] = $approvegroup->group_add_suggestion_name;      
							$groupData['group_location'] = "";
							$groupData['group_added_ip_address'] = user::getUserIp();
							$groupData['group_parent_group_id'] = $approvegroup->group_add_suggestion_parent_group_id;
							$groupData['group_photo_id'] = $last_insert_photo_id; // label photo id
							$groupData['group_view_counter'] = "0";     
	
							#save the group(planet)
							$group = new Group();
							$group->exchangeArray($groupData); 
							$last_insert_group_id ="";
							$last_insert_group_id = $this->getGroupTable()->saveSubGroup($group); 
							
							#save user Group table and make him owner
							if(!empty($last_insert_group_id)){
								
								############################################GALAXY CHECK CODE. AUTOADD GALAXY CODE COMES HERE#############
								//Check if user has already register Galaxy or Not. If yes, then do nothing.If not. Add that galaxy
								
								
								$groupAlreadyRegisterInfo =array();
								$groupAlreadyRegisterInfo =$this->getUserGroupTable()->getUserGroup($approvegroup->group_add_suggestion_user_id, $approvegroup->group_add_suggestion_parent_group_id);					 
								
								if(isset($groupAlreadyRegisterInfo->user_group_id) && !empty($groupAlreadyRegisterInfo->user_group_id)){
									#This means user has already added this galaxy							
								}else{
									#Add this galaxy								 
									 $userGroupData = array();
									 $userGroupData['user_group_user_id'] = $approvegroup->group_add_suggestion_user_id;
									 $userGroupData['user_group_group_id'] = $approvegroup->group_add_suggestion_parent_group_id;
									 #create object of User class								  
									 $userGroupData['user_group_added_ip_address'] = user::getUserIp();
									 $userGroupData['user_group_status'] = "1";
									 $userGroupData['user_group_is_owner'] = "0";
									 #lets Save the User
									$userGroup = new UserGroup();
									$userGroup->exchangeArray($userGroupData);
									$insertedUserGroupId ="";	#this will hold the latest inserted id value
									$insertedUserGroupId = $this->getUserGroupTable()->saveUserGroup($userGroup); 	
									if(isset($insertedUserGroupId) && !empty($insertedUserGroupId)){
										 
									}else{
										$error[] = "error in saving galaxy"; 
									}							
								}						 						
								############################################GALAXY CHECK CODE. AUTOADD GALAXY CODE COMES HERE#############	
								
								
								if(count($error)){
								
								}else{ //if(count($error))
									#Lets save the Planet					
									$userGroupData = array();
									$userGroupData['user_group_user_id'] = $approvegroup->group_add_suggestion_user_id;
									$userGroupData['user_group_group_id'] = $last_insert_group_id;
									#create object of User class
									$userGroupData['user_group_added_ip_address'] = user::getUserIp();
									$userGroupData['user_group_status'] = "1";
									$userGroupData['user_group_is_owner'] = "1";
									#lets Save the User
									$userGroup = new UserGroup();
									$userGroup->exchangeArray($userGroupData);
									$insertedUserGroupId ="";	#this will hold the latest inserted id value
									$insertedUserGroupId = $this->getUserGroupTable()->saveUserGroup($userGroup);								
									
									#send the Notification to User
									$UserGroupNotificationData = array();						
									$UserGroupNotificationData['user_notification_user_id'] = $approvegroup->group_add_suggestion_user_id;								
									$UserGroupNotificationData['user_notification_content'] = "Your Add planet Request has been approved. Your Planet is <a href='".$basePath."/profile'><b>".$approvegroup->group_add_suggestion_name."</b></a>";						$UserGroupNotificationData['user_notification_added_timestamp'] = date('Y-m-d H:i:s');
									$userObject = new user(array());
									$UserGroupNotificationData['user_notification_notification_type_id'] = "1";
									$UserGroupNotificationData['user_notification_status'] = 0;															 
																	
									#lets Save the User Notification
									$UserGroupNotificationSaveObject = new UserNotification();
									$UserGroupNotificationSaveObject->exchangeArray($UserGroupNotificationData);							
									$insertedUserGroupNotificationId ="";	#this will hold the latest inserted id value
									$insertedUserGroupNotificationId = $this->getUserNotificationTable()->saveUserNotification($UserGroupNotificationSaveObject);							
									return $this->redirect()->toRoute('admin/admin-planet',  array('action'=>'edit', 'id' => $last_insert_group_id));
								} //else if(count($error))							
							}else{ //if(!empty($last_insert_group_id))		
								//error in saving group
								$error[] = "error in saving Planet";
							}
										
						}else{ //if(!empty($last_insert_photo_id))			 
							//error in saving photo
							$error[] = "error in saving photo";
						}				
					}else{ //if($this->getUserGroupAddSuggestionTable()->saveUserGroupAddSuggestionForApproval($userGroupAddSuggest))					
						//Error in Saving.  
						$error[] = "error in saving Suggest Planet name";
					} //else of //if($this->getUserGroupAddSuggestionTable()->saveUserGroupAddSuggestionForApproval($userGroupAddSuggest))					
				} //else of if(isset($groupData->group_id) && !empty($groupData->group_id))			 
            } //if ($del == 'Approve')         
        }
	 
        return array(
            'id' => $id,
            'approvegroup' => $approvegroup,		 
			'error' => $error, 
			'success' => $success, 
			'flashMessages' => $this->flashMessenger()->getMessages(),
        );
    }	

	#reject the Suggest Planet
	 public function rejectplanetAction()
    {
		$error = array();
		$success = array();	#success message variable
	
	    $id = (int)$this->params('id');
        if (!$id) {
            return $this->redirect()->toRoute('admin/admin-planet');
        }
		
		$approvegroup =array();
		$approvegroup =$this->getUserGroupAddSuggestionTable()->getUserGroupAddSuggestion($id);
		if(isset($approvegroup->group_add_suggestion_id) && !empty($approvegroup->group_add_suggestion_id)){
			
		}else{
			return $this->redirect()->toRoute('admin/admin-planet', array('action'=>'approvelist'));
		}
		
        $request = $this->getRequest();
        if ($request->isPost()) {
            $del = $request->getPost()->get('del', 'No');
			  if ($del == 'Reject') {
                $id = (int)$request->getPost()->get('id');
				
				#reject the request 
				#approve the Request
					$userGroupAddSuggestData = array();
					$userGroupAddSuggestData['group_add_suggestion_id'] = $approvegroup->group_add_suggestion_id;
					$userGroupAddSuggestData['group_add_suggestion_user_id'] = $approvegroup->group_add_suggestion_user_id;
					$userGroupAddSuggestData['group_add_suggestion_name'] = $approvegroup->group_add_suggestion_name;
					$userGroupAddSuggestData['group_add_suggestion_parent_group_id'] = $approvegroup->group_add_suggestion_parent_group_id;
					#create object of User class
					$user = new User();
					$userGroupAddSuggestData['group_add_suggestion_added_ip_address'] = $user->getUserIp();				
					#reject User Suggestion
					$userGroupAddSuggest = new UserGroupAddSuggestion();
					$userGroupAddSuggest->exchangeArray($userGroupAddSuggestData);
					if($this->getUserGroupAddSuggestionTable()->saveUserGroupAddSuggestionForReject($userGroupAddSuggest)){
						//Rejected Successfully done
						return $this->redirect()->toRoute('admin/admin-planet',  array('action'=>'approvelist'));
					}else{ //if($this->getUserGroupAddSuggestionTable()->saveUserGroupAddSuggestionForReject($userGroupAddSuggest))
						//Error
						$error[] = "error in Rejecting Planet.Please try again";
					} //else of if($this->getUserGroupAddSuggestionTable()->saveUserGroupAddSuggestionForReject($userGroupAddSuggest))
				 
				 
            }
            
        }
	 
        return array(
            'id' => $id,
            'approvegroup' => $approvegroup,		 
			'error' => $error, 'success' => $success, 'flashMessages' => $this->flashMessenger()->getMessages()

        );
    }	
	
	 public function deletesuggestplanetAction()
    {
		$error = array();
		$success = array();	#success message variable
	
	    $id = (int)$this->params('id');
        if (!$id) {
           return $this->redirect()->toRoute('admin/admin-planet',  array('action'=>'approvelist'));
        }
		
		$approvegroup =array();
		$approvegroup =$this->getUserGroupAddSuggestionTable()->getUserGroupAddSuggestion($id);
		if(isset($approvegroup->group_add_suggestion_id) && !empty($approvegroup->group_add_suggestion_id)){
			
		}else{
			return $this->redirect()->toRoute('admin/admin-planet', array('action'=>'approvelist'));
		}

        $request = $this->getRequest();
        if ($request->isPost()) {
            $del = $request->getPost()->get('del', 'No');
            if ($del == 'Yes') {
                $id = (int)$request->getPost()->get('id');
				$this->getUserGroupAddSuggestionTable()->deleteUserGroupAddSuggestion($id); //delete actual planet
            }
            // Redirect to list of tags
            return $this->redirect()->toRoute('admin/admin-planet',  array('action'=>'approvelist'));
        }
	 
        return array(
            'id' => $id,
            'approvegroup' => $approvegroup,		 
			'error' => $error, 'success' => $success, 'flashMessages' => $this->flashMessenger()->getMessages()
        );
    }	
	
	
	
	#accessing the user table module
	public function getUserTable()
    {
        if (!$this->userTable) {
            $sm = $this->getServiceLocator();
            $this->userTable = $sm->get('User\Model\UserTable');
        }
        return $this->userTable;
    }
	
	#accessing the user profile table module
	public function getUserProfileTable()
    {
        if (!$this->userProfileTable) {
            $sm = $this->getServiceLocator();
            $this->userProfileTable = $sm->get('User\Model\UserProfileTable');
        }
        return $this->userProfileTable;
    }
	
	#Accessing the tag table
	public function getGroupTable()
    {
        if (!$this->groupTable) {
            $sm = $this->getServiceLocator();
            $this->groupTable = $sm->get('Group\Model\GroupTable');
        }
        return $this->groupTable;
    }
	
	#access User Galaxy/Planet Module
	 public function getUserGroupTable()
    {
        if (!$this->userGroupTable) {
            $sm = $this->getServiceLocator();
			$this->userGroupTable = $sm->get('Group\Model\UserGroupTable');
        }
        return $this->userGroupTable;
    }  
	
	#access User Notification
    public function getUserNotificationTable()
    {
        if (!$this->userNotificationTable) {
            $sm = $this->getServiceLocator();
            $this->userNotificationTable = $sm->get('Notification\Model\UserNotificationTable');
        }
        return $this->userNotificationTable;
    }
	
	#Accessing the Group tag table
	public function getPhotoTable()
    {
        if (!$this->photoTable) {
            $sm = $this->getServiceLocator();
            $this->photoTable = $sm->get('Photo\Model\PhotoTable');
        }
        return $this->photoTable;
    }
	
	#access User Notification
    public function getUserGroupAddSuggestionTable()
    {
        if (!$this->userGroupAddSuggestionTable) {
            $sm = $this->getServiceLocator();
            $this->userGroupAddSuggestionTable = $sm->get('Group\Model\UserGroupAddSuggestionTable');
        }
        return $this->userGroupAddSuggestionTable;
    } 	
	
}