<?php
namespace Notification\Controller;

use Zend\Mvc\Controller\AbstractActionController;
use Zend\View\Model\ViewModel;	//Return model 
use Zend\Session\Container; // We need this when using sessions
use Zend\Authentication\AuthenticationService;
use Zend\Authentication\Adapter\DbTable as AuthAdapter;
/*use Zend\Authentication\Result as Result;
use Zend\Authentication\Storage;*/
 
//Login Form
use Notification\Form\Notification;       // <-- Add this import
use Notification\Form\NotificationFilter;   

#Notification class
use Notification\Model\Notification;  
use Notification\Model\NotificationTable; 

class NotificationController extends AbstractActionController
{
    protected $NotificationTable;		
  	  
    public function indexAction()
    {
	
    }
	 
}