<?php  
namespace Admin\Controller; 
use Zend\Mvc\Controller\AbstractActionController;
use Zend\View\Model\ViewModel;	//Return model 
use Zend\Session\Container; // We need this when using sessions     
use Zend\Authentication\AuthenticationService;
use Zend\Authentication\Adapter\DbTable as AuthAdapter;
use Zend\Db\Sql\Select;	#This is use for custom search, pagination, sorting
use Zend\Validator\File\Size;
/*use Zend\Authentication\Result as Result;
use Zend\Authentication\Storage;*/ 
#Tag classs
use User\Model\User;
use Photo\Model\Photo;
use Group\Model\Group;
use Admin\Form\AdminGalaxyForm;
use Admin\Form\AdminGalaxyEditForm;
use Admin\Form\AdminGalaxyFilter;   
use Admin\Form\AdminGalaxyEditFilter;    
class AdminGalaxyController extends AbstractActionController
{   
	protected $userTable;			#variable to hold the User model configuration 
	protected $userProfileTable;	#variable to hold the User Profile model configuration 
	protected $groupTable;			#variable to hold the  Group model configuration 
	protected $userGroupTable;		#variable to hold the User Group model configuration 
	protected $photoTable;			#variable to hold the Photo table
	protected $activityTable;		#variable to hold the Activity table
	protected $groupThumb ="";			//Image path of Group Standard Time line
	protected $Group_Timeline_Path="";	//Image path of Group Time line
	protected $Group_Thumb_Smaller ="";	//Image path of Group small Thumb
	protected $Group_Minumum_Bytes ="";	//Image path of Group small Thumb
	
	
	public function __construct()
    { 
        // do some stuff!
		$this->groupThumb = Group::Group_Thumb_Path;  
		$this->Group_Timeline_Path = Group::Group_Timeline_Path;  
		$this->Group_Thumb_Smaller = Group::Group_Thumb_Smaller;  		
		$this->Group_Minumum_Bytes = Group::Group_Minumum_Bytes;  		  
    }   
   
 	#Displaying Tag Grid
    public function indexAction()
    {		 
		$error = array();	#Error variable
		$success = array();	#success message variable
				
		$select = new Select();
        $order_by = $this->params()->fromRoute('order_by') ?  $this->params()->fromRoute('order_by') : 'group_id';
        $order = $this->params()->fromRoute('order') ? $this->params()->fromRoute('order') : Select::ORDER_ASCENDING;
        $select->order($order_by . ' ' . $order);		
		
		#fetch all the group
		$allGroupData = array();	
		$allGroupData = $this->getGroupTable()->fetchAllGroups();	
		  
        return array('allGroupData' => $allGroupData,'order_by' => $order_by,'order' => $order,'error' => $error, 'success' => $success, 'flashMessages' => $this->flashMessenger()->getMessages());	 
    }
	
	public function addAction()
    { 
		$error =array();	#Error variable
		$success =array();	#success message variable
		
		$sm = $this->getServiceLocator();         
		#fetch the upload path		
		$config = $this->getServiceLocator()->get('Config');

		#db connectivity
		$sm = $this->getServiceLocator();
		$dbAdapter = $sm->get('Zend\Db\Adapter\Adapter');
		
		$form = new AdminGalaxyForm();
        $form->get('submit')->setAttribute('value', 'Add');

        $request = $this->getRequest();
        if ($request->isPost()) {
			$group = new Group();
          	$form->setInputFilter(new AdminGalaxyFilter($dbAdapter));					 
           	$form->setData($request->getPost());
			$nonFile = $request->getPost()->toArray();
            $File = $this->params()->fromFiles('galaxy_image');
            $data = array_merge(
				$nonFile, //POST
                 array('fileupload'=> $File['name']) //FILE...
             );
			
            if ($form->isValid()) {                 
				$size = new Size(array('min'=>$this->Group_Minumum_Bytes)); //minimum bytes filesize
     			$adapter = new \Zend\File\Transfer\Adapter\Http();
				//validator can be more than one....Adding validtor for Size
				$adapter->setValidators(array($size), $File['name']);
				//Adding Validator for Extension
				$adapter->addValidator('Extension', false, 'jpg,png,gif');
			 
			if (!$adapter->isValid()){
				$dataError = $adapter->getMessages();
				foreach($dataError as $key=>$row)
				{
					$error[] = $row;
				} //set formElementErrors
				 
				$form->setMessages(array('fileupload'=>$error ));
			} else { //if (!$adapter->isValid())				 
				#upload The Galax Image
				$fileName ="";
				$fileName = group::uploadGroupImage('Galaxy',$File, $config['pathInfo']['UploadPath'], $adapter, $this->params()->fromPost('group_title'));
				if($fileName){
				
				}else{
					$fileName = "no-image.jpg";
				}
				#save the photo
				$photoData = array();						
				$photoData['photo_name'] = $fileName;
				$groupData['photo_added_ip_address'] = user::getUserIp();
				$photoData['photo_caption'] = $this->params()->fromPost('group_seo_title');
				$photoData['photo_status'] = "1";
				$photoData['photo_discription'] = $this->params()->fromPost('group_discription');					 
				$photoData['photo_added_ip_address'] = user::getUserIp();	
				$photoData['photo_user_id'] = "1";
				$photoData['photo_location'] = "";
				$photoData['photo_visible'] = "1";				 
				$photoData['photo_view_counter'] = "0";	
				$photo = new Photo();
				$photo->exchangeArray($photoData);	
				$insertedPhotoId ="";					
				$insertedPhotoId = $this->getPhotoTable()->savePhoto($photo);	 
					
				if(!empty($insertedPhotoId)){
					$groupData = array();						
					$groupData['group_id'] = $this->params()->fromPost('group_id');
					$groupData['group_title'] = $this->params()->fromPost('group_title');
					$groupData['group_seo_title'] = $this->params()->fromPost('group_seo_title');
					$groupData['group_status'] = "1";
					$groupData['group_discription'] = $this->params()->fromPost('group_discription');					 
					$groupData['group_location'] = $this->params()->fromPost('group_location');
					$groupData['group_added_ip_address'] = user::getUserIp();
					//$groupData['group_photo_id'] = InsertedPhotoId;
					$groupData['group_photo_id'] = $insertedPhotoId;
					$groupData['group_view_counter'] = "0";					 
					 #save the group
					 $group->exchangeArray($groupData);	
					 $this->getGroupTable()->saveGroup($group);					  
					return $this->redirect()->toRoute('admin/admin-galaxy');
				} //if(!empty($insertedUserId))			
			}//else of if (!$adapter->isValid())			 
			 
            }//if ($form->isValid())
        } //if ($request->isPost())
        return array('form' => $form, 'error' => $error, 'success' => $success, 'flashMessages' => $this->flashMessenger()->getMessages());
    }

    public function editAction()
    {
        $error =array();	#Error variable
		$success =array();	#success message variable
		//echo "<li>".$this->groupThumb;exit;
		#db connectivity
		$sm = $this->getServiceLocator();
		$dbAdapter = $sm->get('Zend\Db\Adapter\Adapter');
		$config = $this->getServiceLocator()->get('Config');
		
		$id = (int)$this->params('id');
        if (!$id) {
            return $this->redirect()->toRoute('admin/admin-galaxy', array('action'=>'add'));
        }
        
		$group =array();
		$group = $this->getGroupTable()->getGroup($id); #Get Group Details			
		if(isset($group->group_id) && !empty($group->group_id)){
			
		}else{
			return $this->redirect()->toRoute('admin/admin-galaxy', array('action'=>'index'));
		}
			
		$groupPhoto =array();
		$groupPhoto = $this->getPhotoTable()->getPhoto($group->group_photo_id);
		
		$form = new AdminGalaxyEditForm();
        $form->bind($group);
        $form->get('submit')->setAttribute('value', 'Edit');
        
        $request = $this->getRequest();
        if ($request->isPost()) {
			$group = new Group();
          	$form->setInputFilter(new AdminGalaxyEditFilter($dbAdapter, $id));					 
           	$form->setData($request->getPost());
			$nonFile = $request->getPost()->toArray();
            $File = $this->params()->fromFiles('galaxy_image');
            $data = array_merge(
				$nonFile, //POST
                 array('fileupload'=> $File['name']) //FILE...
             );      
			 
			 
			 $addGroup = false; 	#this will tell whether to add group or not		
			 $group_photo_id ="";	 
			 if ($form->isValid()) { 				  
				 if(isset($File['name']) && !empty($File['name'])){				 	
					####################################### IF user has upload New File###########################################
					$size = new Size(array('min'=>$this->Group_Minumum_Bytes)); //minimum bytes filesize
     				$adapter = new \Zend\File\Transfer\Adapter\Http();					
					$adapter->setValidators(array($size), $File['name']);//validator can be more than one....Adding validtor for Size
					$adapter->addValidator('Extension', false, 'jpg,png,gif');//validattion for extension
					if (!$adapter->isValid()){
						#error in file Upload
						$dataError = $adapter->getMessages();
						echo "<pre>";print_r($adapter);exit;
						foreach($dataError as $key=>$row)
						{
							$error[] = $row;
						} //set formElementErrors
						$addGroup = false; //stop adding grouo since there is a error in file upload
						$form->setMessages(array('fileupload'=>$error ));
					}else{ //if (!$adapter->isValid())
						#no error. Upload the file
						 
						$fileName ="";
						$fileName = group::uploadGroupImage('Galaxy',$File, $config['pathInfo']['UploadPath'], $adapter, $this->params()->fromPost('group_title'));
						 
						
						 
						if($fileName){
							//do nothing.
						}else{ //if($fileName)
							$fileName = "no-image.jpg";
						} //else of if($fileName)	
						
						#save the photo
						$photoData = array();						
						$photoData['photo_name'] = $fileName;
						$groupData['photo_added_ip_address'] = user::getUserIp();
						$photoData['photo_caption'] = $this->params()->fromPost('group_seo_title');
						$photoData['photo_status'] = "1";
						$photoData['photo_discription'] = $this->params()->fromPost('group_discription');					 
						$photoData['photo_added_ip_address'] = user::getUserIp();	
						$photoData['photo_user_id'] = "1";
						$photoData['photo_location'] = "";
						$photoData['photo_visible'] = "1";				 
						$photoData['photo_view_counter'] = "0";	
						$photo = new Photo();
						$photo->exchangeArray($photoData);	
						$group_photo_id ="";					
						$group_photo_id = $this->getPhotoTable()->savePhoto($photo);	
						
						$addGroup = true; 			
					} //else of if (!$adapter->isValid())					 								 
				 }else{ //if(isset($File['name']) && !empty($File['name']))
					########################################If User has not Upload Any fiile#######################################
					$addGroup = true; 
					$group_photo_id = $this->params()->fromPost('group_photo_id');
				 } //else of  if(isset($File['name']) && !empty($File['name']))
				  
				 if($addGroup==true){
				 	#start adding Group	
					$groupData = array();						
					$groupData['group_id'] = $this->params()->fromPost('group_id');
					$groupData['group_title'] = $this->params()->fromPost('group_title');
					$groupData['group_seo_title'] = $this->params()->fromPost('group_seo_title');
					$groupData['group_status'] = "1";
					$groupData['group_discription'] = $this->params()->fromPost('group_discription');					 
					$groupData['group_location'] = $this->params()->fromPost('group_location');
					$groupData['group_added_ip_address'] = user::getUserIp();
					//$groupData['group_photo_id'] = InsertedPhotoId;
					$groupData['group_photo_id'] = $group_photo_id;
					$groupData['group_view_counter'] = "0";					 
					#save the group
					$group->exchangeArray($groupData);	
					$this->getGroupTable()->saveGroup($group);					  
					return $this->redirect()->toRoute('admin/admin-galaxy');			 
				 }//if($$addGroup==true) 			 	
			 } //if ($form->isValid()) 			 
		} //if ($request->isPost())	 

        return array(
            'id' => $id,
            'form' => $form,
			'group' => $group,
			'groupPhoto' => $groupPhoto,
			'groupThumb' => $this->groupThumb,			
			'error' => $error, 
			'success' => $success,
			'flashMessages' => $this->flashMessenger()->getMessages(),		
        );
    }

    public function deleteAction()
    {
      	$error =array();	#Error variable
		$success =array();	#success message variable
		
	    $id = (int)$this->params('id');
        if (!$id) {
            return $this->redirect()->toRoute('admin/admin-galaxy');
        }
		$group =array();
		$group = $this->getGroupTable()->getGroup($id); #Get Group Details			
		if(isset($group->group_id) && !empty($group->group_id)){
			
		}else{
			return $this->redirect()->toRoute('admin/admin-galaxy', array('action'=>'index'));
		}

        $request = $this->getRequest();
        if ($request->isPost()) {
            $del = $request->getPost()->get('del', 'No');
            if ($del == 'Yes') {
                $id = (int)$request->getPost()->get('id');
                $this->getGroupTable()->deleteGroup($id);
            }

            // Redirect to list of groups
            return $this->redirect()->toRoute('admin/admin-galaxy');
        }
	 
        return array(
            'id' => $id,
            'group' => $group,
			'usersList' => $this->getUserGroupTable()->fetchAllUserForGeneralGroup($id),	#check if there is any users
			'activityList' => $this->getActivityTable()->getGroupAllActivity($id),	#check if there is any activity		
			'error' => $error, 'success' => $success, 'flashMessages' => $this->flashMessenger()->getMessages()
        );
    }	 
	
	#accessing the user table module
	public function getUserTable()
    {
        if (!$this->userTable) {
            $sm = $this->getServiceLocator();
            $this->userTable = $sm->get('User\Model\UserTable');
        }
        return $this->userTable;
    }
	
	#accessing the user profile table module
	public function getUserProfileTable()
    {
        if (!$this->userProfileTable) {
            $sm = $this->getServiceLocator();
            $this->userProfileTable = $sm->get('User\Model\UserProfileTable');
        }
        return $this->userProfileTable;
    }
	 
	#Accessing the Group table
	public function getGroupTable()
    {
        if (!$this->groupTable) {
            $sm = $this->getServiceLocator();
            $this->groupTable = $sm->get('Group\Model\GroupTable');
        }
        return $this->groupTable;
    }
	
	#Accessing the user Group table
	public function getUserGroupTable()
    {
        if (!$this->userGroupTable) {
            $sm = $this->getServiceLocator();
            $this->userGroupTable = $sm->get('Group\Model\UserGroupTable');
        }
        return $this->userGroupTable;
    }	
	
	#Accessing the Photo table
	public function getPhotoTable()
    {       
		if (!$this->photoTable) {
            $sm = $this->getServiceLocator();
            $this->photoTable = $sm->get('Photo\Model\PhotoTable');
        }
        return $this->photoTable;
    }	
	
	#Accessing the Activity table
	public function getActivityTable()
    {       
		if (!$this->activityTable) {
            $sm = $this->getServiceLocator();
            $this->photoTable = $sm->get('Activity\Model\ActivityTable');
        }
        return $this->photoTable;
    } 
}