<?php
namespace Admin\Controller; 
use Zend\Mvc\Controller\AbstractActionController;
use Zend\View\Model\ViewModel;	//Return model 
use Zend\Session\Container; // We need this when using sessions     
use Zend\Authentication\AuthenticationService;
use Zend\Authentication\Adapter\DbTable as AuthAdapter;
use Zend\Db\Sql\Select;
use Zend\Validator\File\Size;
/*use Zend\Authentication\Result as Result;
use Zend\Authentication\Storage;*/ 
#Tag classs
use Tag\Model\Tag;
use Group\Model\Group;
use Photo\Model\Photo;
use User\Model\User; 
use Activity\Model\Activity;
use Activity\Model\ActivityTable;

  
class AdminActivityController extends AbstractActionController
{   
	
    protected $adminActivityTable;
	protected $userTable;			#variable to hold the User model configuration 
	protected $groupTable;			#variable to hold the group model configuration 
	protected $userProfileTable;	#variable to hold the User Profile model configuration 
	protected $tagTable;			#variable to hold the Tag configuration 
	protected $groupTagTable;		#variable to hold the Group Tag model configuration 
	protected $userTagTable;		#variable to hold the User Tag model configuration
	protected $photoTable;		    #variable to hold the Photo model configuration
	protected $Group_Thumb_Path = "";	//Image path of Group Timelime
	protected $Group_Timeline_Path = "";	//Image path of Group Timelime
	protected $Group_Thumb_Smaller = "";	//Image path of Group small Thumb
	protected $Group_Minumum_Bytes = "";	//Image path of Group small Thumb
	
	public function __construct()
    {
	         // do some stuff!

	
    }
	
   
 	#Displaying Tag Grid
    public function indexAction()
    {
		 $title = 'List Activity';
		$sm = $this->getServiceLocator();
		$adminActivityTable = $sm->get('Activity\Model\ActivityTable');
		$all_activity = array();	
		$all_activity = $adminActivityTable->fetchAll();
        return array('all_activity' => $all_activity, 
						'title' => $title, 
						'flashMessages' => $this->flashMessenger()->getMessages(),
					);	 
    }
	public function viewAction()
	{   $title = 'View Activity';
	    $sm = $this->getServiceLocator();
		$adminActivityTable = $sm->get('Activity\Model\ActivityTable');
		
	    $id = (int)$this->params('id'); 
		 if (!$id) {
            return $this->redirect()->toRoute('admin/admin-activity', array('action'=>'index'));
        }
		
		$view_activity = array();	
		$view_activity = $adminActivityTable->Admin_get_activity($id);
		return array('view_activity' => $view_activity , 'title' => $title );
	}
	public function blockAction()
	{
	   $sm = $this->getServiceLocator();
		$adminActivityTable = $sm->get('Activity\Model\ActivityTable');
		
	    $id = (int)$this->params('id'); 
		 if (!$id) {
            return $this->redirect()->toRoute('admin/admin-activity', array('action'=>'index'));
        }
		
		if($adminActivityTable->Admin_block_activity($id) == 'success')
		{  
		   $alert_content = 'Activity '.$id.' hasbeen blocked !';
		   $msg = array('type'=>'success',
		                'message'=>$alert_content,
		               );
		   $this->flashMessenger()->addMessage($msg);
		   
		   return $this->redirect()->toRoute('admin/admin-activity', array('action'=>'index'));
		}else{
		   $msg = array('type'=>'error',
		                'message'=>'Sorry some error occured !',
		               );
		   $this->flashMessenger()->addMessage($msg);
		   return $this->redirect()->toRoute('admin/admin-activity', array('action'=>'index'));
		}
		
	}  
	public function unblockAction()
	{ 
	   $sm = $this->getServiceLocator();
		$adminActivityTable = $sm->get('Activity\Model\ActivityTable');
		
	   echo $id = (int)$this->params('id'); 
	
		 if (!$id) {
            return $this->redirect()->toRoute('admin/admin-activity', array('action'=>'index'));
        }
		
		if($adminActivityTable->Admin_unblock_activity($id) == 'success')
		{  
		   $alert_content = 'Activity '.$id.' hasbeen unblocked !';
		   $msg = array('type'=>'success',
		                'message'=>$alert_content,
		               );
		   $this->flashMessenger()->addMessage($msg);
		  
		   return $this->redirect()->toRoute('admin/admin-activity', array('action'=>'index'));
		}else{
		   $msg = array('type'=>'error',
		                'message'=>'Sorry some error occured !',
		               );
		   $this->flashMessenger()->addMessage($msg);
		   return $this->redirect()->toRoute('admin/admin-activity', array('action'=>'index'));
		}
		
	}
	 //==============================================Delete Activity==========================================================
    public function deleteAction(){
	    $id = (int)$this->params('id'); 
	    $sm = $this->getServiceLocator();
		$adminActivityTable = $sm->get('Activity\Model\ActivityTable');
		
		 if (!$id) {
            return $this->redirect()->toRoute('admin/admin-activity', array('action'=>'index'));
        }
		if($adminActivityTable->deleteActivity($id) == 'success')
		{  
		   $alert_content = 'Activity '.$id.' hasbeen Deleted !';
		   $msg = array('type'=>'success',
		                'message'=>$alert_content,
		               );
		   $this->flashMessenger()->addMessage($msg);
		  
		   return $this->redirect()->toRoute('admin/admin-activity', array('action'=>'index'));
		}else{
		   $msg = array('type'=>'error',
		                'message'=>'Sorry some error occured !',
		               );
		   $this->flashMessenger()->addMessage($msg);
		   return $this->redirect()->toRoute('admin/admin-activity', array('action'=>'index'));
		}

	}
	
}