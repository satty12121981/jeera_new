<?php
namespace Like\Model;
use Zend\Db\Sql\Select;
use Zend\Db\TableGateway\AbstractTableGateway;
use Zend\Db\TableGateway\TableGateway;
use Zend\Db\TableGateway\Feature\RowGatewayFeature;
use Zend\Db\Adapter\Adapter;
use Zend\Db\ResultSet\ResultSet;
class LikeTable extends AbstractTableGateway
{ 
    protected $table = 'y2m_like'; 
	
    public function __construct(Adapter $adapter)
    {
        $this->adapter = $adapter;
        $this->resultSetPrototype = new ResultSet();
        $this->resultSetPrototype->setArrayObjectPrototype(new Like());
        $this->initialize();
    }

	// this function will fetch likes count by reference
    public function fetchLikesCountByReference($LikeTypeId,$ReferenceId)
    {
		$LikeTypeId  = (int) $LikeTypeId;
		$ReferenceId  = (int) $ReferenceId;
		$select = new Select;
		$select->columns(array('likes_counts' => new \Zend\Db\Sql\Expression('COUNT(*)')))
			->from('y2m_like')
			->where(array('y2m_like.like_system_type_id' => $LikeTypeId,'y2m_like.like_refer_id' => $ReferenceId))
			->order(array('y2m_like.like_system_type_id ASC'));
		
		$statement = $this->adapter->createStatement();
		$select->prepareStatement($this->adapter, $statement);
		$resultSet = new ResultSet();
		$resultSet->initialize($statement->execute());	
		$row = $resultSet->current();
		return $row['likes_counts'];
    }
	
	// this function will check against user of the system like exists already
	public function LikeExistsCheck($LikeTypeId,$ReferenceId,$UserId) {
	
        $LikeTypeId  = (int) $LikeTypeId;
		$ReferenceId  = (int) $ReferenceId;
		$UserId  = (int) $UserId;
        $rowset = $this->select(array('like_system_type_id' => $LikeTypeId,'like_refer_id'=>$ReferenceId,'like_by_user_id'=>$UserId));
        $row = $rowset->current();
        return $row;
	}
	
	// this function will fetch by ref
    public function fetchLikesUsersByReference($LikeTypeId,$ReferenceId)
    {
		$LikeTypeId  = (int) $LikeTypeId;
		$ReferenceId  = (int) $ReferenceId;
		$select = new Select;
		$select->from('y2m_like')
			->join('y2m_system_type', 'y2m_like.like_system_type_id = y2m_system_type.system_type_id')
			->join('y2m_user', 'y2m_like.like_by_user_id = y2m_user.user_id')
			->join('y2m_photo', 'y2m_photo.photo_id = y2m_user.user_profile_photo_id')
			->where(array('y2m_like.like_system_type_id' => $LikeTypeId,'y2m_like.like_refer_id' => $ReferenceId))
			->order(array('y2m_like.like_system_type_id ASC'));
		$statement = $this->adapter->createStatement();
		$select->prepareStatement($this->adapter, $statement);
		//echo $select->getSqlString(); 
		$resultSet = new ResultSet();
		$resultSet->initialize($statement->execute());	  
		
		return $resultSet;
    }
	
	// this will fetch single like from table
    public function getLike($like_id)
    {
        $like_id  = (int) $like_id;
        $rowset = $this->select(array('like_id' => $like_id));
        $row = $rowset->current();
        return $row;
    }
	
	// this will save Like in a table
    public function saveLike(Like $Like)
    {
       $data = array(
            'like_system_type_id' => $Like->like_system_type_id,
            'like_by_user_id'  => $Like->like_by_user_id,
			'like_status'  => $Like->like_status,
			'like_added_timestamp'  => $Like->like_added_timestamp,
			'like_added_ip_address'  => new \Zend\Db\Sql\Expression("INET_ATON('" . $Like->like_added_ip_address . "')"),
			'like_refer_id'  => $Like->like_refer_id
        );

        $like_id = (int)$Like->like_id;
        if ($like_id == 0) {
            $this->insert($data);
			return $this->adapter->getDriver()->getConnection()->getLastGeneratedValue();
        } else {
            if ($this->getLike($like_id)) {
                $this->update($data, array('like_id' => $like_id));
            } else {
                throw new \Exception('Like id does not exist');
            }
        }
    }
	
	// it will delete any Like
    public function deleteLike($like_id)
    {
        $this->delete(array('like_id' => $like_id));
    }
	
	// it will delete any Like
    public function deleteLikeByReference($like_system_type_id,$like_by_user_id,$like_refer_id)
    {
        return $this->delete(array('like_system_type_id' => $like_system_type_id,'like_by_user_id' => $like_by_user_id,'like_refer_id' => $like_refer_id));
    }
	
}