<?php
####################Comment Controller #################################

namespace Comment\Controller;

use Zend\Mvc\Controller\AbstractActionController;
use Zend\View\Model\ViewModel;	//Return model 
use Zend\Session\Container; // We need this when using sessions     
use Zend\Authentication\AuthenticationService;	//Needed for checking User session
use Zend\Authentication\Adapter\DbTable as AuthAdapter;	//Db apapter
use Zend\Crypt\BlockCipher;		# For encryption
/*use Zend\Authentication\Result as Result;
use Zend\Authentication\Storage;*/
 
#Group classs
use Groups\Model\Groups;  
use Groups\Model\GroupsTable; 
use Discussion\Model\Discussion;  
use Discussion\Model\DiscussionTable; 
use Album\Model\Album;  
use Album\Model\AlbumTable; 
use Activity\Model\Activity;  
use Activity\Model\ActivityTable; 
use Comment\Model\Comment;  
use Comment\Model\CommentTable; 
use \Exception;		#Exception class for handling exception
#Group Suggestion add form
use Comment\Form\CommentForm;
use Comment\Form\CommentFilter;  


use Zend\View\Helper\HelperInterface;
use Zend\View\Renderer\RendererInterface;

class CommentController extends AbstractActionController
{     
	protected $userTable;
	protected $groupTable;
	protected $userGroupTable;

	protected $photoTable = ""; 
	protected $activityTable = ""; 
	protected $discussionTable = ""; 
	protected $albumTable = ""; 
	protected $commentTable ="";
	
	public function __construct(){
		return $this;
	}
	
	#this function will load the css and javascript need for perticular action
	protected function getViewHelper($helperName)
	{
    	return $this->getServiceLocator()->get('viewhelpermanager')->get($helperName);
	}
   
 	#This will load all Groups   
    public function indexAction()
    {		
		$allComments = array();	//this will keep the all groups of database
		$identity = "";			//This will check user is logged in or not		
		$userGroups = array();	//	This will hold the Data of Register User Groups
		$userGroupsIds = array();//	This will hold the ids of Register User Groups
		
		try {
			$request   = $this->getRequest();							
			$auth = new AuthenticationService();	
			#pass the group Image Oath. We need to show thumb image here
			$identity = null;        
			if ($auth->hasIdentity()) {
				// Identity exists; get it
				$identity = $auth->getIdentity();
				$this->layout()->identity = $identity;	//assign Identity to layout 		
				$userData =array();	///this will hold data from y2m_user table				 				
				$userData = $this->getUserTable()->getUser($identity->user_id);	#check the identity againts the DB	
				if(isset($userData->user_id) && !empty($userData->user_id)){				
					#fetch all groups
					$allComments = $this->getCommentTable()->fetchAllComments();	
				} 
			} 
			$this->layout()->identity = $identity;	//assign Identity to layout  	
		} catch (\Exception $e) {
	        echo "Caught exception: " . get_class($e) . "\n";
   			echo "Message: " . $e->getMessage() . "\n";exit;
		}
		
		$viewModel = new ViewModel(array('allGroups' => $allGroups, 'groupThumb' => $this->groupThumb));
		$viewModel->setTerminal($request->isXmlHttpRequest());
		
    	return $viewModel;          
	}
	public function ajaxAction(){
		echo "here";die();
	}
	#This will load all Subgroups Of Group   
	function CommentsAction(){		
		$error = array();	#Error variable
		$success = array();	#success message variable		
		$GroupId = "";
		$SubGroupId = "";	//This will hold the galaxy id
		$GroupReferId = ""; 
		$SystemTypeId = ""; 				
		$auth = new AuthenticationService(); 
		$userData = array();	//this will hold data from y2m_user table
		$groupData = array();//this will hold the Galaxy data
		$SubGroupData = array();//this will hold the Planet data
		$ModuleCommentsData = array();//this will hold the Planet data
		$request   = $this->getRequest();		
		$post = $request->getPost();
		$GroupId = $post['group_id']; 				
		$SubGroupId = $post['planet']; 
		$GroupReferId = $post['content_id']; 			
		$SystemTypeId = $post['type']; 	 
		$sm = $this->getServiceLocator();	
		$auth = new AuthenticationService();	
		$identity = null;   
		if ($auth->hasIdentity()) {
			// Identity exists get it
			$identity = $auth->getIdentity();				
			#fetch the user Galaxy
				
			$this->userTable = $sm->get('User\Model\UserTable');	
			
			#check the identity against the DB
			$userData = $this->userTable->getUser($identity->user_id);			
		 
			if(isset($userData->user_id) && !empty($userData->user_id) && isset($GroupId) && !empty($GroupId) && isset($SubGroupId) && !empty($SubGroupId)) {
				$this->groupTable = $sm->get('Groups\Model\GroupsTable');	
				
				#get Group Info
				$SubGroupData = $this->groupTable->getSubGroupForSEO($SubGroupId);

				#fetch the Galaxy Info
				$groupData = $this->groupTable->getGroup($SubGroupData->group_parent_group_id);	

				$this->commentTable = $sm->get('Comment\Model\CommentTable');					
				
				$SystemTypeData = $this->groupTable->fetchSystemType($SystemTypeId);

				$LikeTypeData = $this->groupTable->fetchSystemType('comment');
				
				$module_id = null;
				#fetch the planet's module details
				switch ($SystemTypeId) {
					case 'discussion':
						$this->discussionTable = $sm->get('Discussion\Model\DiscussionTable');
						$GroupModuleData = $this->discussionTable->getDiscussion($GroupReferId);//print_r($GroupModuleData);die();
						$moduleId = $GroupModuleData->group_discussion_group_id;
						break;
					case 'Activity':
						$this->activityTable = $sm->get('Activity\Model\ActivityTable');
						$GroupModuleData = $this->activityTable->getActivity($GroupReferId);
						$moduleId = $GroupModuleData->group_activity_group_id;
						break;
					case 'album':
						$this->albumTable = $sm->get('Album\Model\AlbumTable');
						$GroupModuleData = $this->albumTable->getGroupAlbum($GroupReferId);
						$moduleId = $GroupModuleData->group_album_group_id;
						break;
				}
				$form = new CommentForm($SystemTypeData->system_type_id,$GroupReferId); 
				
				#add discussion code
				if(isset($SubGroupData->group_id) && !empty($SubGroupData->group_id) && isset($SubGroupData->group_parent_group_id) && !empty($SubGroupData->group_parent_group_id) && isset($moduleId) && !empty($moduleId) ) {					
				
				if (isset($post['action'])&&$post['action']=='save') {
						
						$comment = new Comment();
						$form->setInputFilter(new CommentFilter());
						$form->setData($request->getPost());
						
						 if ($form->isValid()) {  						
							$comment_by_user_id = $userData->user_id;
							$comment_status = 1;
							
							$servParam = $request->getServer();
							$remoteAddr = $servParam->get('REMOTE_ADDR');
							
							#save the comments
							$commentsData = array();
							$commentsData['comment_system_type_id'] = $SystemTypeData->system_type_id;
							$commentsData['comment_by_user_id'] = $comment_by_user_id;
							$commentsData['comment_refer_id'] = $GroupReferId;
							$commentsData['comment_content'] = $post['comment_content'];
							$commentsData['comment_status'] = $comment_status;							
							#create object of User class
							$commentsData['comment_added_ip_address'] =  $remoteAddr;
							$commentsData['comment_added_timestamp'] = date("Y-m-d H:i:s");
							
							#lets Save the Comment
							$comment->exchangeArray($commentsData);
							
							$insertedcommentsId = "";	#this will hold the latest inserted id value
							$insertedcommentsId = $this->commentTable->saveComment($comment); 
							
							if(isset($insertedcommentsId) && !empty($insertedcommentsId)) {
								 $success[] = 'comments saved successfully';
							}
							else {
								 $success[] = 'Oops an error is occured while saving comments';	
							}
						 }
						 
					} 
										
					#fetch the Discussion comment of planet details
					$ModuleCommentsData = $this->commentTable->fetchCommentsByReferenceWithLikes($SystemTypeData->system_type_id,$LikeTypeData->system_type_id,$GroupReferId,$userData->user_id);	
					
				}
			}
		
		}else{
			return $this->redirect()->toRoute('user/login', array('action' => 'login'));
		}		
			

		$viewModel = new ViewModel(array('form' => $form,'userData' => $userData,'groupData' => $groupData,'SubGroupData' => $SubGroupData,'module_comments' => $ModuleCommentsData,'Group_Refer_Id' => $GroupReferId,'System_Type_Id' => $SystemTypeId, 'error' => $error, 'success' => $success, 'flashMessages' => $this->flashMessenger()->getMessages()));
		$viewModel->setTerminal($request->isXmlHttpRequest());
		return $viewModel;
	
	}
	 
}
