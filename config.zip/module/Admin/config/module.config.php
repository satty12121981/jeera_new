<?php
return array(
    'controllers' => array(
        'invokables' => array(
            'Admin\Controller\Admin' => 'Admin\Controller\AdminController',
			'Admin\Controller\AdminCountry' => 'Admin\Controller\AdminCountryController',
			'Admin\Controller\AdminTag' => 'Admin\Controller\AdminTagController',
			'Admin\Controller\AdminUserTag' => 'Admin\Controller\AdminUserTagController',
			'Admin\Controller\AdminPlanetTag' => 'Admin\Controller\AdminPlanetTagController',
			'Admin\Controller\AdminPlanet' => 'Admin\Controller\AdminPlanetController',
			'Admin\Controller\AdminGalaxy' => 'Admin\Controller\AdminGalaxyController',
			'Admin\Controller\AdminActivity' => 'Admin\Controller\AdminActivityController',
			'Admin\controller\AdminNotification'=>'Admin\controller\AdminNotificationController',
        ),
    ),
    // The following section is new and should be added to your file
    'router' => array(
        'routes' => array(
            'admin' => array(
                'type' => 'Literal',
                'priority' => 1000,
                'options' => array(
                    'route' => '/Admin',
                    'defaults' => array(
						'__NAMESPACE__' => 'Admin\Controller',
                        'controller' => 'admin',
                        'action'     => 'index',
                    ),
                ),
                'may_terminate' => true,
                'child_routes' => array(
                    'login' => array(
                        'type' => 'Literal',
                        'options' => array(
                            'route' => '/login',
                            'defaults' => array(
								'__NAMESPACE__' => 'Admin\Controller',
                                'controller' => 'admin',
                                'action'     => 'login',
                            ),
                        ),
                    ),                    
                    'logout' => array(
                        'type' => 'Literal',
                        'options' => array(
                            'route' => '/logout',
                            'defaults' => array(
								'__NAMESPACE__' => 'Admin\Controller',
                                'controller' => 'admin',
                                'action'     => 'logout',
                            ),
                        ),
                    ),
                    'admin-country' => array(
                        'type' => 'segment',
                        'options' => array(
                           	'route'    => '/country[/:action][/:id]',
							'constraints' => array(
								'action' => '[a-zA-Z][a-zA-Z0-9_-]*',
								'id'     => '[0-9]+',
							),
                            'defaults' => array(
								'__NAMESPACE__' => 'Admin\Controller',
                                'controller' => 'admincountry',
                                'action'     => 'index',
                            ),
                        ),
                    ),
                    'admin-tags' => array(
                        'type' => 'segment',
                        'options' => array(
                           	'route'    => '/tags[/:action][/:id]',
							'constraints' => array(
								'action' => '[a-zA-Z][a-zA-Z0-9_-]*',
								'id'     => '[0-9]+',
							),
                            'defaults' => array(
								'__NAMESPACE__' => 'Admin\Controller',
                                'controller' => 'admintag',
                                'action'     => 'index',
                            ),
                        ),
                    ),
					'admin-user-tags' => array(
                        'type' => 'segment',
                        'options' => array(
                           	'route'    => '/usertags[/:action][/:id]',
							'constraints' => array(
								'action' => '[a-zA-Z][a-zA-Z0-9_-]*',
								'id'     => '[0-9]+',
							),
                            'defaults' => array(
								'__NAMESPACE__' => 'Admin\Controller',
                                'controller' => 'adminusertag',
                                'action'     => 'index',
                            ),
                        ),
                    ),
					'admin-planet-tags' => array(
                        'type' => 'segment',
                        'options' => array(
                           	'route'    => '/planettags[/:action][/:id]',
							'constraints' => array(
								'action' => '[a-zA-Z][a-zA-Z0-9_-]*',
								'id'     => '[0-9]+',
							),
                            'defaults' => array(
								'__NAMESPACE__' => 'Admin\Controller',
                                'controller' => 'adminplanettag',
                                'action'     => 'index',
                            ),
                        ),
                    ),
					
                    'admin-galaxy' => array(
                        'type' => 'segment',
                        'options' => array(
                           	'route'    => '/galaxy[/:action][/:id]',
							'constraints' => array(
								'action' => '[a-zA-Z][a-zA-Z0-9_-]*',
								'id'     => '[0-9]+',
							),
                            'defaults' => array(
								'__NAMESPACE__' => 'Admin\Controller',
                                'controller' => 'admingalaxy',
                                'action'     => 'index',
                            ),
                        ),
                    ),
					'admin-planet' => array(
                        'type' => 'segment',
                        'options' => array(
                           	'route'    => '/planet[/:action][/:id]',
							'constraints' => array(
								'action' => '[a-zA-Z][a-zA-Z0-9_-]*',
								'id'     => '[0-9]+',
							),
                            'defaults' => array(
								'__NAMESPACE__' => 'Admin\Controller',
                                'controller' => 'adminplanet',
                                'action'     => 'index',
                            ),
                        ),
                    ),
					
					'admin-activity' => array(
                        'type' => 'segment',
                        'options' => array(
                           	'route'    => '/activity[/:action][/:id]',
							'constraints' => array(
								'action' => '[a-zA-Z][a-zA-Z0-9_-]*',
								'id'     => '[0-9]+',
							),
                            'defaults' => array(
								'__NAMESPACE__' => 'Admin\Controller',
                                'controller' => 'adminactivity',
                                'action'     => 'index',
                            ),
                        ),
                    ),
					'admin-notification' => array(
                        'type' => 'segment',
                        'options' => array(
                           	'route'    => '/notification[/:action][/:id]',
							'constraints' => array(
								'action' => '[a-zA-Z][a-zA-Z0-9_-]*',
								'id'     => '[0-9]+',
							),
                            'defaults' => array(
								'__NAMESPACE__' => 'Admin\Controller',
                                'controller' => 'adminnotification',
                                'action'     => 'index',
                            ),
                        ),
                    ),
					
                ),
            ),
        ),
    ),

   'view_manager' => array(

        'display_not_found_reason' => true,
        'display_exceptions'       => true,
        'doctype'                  => 'HTML5',
        'not_found_template'       => 'error/404',
        'exception_template'       => 'error/index',
        'template_map' => array(
            'Admin/layout'           => __DIR__ . '/../view/layout/admin_layout.phtml',
           
            'error/404'               => __DIR__ . '/../view/error/404.phtml',
            'error/index'             => __DIR__ . '/../view/error/index.phtml',
        ),

        'template_path_stack' => array(
            'Admin' => __DIR__ . '/../view',
        ),
      ),
	  'module_layouts' => array(
      'Admin' => array(
          'default' => 'layout/admin_layout',
         // 'edit'    => 'layout/albumEdit',
        )
     ),

);

