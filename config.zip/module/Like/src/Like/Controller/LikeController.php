<?php
####################Like Controller #################################
#namespace for module like
namespace Like\Controller;
#library uses
use Zend\Mvc\Controller\AbstractActionController;
use Zend\View\Model\ViewModel;	//Return model 
use Zend\View\Model\JsonModel;
use Zend\Session\Container;		// We need this when using sessions     
use Zend\Authentication\AuthenticationService;		//Needed for checking User session
use Zend\Authentication\Adapter\DbTable as AuthAdapter;		//Db adapter
use Zend\Crypt\BlockCipher;		# For encryption

/*use Zend\Authentication\Result as Result;
use Zend\Authentication\Storage;*/
 
#Model uses
use User\Model\User; 
use User\Model\UserTable; 
use Groups\Model\Groups;  
use Groups\Model\GroupsTable; 
use Discussion\Model\Discussion;  
use Discussion\Model\DiscussionTable; 
use Album\Model\Album;  
use Album\Model\AlbumTable; 
use Activity\Model\Activity;  
use Activity\Model\ActivityTable; 
use Comment\Model\Comment; 
use Comment\Model\CommentTable; 
use Like\Model\Like;  
use Like\Model\LikeTable; 
use \Exception;		#Exception class for handling exception

#Group Module like uses
use Like\Form\LikeForm;
use Like\Form\LikeFilter;  

class LikeController extends AbstractActionController
{     
	protected $userTable;
	protected $groupTable;
	protected $userGroupTable;

	protected $photoTable = ""; 
	protected $activityTable = ""; 
	protected $discussionTable = "";
	protected $commentTable = ""; 
	protected $albumTable = ""; 
	protected $LikeTable = "";
	protected $remoteAddr;
	
	public function __construct(){
		return $this;
	}
	
	#this function will load the css and javascript need for perticular action
	protected function getViewHelper($helperName)
	{
    	return $this->getServiceLocator()->get('viewhelpermanager')->get($helperName);
	}
    	
	public function indexAction(){
		return $this;
	}
	
	#This will load all Subgroups Of Group   
	function LikesAction() {		
		$auth = new AuthenticationService();
		$error = array();
		if ($auth->hasIdentity()) {
			$request   = $this->getRequest();
			if ($request->isPost()) {
				$post = $request->getPost();
				$identity = $auth->getIdentity();
				$SystemType = $post['type'];
				$identity = $auth->getIdentity();
				$sm = $this->getServiceLocator();				
				$this->groupTable = $sm->get('Groups\Model\GroupsTable');
				$SystemTypeData = $this->groupTable->fetchSystemType($SystemType);
				if(!empty($SystemTypeData)){
					switch($SystemType){
						case 'Discussion':
							$group_id = $post['group_id'];
							$planet_id = $post['planet'];
							if($group_id!=''&&$planet_id!=''){
								$SubGroupData = $this->groupTable->getSubGroupForSEO($planet_id);
								if(!empty($SubGroupData)){
									$discussion_id = $post['content_id'];
									if($discussion_id!=''){
										$this->discussionTable = $sm->get('Discussion\Model\DiscussionTable');
										$discussion_data = $this->discussionTable->getDiscussion($discussion_id);
										if(!empty($discussion_data)){
											if($this->addLIke($identity->user_id,$SystemTypeData->system_type_id,$discussion_id)){
												$success[] = 'Likes saved successfully';
												$this->likeTable = $sm->get('Like\Model\LikeTable');
												$ModuleLikesData = $this->likeTable->fetchLikesCountByReference($SystemTypeData->system_type_id,$discussion_id);	
												$likeData = $this->likeTable->LikeExistsCheck($SystemTypeData->system_type_id,$discussion_id,$identity->user_id);
												if (isset($ModuleLikesData) && !empty($ModuleLikesData)) {
													if ( $likeData->like_by_user_id && $ModuleLikesData > 1 ) {
														$data['view'] = "<a href=\"#\" class=\"discussion-unlikes\" id=\"$discussion_id\">Unlike</a>&nbsp;&nbsp;You&nbsp;+&nbsp;".($ModuleLikesData-2);
													} else{
														$data['view'] =	"<a href=\"#\" class=\"discussion-unlikes\" id=\"$discussion_id\" title=\"Unlike\">Unlike</a>&nbsp;&nbsp;You&nbsp;";
													}												
												}
												else{											
													$data['view'] = '';
												}
												$data['error'] = 0;
												$data['msg'] = 0;
												echo json_encode($data);die();
																					 
											}else{
												 $error[] = 'Oops an error is occured while saving Likes';
											}
										}
										else{
											$error[] = 'Content is not existing';
										}
									}else{
										$error[] = 'Content is not existing';
									}
									
								}
								else{
									$error[] = 'Unautherized access';	
								}
							}
							else{
								$error[] = 'Unautherized access';
							}
						break;
						case 'Activity':
							$group_id = $post['group_id'];
							$planet_id = $post['planet'];
							if($group_id!=''&&$planet_id!=''){
								$SubGroupData = $this->groupTable->getSubGroupForSEO($planet_id);
								if(!empty($SubGroupData)){
									$activity_id = $post['content_id'];
									if($activity_id!=''){
										$this->activityTable = $sm->get('Activity\Model\ActivityTable');
										$activity_data = $this->activityTable->getActivity($activity_id);
										if(!empty($activity_data)){
											if($this->addLIke($identity->user_id,$SystemTypeData->system_type_id,$activity_id)){
												$success[] = 'Likes saved successfully';
												$this->likeTable = $sm->get('Like\Model\LikeTable');
												$ModuleLikesData = $this->likeTable->fetchLikesCountByReference($SystemTypeData->system_type_id,$activity_id);	
												$likeData = $this->likeTable->LikeExistsCheck($SystemTypeData->system_type_id,$activity_id,$identity->user_id);
												if (isset($ModuleLikesData) && !empty($ModuleLikesData)) {
													if ( $likeData->like_by_user_id && $ModuleLikesData > 1 ) {
														$data['view'] = "<a href=\"#\" class=\"activity-unlikes\" id=\"$activity_id\">Unlike</a>&nbsp;&nbsp;You&nbsp;+&nbsp;".($ModuleLikesData-2);
													} else{
														$data['view'] =	"<a href=\"#\" class=\"activity-unlikes\" id=\"$activity_id\" title=\"Unlike\">Unlike</a>&nbsp;&nbsp;You&nbsp;";
													}												
												}
												else{											
													$data['view'] = '';
												}
												$data['error'] = 0;
												$data['msg'] = 0;
												echo json_encode($data);die();
																					 
											}else{
												 $error[] = 'Oops an error is occured while saving Likes';
											}
										}else{
											$error[] = 'Content is not existing';
										}
									}else{
										$error[] = 'Content is not existing';
									}
								}else{	
									$error[] = 'Unautherized access';
								}
							}else{								 
								$error[] = 'Unautherized access';						 
							}
						break;
						case 'album':
							
						break;
						case 'Comment':
							$comment_id = $post['content_id'];
							if($comment_id!=''){
								$this->commentTable = $sm->get('Comment\Model\CommentTable');
								$Comment_data = $this->commentTable->getComment($comment_id);
								if(!empty($Comment_data)){
									if($this->addLIke($identity->user_id,$SystemTypeData->system_type_id,$comment_id)){
										$success[] = 'Likes saved successfully';
										$this->likeTable = $sm->get('Like\Model\LikeTable');
										$ModuleLikesData = $this->likeTable->fetchLikesCountByReference($SystemTypeData->system_type_id,$comment_id);	
										$likeData = $this->likeTable->LikeExistsCheck($SystemTypeData->system_type_id,$comment_id,$identity->user_id);
										if (isset($ModuleLikesData) && !empty($ModuleLikesData)) {
											if ( $likeData->like_by_user_id && $ModuleLikesData > 1 ) {
												$data['view'] = "<a href=\"#\" class=\"comments-unlikes\" id=\"$comment_id\">Unlike</a>&nbsp;&nbsp;You&nbsp;+&nbsp;".($ModuleLikesData-2);
											} else{
												$data['view'] =	"<a href=\"#\" class=\"comments-unlikes\" id=\"$comment_id\" title=\"Unlike\">Unlike</a>&nbsp;&nbsp;You&nbsp;";
											}												
										}
										else{											
											$data['view'] = '';
										}
										$data['error'] = 0;
										$data['msg'] = 0;
										echo json_encode($data);die();
									}else{
										 $error[] = 'Oops an error is occured while saving Likes';
									}
									
								}else{
									$error[] = 'Content is not existing';
								}
							}
							else{
								$error[] = 'Content is not existing';
							}
						break;
						default:
						$error[] = 'You don\'t habe the permissions to do this';
						
					}
				}
				else{
					$error[] = 'Likes for this section currently unavailable';
				}
			}
			else{
				$error[] = 'Unautherized access';
			}
		}
		else{	
			$error[] = 'Your session has been expired';
		}
		$data['error'] = 1;
		$data['view']	= '';
		$data['msg'] = $error[0];
		echo json_encode($data);die(); 
	
	}
	public function addLIke($user_id,$type,$content_id){
		$sm = $this->getServiceLocator();
		$this->remoteAddr = $sm->get('ControllerPluginManager')->get('GenericPlugin')->getRemoteAddress();
		$Like = new Like();
		$this->likeTable = $sm->get('Like\Model\LikeTable');
		$likeData = $this->likeTable->LikeExistsCheck($type,$content_id,$user_id);
		$LikesData = array();
		$LikesData['like_system_type_id'] = $type;
		$LikesData['like_by_user_id'] = $user_id;
		$LikesData['like_refer_id'] = $content_id;
		$LikesData['like_status'] = 1;		
		$LikesData['like_added_ip_address'] =  $this->remoteAddr;
		$Like->exchangeArray($LikesData);
		$insertedLikesId = $this->likeTable->saveLike($Like);
		if($insertedLikesId)
		return true;
		else
		return false;
	}
	
	#This will load all Subgroups Of Group   
	function UnLikesAction() {
		$auth = new AuthenticationService();
		$error = array();
		if ($auth->hasIdentity()) {
			$request   = $this->getRequest();
			if ($request->isPost()) {
				$post = $request->getPost();
				$identity = $auth->getIdentity();
				$SystemType = $post['type'];
				$identity = $auth->getIdentity();
				$sm = $this->getServiceLocator();				
				$this->groupTable = $sm->get('Groups\Model\GroupsTable');
				$SystemTypeData = $this->groupTable->fetchSystemType($SystemType);
				if(!empty($SystemTypeData)){
					switch($SystemType){
						case 'Discussion':
							$group_id = $post['group_id'];
							$planet_id = $post['planet'];
							if($group_id!=''&&$planet_id!=''){
								$SubGroupData = $this->groupTable->getSubGroupForSEO($planet_id);
								if(!empty($SubGroupData)){
									$discussion_id = $post['content_id'];
									if($discussion_id!=''){
										$this->discussionTable = $sm->get('Discussion\Model\DiscussionTable');
										$discussion_data = $this->discussionTable->getDiscussion($discussion_id);
										if(!empty($discussion_data)){
											$this->likeTable = $sm->get('Like\Model\LikeTable');
											$likeData = $this->likeTable->LikeExistsCheck($SystemTypeData->system_type_id,$discussion_id,$identity->user_id);
											if ( !empty( $likeData->like_id ) ) {
												if( $this->likeTable->deleteLikeByReference($SystemTypeData->system_type_id,$likeData->like_by_user_id,$discussion_id)){
													$success[] = 'Unliked successfully';
													$ModuleLikesData = $this->likeTable->fetchLikesCountByReference($SystemTypeData->system_type_id,$discussion_id);	
													$likeData = $this->likeTable->LikeExistsCheck($SystemTypeData->system_type_id,$discussion_id,$identity->user_id);
													if (isset($ModuleLikesData) && !empty($ModuleLikesData)) {
													$data['view'] = "<a id=\"$discussion_id\" class=\"discussion-likes\" href=\"javascript:void(0)\">Like</a>".($ModuleLikesData-1);											 
													}
													else{											
													$data['view'] =	"<a id=\"$discussion_id\" class=\"discussion-likes\"  href=\"javascript:void(0)\">Like</a>";
													}
													$data['error'] = 0;
													$data['msg'] = 0;
													echo json_encode($data);die();
													
												}else{
													$error[] = 'Oops an error is occured while saving Likes';
												}
											}
											else{
												$error[] = 'Content is not existing';
											}
												
										}
										else{
											$error[] = 'Content is not existing';
										}
									}else{
										$error[] = 'Content is not existing';
									}
									
								}
								else{
									$error[] = 'Unautherized access';	
								}
							}
							else{
								$error[] = 'Unautherized access';
							}
						break;
						case 'Activity':
							$group_id = $post['group_id'];
							$planet_id = $post['planet'];
							if($group_id!=''&&$planet_id!=''){
								$SubGroupData = $this->groupTable->getSubGroupForSEO($planet_id);
								if(!empty($SubGroupData)){
									$activity_id = $post['content_id'];
									if($activity_id!=''){
										$this->activityTable = $sm->get('Activity\Model\ActivityTable');
										$activity_data = $this->activityTable->getActivity($activity_id);
										if(!empty($activity_data)){
											$this->likeTable = $sm->get('Like\Model\LikeTable');
											$likeData = $this->likeTable->LikeExistsCheck($SystemTypeData->system_type_id,$activity_id,$identity->user_id);
											if ( !empty( $likeData->like_id ) ) {
												if( $this->likeTable->deleteLikeByReference($SystemTypeData->system_type_id,$likeData->like_by_user_id,$activity_id)){
													$success[] = 'Unliked successfully';
													$ModuleLikesData = $this->likeTable->fetchLikesCountByReference($SystemTypeData->system_type_id,$activity_id);	
													$likeData = $this->likeTable->LikeExistsCheck($SystemTypeData->system_type_id,$activity_id,$identity->user_id);
													if (isset($ModuleLikesData) && !empty($ModuleLikesData)) {
													$data['view'] = "<a id=\"$activity_id\" class=\"activity-likes\" href=\"javascript:void(0)\">Like</a>".($ModuleLikesData-1);											 
													}
													else{											
													$data['view'] =	"<a id=\"$activity_id\" class=\"activity-likes\"  href=\"javascript:void(0)\">Like</a>";
													}
													$data['error'] = 0;
													$data['msg'] = 0;
													echo json_encode($data);die();
													
												}else{
													$error[] = 'Oops an error is occured while saving Likes';
												}
											}
											else{
												$error[] = 'Content is not existing';
											}
												
										}
										else{
											$error[] = 'Content is not existing';
										}
									}else{
										$error[] = 'Content is not existing';
									}
									
								}
								else{
									$error[] = 'Unautherized access';	
								}
							}
							else{
								$error[] = 'Unautherized access';
							}
						break;
						case 'album':
							
						break;
						case 'Comment':
							$comment_id = $post['content_id'];
							if($comment_id!=''){
								$this->commentTable = $sm->get('Comment\Model\CommentTable');
								$Comment_data = $this->commentTable->getComment($comment_id);
								if(!empty($Comment_data)){
									$this->likeTable = $sm->get('Like\Model\LikeTable');
									$likeData = $this->likeTable->LikeExistsCheck($SystemTypeData->system_type_id,$comment_id,$identity->user_id);
									if ( !empty( $likeData->like_id ) ) {
										if( $this->likeTable->deleteLikeByReference($SystemTypeData->system_type_id,$likeData->like_by_user_id,$comment_id)){
											$success[] = 'Unliked successfully';											 
											$ModuleLikesData = $this->likeTable->fetchLikesCountByReference($SystemTypeData->system_type_id,$comment_id);	
											$likeData = $this->likeTable->LikeExistsCheck($SystemTypeData->system_type_id,$comment_id,$identity->user_id);
											if (isset($ModuleLikesData) && !empty($ModuleLikesData)) {
											$data['view'] = "<a id=\"$comment_id\" class=\"comments-likes\" href=\"javascript:void(0)\">Like</a>".($ModuleLikesData-1);											 
											}
											else{											
											$data['view'] =	"<a id=\"$comment_id\" class=\"comments-likes\"  href=\"javascript:void(0)\">Like</a>";
											}
											$data['error'] = 0;
											$data['msg'] = 0;
											echo json_encode($data);die();
										}else{
											$error[] = 'Oops an error is occured while saving Likes';
										}
										
									}
									else{
										$error[] = 'Content is not existing';
									}
								}else{
									
								}
							}
							else{
								$error[] = 'Content is not existing';
							}
						break;
						default:
						$error[] = 'You don\'t habe the permissions to do this';
						
					}
				}else{
					$error[] = 'Likes for this section currently unavailable';
				}
			}
			else{
				$error[] = 'Unautherized access';
			}
		}
		else{	
			$error[] = 'Your session has been expired';
		}
		$data['error'] = 1;
		$data['view']	= '';
		$data['msg'] = $error[0];
		echo json_encode($data);die(); 
		
	}
	 
	
	#This will load all Subgroups Of Group   
	function LikesUsersListAction() {	
		$error = array();	#Error variable
		$success = array();	#success message variable
		$GroupId = "";
		$SubGroupId = "";	//This will hold the galaxy id
		$GroupReferId = ""; 
		$SystemTypeId = ""; 				
		$userData = array();	//this will hold data from y2m_user table
		$groupData = array();//this will hold the Galaxy data
		$SubGroupData = array();//this will hold the Planet data
		$LikesUsersListData = array();//this will hold the Planet data
		
		$GroupId = $this->params('group_id'); 				
		$SubGroupId = $this->params('sub_group_id'); 
		$GroupReferId = $this->params('group_refer_id');
		$SystemTypeId = $this->params('system_type_id'); 
	
		#db connectivity
		$sm = $this->getServiceLocator();
		$this->remoteAddr = $sm->get('ControllerPluginManager')->get('GenericPlugin')->getRemoteAddress();
		$dbAdapter = $sm->get('Zend\Db\Adapter\Adapter');
		
		try {				

			$request   = $this->getRequest();
			$auth = new AuthenticationService();	
			$identity = null;   
			
			if ($auth->hasIdentity()) {
				
				// Identity exists; get it
				$identity = $auth->getIdentity();				
				#fetch the user Galaxy
				$this->userTable = $sm->get('User\Model\UserTable');
				
				#check the identity against the DB
				$userData = $this->userTable->getUser($identity->user_id);	
		
				if(isset($userData->user_id) && !empty($userData->user_id) && isset($GroupId) && !empty($GroupId) && isset($SubGroupId) && !empty($SubGroupId)) {				
					
					$this->groupTable = $sm->get('Group\Model\GroupTable');
					
					#get Group Info
					$SubGroupData = $this->groupTable->getSubGroupForSEO($SubGroupId);
					
					#fetch the Galaxy Info
					$groupData = $this->groupTable->getGroup($SubGroupData->group_parent_group_id);	

					$SystemTypeData = $this->groupTable->fetchSystemType($SystemTypeId);
					
					$this->discussionTable = $sm->get('Discussion\Model\DiscussionTable');
					
					#fetch the Discussion planet details
					$GroupModuleData = $this->discussionTable->getDiscussion($GroupReferId);	
					
					#add discussion code
					if(isset($SubGroupData->group_id) && !empty($SubGroupData->group_id) && isset($SubGroupData->group_parent_group_id) && !empty($SubGroupData->group_parent_group_id) && isset($GroupModuleData->group_discussion_group_id) && !empty($GroupModuleData->group_discussion_group_id) ) {					
						$this->likeTable = $sm->get('Like\Model\LikeTable');	
						#fetch the Discussion Like of planet details
						$LikesUsersListData = $this->likeTable->fetchLikesUsersByReference($SystemTypeData->system_type_id,$GroupReferId);
						
					}
				}
			
			} //if ($auth->hasIdentity()) 			
		} catch (\Exception $e) {
			echo "Caught exception: " . get_class($e) . "\n";
			echo "Message: " . $e->getMessage() . "\n";			 
		}
		//echo $ModuleLikesData->likes_counts;
		
		$viewModel = new ViewModel(array('userData' => $userData,'groupData' => $groupData,'SubGroupData' => $SubGroupData, 'LikesUsersListData' => $LikesUsersListData, 'Group_Refer_Id' => $GroupReferId,'System_Type_Id' => $SystemTypeId, 'error' => $error, 'success' => $success, 'flashMessages' => $this->flashMessenger()->getMessages()));
		$viewModel->setTerminal($request->isXmlHttpRequest());
		return $viewModel;
	
	}
	
	
	#This will load all Subgroups Of Group   
	function CommentsLikesUsersListAction() {	
		$error = array();	#Error variable
		$success = array();	#success message variable
		$GroupId = "";
		$SubGroupId = "";	//This will hold the galaxy id
		$GroupReferId = ""; 
		$SystemTypeId = ""; 				
		$userData = array();	//this will hold data from y2m_user table
		$groupData = array();//this will hold the Galaxy data
		$SubGroupData = array();//this will hold the Planet data
		$LikesUsersListData = array();//this will hold the Planet data
		
		$GroupId = $this->params('group_id'); 				
		$SubGroupId = $this->params('sub_group_id'); 
		$GroupReferId = $this->params('group_refer_id');
		$SystemTypeId = $this->params('system_type_id'); 	
		$SubSystemTypeId = $this->params('sub_system_type_id'); 	
	
		#db connectivity
		$sm = $this->getServiceLocator();
		$this->remoteAddr = $sm->get('ControllerPluginManager')->get('GenericPlugin')->getRemoteAddress();
		$dbAdapter = $sm->get('Zend\Db\Adapter\Adapter');
		
		try {				

			$request   = $this->getRequest();
			$auth = new AuthenticationService();	
			$identity = null;   
			
			if ($auth->hasIdentity()) {
				
				// Identity exists; get it
				$identity = $auth->getIdentity();				
				#fetch the user Galaxy
				$this->userTable = $sm->get('User\Model\UserTable');
				
				#check the identity against the DB
				$userData = $this->userTable->getUser($identity->user_id);	
		
				if(isset($userData->user_id) && !empty($userData->user_id) && isset($GroupId) && !empty($GroupId) && isset($SubGroupId) && !empty($SubGroupId)) {				
					
					$this->groupTable = $sm->get('Group\Model\GroupTable');
					
					#get Group Info
					$SubGroupData = $this->groupTable->getSubGroupForSEO($SubGroupId);

					#fetch the Galaxy Info
					$groupData = $this->groupTable->getGroup($SubGroupData->group_parent_group_id);	
					
					$this->commentTable = $sm->get('Comment\Model\CommentTable');

					$SystemTypeData = $this->groupTable->fetchSystemType($SubSystemTypeId);
					
					$this->discussionTable = $sm->get('Discussion\Model\DiscussionTable');
					
					#fetch the Discussion planet details
					$GroupDiscussionCommentsData = $this->commentTable->getComment($GroupReferId);
					
					#add discussion code
					if(isset($SubGroupData->group_id) && !empty($SubGroupData->group_id) && isset($SubGroupData->group_parent_group_id) && !empty($SubGroupData->group_parent_group_id) && isset($GroupDiscussionCommentsData->comment_id) && !empty($GroupDiscussionCommentsData->comment_id) ) {					
					
						$this->likeTable = $sm->get('Like\Model\LikeTable');	
						#fetch the Discussion Like of planet details
						$LikesUsersListData = $this->likeTable->fetchLikesUsersByReference($SystemTypeData->system_type_id,$GroupReferId);	
						
					}
				}
			
			} //if ($auth->hasIdentity()) 			
		} catch (\Exception $e) {
			echo "Caught exception: " . get_class($e) . "\n";
			echo "Message: " . $e->getMessage() . "\n";			 
		}
		
		
		$viewModel = new ViewModel(array('userData' => $userData,'groupData' => $groupData,'SubGroupData' => $SubGroupData, 'LikesUsersListData' => $LikesUsersListData, 'Group_Refer_Id' => $GroupReferId,'System_Type_Id' => $SystemTypeId, 'error' => $error, 'success' => $success, 'flashMessages' => $this->flashMessenger()->getMessages()));
		$viewModel->setTerminal($request->isXmlHttpRequest());
		return $viewModel;
	
	}
	
}
