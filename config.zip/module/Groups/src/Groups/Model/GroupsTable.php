<?php
namespace Groups\Model;
use Zend\Db\Sql\Select ;
use Zend\Db\TableGateway\AbstractTableGateway;
use Zend\Db\TableGateway\TableGateway;
use Zend\Db\TableGateway\Feature\RowGatewayFeature;
use Zend\Db\Adapter\Adapter;
use Zend\Db\ResultSet\ResultSet;
class GroupsTable extends AbstractTableGateway
{ 
    protected $table = 'y2m_group';  
    public function __construct(Adapter $adapter)
    {
        $this->adapter = $adapter;
        $this->resultSetPrototype = new ResultSet();
        $this->resultSetPrototype->setArrayObjectPrototype(new Groups());
        $this->initialize();
    }

	//this function will fetch all groups
    public function fetchAllGroups()
    { 
        	$select = new Select;
			$select->from('y2m_group')
    			->join('y2m_photo', 'y2m_photo.photo_id = y2m_group.group_photo_id', array('*'))
				->where(array('y2m_group.group_parent_group_id' => "0"))
				->order(array('y2m_group.group_title ASC'));
	   		$statement = $this->adapter->createStatement();
			$select->prepareStatement($this->adapter, $statement);
			$resultSet = new ResultSet();
			$resultSet->initialize($statement->execute());	  
			return $resultSet;
	    //$resultSet = $this->select(array('group_parent_group_id' => 0));
        //return $resultSet;
    }
	public function getPlanets($group_id=null){
		$group_id  = (int) $group_id;
		$predicate = new  \Zend\Db\Sql\Where();
		$select = new Select;
		$select->from('y2m_group')			 
			 ->join('y2m_photo', 'y2m_photo.photo_id = y2m_group.group_photo_id', array('*'))
			 ->where(array($predicate->greaterThan('y2m_group.group_parent_group_id' , "0"), 'y2m_group.group_parent_group_id' => $group_id))
			 ->order(array('y2m_group.group_id ASC'));		 
		$statement = $this->adapter->createStatement();
		$select->prepareStatement($this->adapter, $statement);
		$resultSet = new ResultSet();
		$resultSet->initialize($statement->execute());
		return $resultSet;
	}
	//this function will fetch all groups
    public function fetchAllSubGroups($group_id=null)
    {  		
 
		if($group_id==null){
			
			$predicate = new  \Zend\Db\Sql\Where();
			$select = new Select;
			$select->from(array('c' => 'y2m_group'))
				 ->join(array('p' => 'y2m_group'), 'c.group_id = p.group_parent_group_id', array('*'))
				 ->join('y2m_photo', 'y2m_photo.photo_id = c.group_photo_id', array('*'))
				 ->where($predicate->greaterThan('p.group_parent_group_id' , "0"))
				 ->order(array('c.group_id ASC'));
			$select->columns(array('parent_title' => 'group_title'));
			$statement = $this->adapter->createStatement();
			$select->prepareStatement($this->adapter, $statement);
			$resultSet = new ResultSet();
			$resultSet->initialize($statement->execute());
			return $resultSet;
		}else{				 	 
			$group_id  = (int) $group_id;
			$predicate = new  \Zend\Db\Sql\Where();
			$select = new Select;
			$select->from(array('c' => 'y2m_group'))
				 ->join(array('p' => 'y2m_group'), 'c.group_id = p.group_parent_group_id', array('*'))
				 ->join('y2m_photo', 'y2m_photo.photo_id = p.group_photo_id', array('*'))
				 ->where(array($predicate->greaterThan('p.group_parent_group_id' , "0"), 'p.group_parent_group_id' => $group_id))
				 ->order(array('c.group_id ASC'));
			$select->columns(array('child_title' => 'group_title', 'parent_title' => 'group_title'));
			$statement = $this->adapter->createStatement();
			$select->prepareStatement($this->adapter, $statement);
			$resultSet = new ResultSet();
			$resultSet->initialize($statement->execute());
			return $resultSet;		
		}		
			 
			/*$group_id  = (int) $group_id;
			$predicate = new  \Zend\Db\Sql\Where();
			$select = new Select;
			$select->from('y2m_group')
    			->join('y2m_photo', 'y2m_photo.photo_id = y2m_group.group_photo_id', array('*'))
				->where(array($predicate->greaterThan('group_parent_group_id' , "0"), 'group_parent_group_id' => $group_id))
				->order(array('y2m_group.group_title ASC'));; 
	   		$statement = $this->adapter->createStatement();
			$select->prepareStatement($this->adapter, $statement);
			$resultSet = new ResultSet();
			$resultSet->initialize($statement->execute());	  
			return $resultSet;
	    //$resultSet = $this->select(array('group_parent_group_id' => 0));
        //return $resultSet;*/
    }
	
		//this function will fetch all groups
    public function fetchAllPlanets()
    {      	
		$predicate = new  \Zend\Db\Sql\Where();
		$select = new Select;
		$select->from(array('c' => 'y2m_group'))
				->join(array('p' => 'y2m_group'), 'c.group_id = p.group_parent_group_id', array('*'))
				->where($predicate->greaterThan('p.group_parent_group_id' , "0"))
				->order(array('c.group_id ASC'));
		$select->columns(array('child_title' => 'group_title', 'parent_title' => 'group_title'));
   		$statement = $this->adapter->createStatement();
		$select->prepareStatement($this->adapter, $statement);
		$resultSet = new ResultSet();
		$resultSet->initialize($statement->execute());
		return $resultSet;
    }
		
	//this will fetch single Galaxy from table
   public function getGroup($group_id)
    {
        $group_id  = (int) $group_id;
        $rowset = $this->select(array('group_id' => $group_id,'group_parent_group_id' => '0'));
        $row = $rowset->current();
        return $row;
    }
	
	//this will fetch single Galaxy from table
   public function getGroupForName($group_title)
    {
        $rowset = $this->select(array('group_title' => $group_title,'group_parent_group_id' => '0'));
        $row = $rowset->current();
        return $row;
    }
	
	#check Planet based based on name
	 public function getSubGroupForName($group_title)
    {
        $predicate = new  \Zend\Db\Sql\Where();
        $rowset = $this->select(array('group_title' => $group_title, $predicate->greaterThan('group_parent_group_id' , "0")));
        $row = $rowset->current();
		return $row;
     }
	
	//this will fetch single Planet from table
	public function getSubGroup($group_id)
    {
        $group_id  = (int) $group_id;
		$predicate = new  \Zend\Db\Sql\Where();
        $rowset = $this->select(array('group_id' => $group_id, $predicate->greaterThan('group_parent_group_id' , "0")));
		$row = $rowset->current();
        return $row;
    }	
	
	//this will fetch Group Based on SEO name
	public function getGroupIdFromSEO($group_seo_title)
    {
      	$rowset = $this->select(array('group_seo_title' => $group_seo_title));
		$row = $rowset->current();
        return $row;
    }
	public function getGroupForSEO($group_seo_title)
    {
      	$rowset = $this->select(array('group_seo_title' => $group_seo_title, 'group_parent_group_id' => '0'));
		$row = $rowset->current();
        return $row;
    }
	
	//this will fetch single Planet Based on SEO name
	public function getSubGroupForSEO($group_seo_title)
    {
        $predicate = new  \Zend\Db\Sql\Where();
        $rowset = $this->select(array('group_seo_title' => $group_seo_title, $predicate->greaterThan('group_parent_group_id' , "0")));
		$row = $rowset->current();
        return $row;
    }
	
	
	//this will save group in a table
    public function saveGroup(Groups $group)
    {
       $data = array(
            'group_title' => $group->group_title,
            'group_seo_title'  => $group->group_seo_title,
			'group_status'  => $group->group_status,
			'group_discription'  => $group->group_discription,
			'group_added_timestamp'  => $group->group_added_timestamp,
			'group_added_ip_address'  => $group->group_added_ip_address,
			'group_parent_group_id'  => 0,
			'group_location'  => $group->group_location,
			'group_photo_id'  => $group->group_photo_id,
			'group_modified_timestamp'  => $group->group_modified_timestamp,
			'group_modified_ip_address'  => $group->group_modified_ip_address,
			'group_view_counter'  => $group->group_view_counter,		
        );

        $group_id = (int)$group->group_id;
        if ($group_id == 0) {
            $this->insert($data);
			return $this->adapter->getDriver()->getConnection()->getLastGeneratedValue();
        } else {
            if ($this->getGroup($group_id)) {
                $this->update($data, array('group_id' => $group_id));
            } else {
                throw new \Exception('Form id does not exist');
            }
        }
    }
	//this will save sub-group in a table
	public function saveSubGroup(Groups $group)
    {
       $data = array(
            'group_title' => $group->group_title,
            'group_seo_title'  => $group->group_seo_title,
			'group_status'  => $group->group_status,
			'group_discription'  => $group->group_discription,
			'group_added_timestamp'  => $group->group_added_timestamp,
			'group_added_ip_address'  => $group->group_added_ip_address,
			'group_parent_group_id'  => $group->group_parent_group_id,
			'group_location'  => $group->group_location,
			'group_photo_id'  => $group->group_photo_id,
			'group_modified_timestamp'  => $group->group_modified_timestamp,
			'group_modified_ip_address'  => $group->group_modified_ip_address,
			'group_view_counter'  => $group->group_view_counter,		
        );

        $group_id = (int)$group->group_id;
        if ($group_id == 0) {
            $this->insert($data);
			return $this->adapter->getDriver()->getConnection()->getLastGeneratedValue();
        } else {
            if ($this->getSubGroup($group_id)) {
                $this->update($data, array('group_id' => $group_id));
            } else {
                throw new \Exception('Form id does not exist');
            }
        }
    }

	//it will delete any group
    public function deleteGroup($group_id)
    {
        $this->delete(array('group_id' => $group_id, 'y2m_group.group_parent_group_id' => "0"));
    }
	
	public function deleteSubGroup($group_id)
    {
        $predicate = new  \Zend\Db\Sql\Where();
		$this->delete(array('group_id' => $group_id, $predicate->greaterThan('group_parent_group_id' , "0")));
    }
	
	public function fetchSystemType($SystemTypeTitle)
    {
		$SystemTypeTitle  = (string) $SystemTypeTitle;
		$table = new TableGateway('y2m_system_type', $this->adapter, new RowGatewayFeature('system_type_title'));
		$results = $table->select(array('system_type_title' => $SystemTypeTitle));
		$Row = $results->current();
		return $Row;
    }
	public function getSeotitle($group_id){
		$rowset = $this->select(array('group_id' => $group_id));
		$row = $rowset->current();
        return $row;
	}	
    
}