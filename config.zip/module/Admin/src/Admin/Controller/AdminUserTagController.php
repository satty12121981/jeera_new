<?php
namespace Admin\Controller; 
use Zend\Mvc\Controller\AbstractActionController;
use Zend\View\Model\ViewModel;	//Return model 
use Zend\Session\Container; // We need this when using sessions     
use Zend\Authentication\AuthenticationService;
use Zend\Authentication\Adapter\DbTable as AuthAdapter;
use Zend\Db\Sql\Select;
/*use Zend\Authentication\Result as Result;
use Zend\Authentication\Storage;*/ 
#Tag classs
use Tag\Model\Tag;
use Tag\Model\UserTag;
use User\Model\User;
use Admin\Form\AdminUserTagForm;
use Admin\Form\AdminUserTagFilter;   
use Admin\Form\AdminUserTagEditFilter;   
class AdminUserTagController extends AbstractActionController
{   
	protected $userTable;			#variable to hold the User model configration 
	protected $userProfileTable;	#variable to hold the User Profile model configration 
	protected $tagTable;			#variable to hold the Tag configration 
	protected $userTagTable;		#variable to hold the User Tag model configration 
	protected $groupTable;			#variable to hold the User Group model configration 
   
 	#Displaying Tag Grid
    public function indexAction()
    {		 
		$error =array();	#Error variable
		$success =array();	#success message variable
		
		$select = new Select();
        $order_by = $this->params()->fromRoute('order_by') ?  $this->params()->fromRoute('order_by') : 'tag_id';
        $order = $this->params()->fromRoute('order') ? $this->params()->fromRoute('order') : Select::ORDER_ASCENDING;
        $select->order($order_by . ' ' . $order);		
		
		#fetch all users tag
		$allUserTagData = array();	
		$allUserTagData = $this->getUserTagTable()->fetchAll();	
		  
        return array('allUserTagData' => $allUserTagData,'order_by' => $order_by,'order' => $order, 'error' => $error, 'success' => $success, 'flashMessages' => $this->flashMessenger()->getMessages());	 
    }
	
	public function addAction()
    {        
	    $error =array();	#Error variable
		$success =array();	#success message variable
		
		#db connectivity
		$sm = $this->getServiceLocator();
		$dbAdapter = $sm->get('Zend\Db\Adapter\Adapter');
		
		#fetch all users  
		$allUserData = array();	
		$allUserData = $this->getUserTable()->fetchAll();
		$selectAllUser =array();
		$selectAllUser = User::selectFormatAllUser($allUserData);	 
		#fetch all tags  
		$allTagData = array();	
		$allTagData = $this->getTagTable()->fetchAll();
		$selectAllTag =array();
		$selectAllTag = Tag::selectFormatAllTag($allTagData);		 
		
		$form = new AdminUserTagForm($selectAllUser, $selectAllTag);
        $form->get('submit')->setAttribute('value', 'Add');

        $request = $this->getRequest();
        if ($request->isPost()) {
      		$userTag = new UserTag();
          	$form->setInputFilter(new AdminUserTagFilter($dbAdapter));					 
           	$form->setData($request->getPost());
            if ($form->isValid()) {
			
				#everthing is ok. Apply extra validator. Check the Unique combination of User and tags
				$tag_id = $this->params()->fromPost('user_tag_tag_id'); 
				$user_id = $this->params()->fromPost('user_tag_user_id'); 
				
				#check, if it is already exist, then show error since user can not add those
				$userTagExist =array();
				$userTagExist = $this->getUserTagTable()->checkUserTag($user_id, $tag_id);
				
				if(isset($userTagExist->user_tag_id) && !empty($userTagExist->user_tag_id)){
					 $error[] = 'Same Tag and User already exist.Please choose a different one';	
				}else{ //if(isset($userTagExist['user_tag_id']) && !empty($userTagExist['user_tag_id']))               		
					$this->flashMessenger()->addMessage('');	 
					$userTag->exchangeArray($form->getData());								
                	$this->getUserTagTable()->saveUserTag($userTag);
                	// Redirect to list of tags
                	return $this->redirect()->toRoute('admin/admin-user-tags');
				}
            }else{
				 $error[] ='error in Form';
			}
        }
		 
        return array('form' => $form, 'error' => $error, 'success' => $success, 'flashMessages' => $this->flashMessenger()->getMessages());
    }

    public function editAction()
    {
        $error =array();	#Error variable
		$success =array();	#success message variable
		#db connectivity
		$sm = $this->getServiceLocator();
		$dbAdapter = $sm->get('Zend\Db\Adapter\Adapter');
		
		$id = (int)$this->params('id');
        if (!$id) {
            return $this->redirect()->toRoute('admin/admin-user-tags', array('action'=>'add'));
        }
        $userTag = $this->getUserTagTable()->getUserTag($id); 
		if(isset($userTag->user_tag_id) && !empty($userTag->user_tag_id)){
			
		}else{
			return $this->redirect()->toRoute('admin/admin-user-tags', array('action'=>'index'));
		} 
		
		#fetch all users  
		$allUserData = array();	
		$allUserData = $this->getUserTable()->fetchAll();
		$selectAllUser =array();
		$selectAllUser = User::selectFormatAllUser($allUserData);	 
		
		#fetch all tags  
		$allTagData = array();	
		$allTagData = $this->getTagTable()->fetchAll();
		$selectAllTag =array();
		$selectAllTag = Tag::selectFormatAllTag($allTagData);
		
        $form = new AdminUserTagForm($selectAllUser, $selectAllTag);
        $form->bind($userTag);
        $form->get('submit')->setAttribute('value', 'Edit');
		        
        $request = $this->getRequest();
        if ($request->isPost()) {
			$userTag = new UserTag();
			$form->setInputFilter(new AdminUserTagEditFilter($dbAdapter));		
            $form->setData($request->getPost());
            if ($form->isValid()) {			
				#everthing is ok. Apply extra validator. Check the Unique combination of User and tags
				$tag_id = $this->params()->fromPost('user_tag_tag_id'); 
				$user_id = $this->params()->fromPost('user_tag_user_id'); 
				                
				$userTagExist =array();
				$userTagExist =$this->getUserTagTable()->checkUserTagForEdit($user_id, $tag_id, $id);
				
				if(isset($userTagExist->user_tag_id) && !empty($userTagExist->user_tag_id)){
					//exit;
					$error[] = 'Same Tag and User already exist.Please choose a different one';	
				}else{ //if(isset($userTagExist['user_tag_id']) && !empty($userTagExist['user_tag_id']))   
					$userTag->exchangeArray($form->getData());	
					$this->getUserTagTable()->saveUserTag($userTag);
					 // Redirect to list of tags
                	return $this->redirect()->toRoute('admin/admin-user-tags');				
				}	              
            }else{
				 $error[] ='error in Form';
			}
        }
        return array('id' => $id, 'form' => $form, 'error' => $error, 'success' => $success, 'flashMessages' => $this->flashMessenger()->getMessages());
    }

    public function deleteAction()
    {
       	$error =array();	#Error variable
		$success =array();	#success message variable
	   // echo "hello";exit;
	    $id = (int)$this->params('id'); 
        if (!$id) {
            return $this->redirect()->toRoute('admin/admin-user-tags');
        }
		$userTag = $this->getUserTagTable()->getUserTag($id);	 
		if(isset($userTag->user_tag_id) && !empty($userTag->user_tag_id)){
			
		}else{
			return $this->redirect()->toRoute('admin/admin-user-tags', array('action'=>'index'));
		} 
		
        $request = $this->getRequest();
        if ($request->isPost()) {
            $del = $request->getPost()->get('del', 'No');
            if ($del == 'Yes') {
                $id = (int)$request->getPost()->get('id');
                $this->getUserTagTable()->deleteUserTag($id);
            }
            // Redirect to list of tags
            return $this->redirect()->toRoute('admin/admin-user-tags');
        } 			 
        return array('id' => $id, 'userTag' => $userTag,'error' => $error, 'success' => $success, 'flashMessages' => $this->flashMessenger()->getMessages());
    }	 
	
	#accessing the user table module
	public function getUserTable()
    {
        if (!$this->userTable) {
            $sm = $this->getServiceLocator();
            $this->userTable = $sm->get('User\Model\UserTable');
        }
        return $this->userTable;
    }
	
	#accessing the user profile table module
	public function getUserProfileTable()
    {
        if (!$this->userProfileTable) {
            $sm = $this->getServiceLocator();
            $this->userProfileTable = $sm->get('User\Model\UserProfileTable');
        }
        return $this->userProfileTable;
    }
	
	#Accessing the tag table
	public function getTagTable()
    {
        if (!$this->tagTable) {
            $sm = $this->getServiceLocator();
            $this->tagTable = $sm->get('Tag\Model\TagTable');
        }
        return $this->tagTable;
    }
	
	#Accessing the Group tag table
	public function getUserTagTable()
    {
        if (!$this->userTagTable) {
            $sm = $this->getServiceLocator();
            $this->userTagTable = $sm->get('Tag\Model\UserTagTable');
        }
        return $this->userTagTable;
    }
}