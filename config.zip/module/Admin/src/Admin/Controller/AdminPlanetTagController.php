<?php 
namespace Admin\Controller; 
use Zend\Mvc\Controller\AbstractActionController;
use Zend\View\Model\ViewModel;	//Return model 
use Zend\Session\Container; // We need this when using sessions     
use Zend\Authentication\AuthenticationService;
use Zend\Authentication\Adapter\DbTable as AuthAdapter;
use Zend\Db\Sql\Select;
/*use Zend\Authentication\Result as Result;
use Zend\Authentication\Storage;*/ 
#Tag classs
use Tag\Model\Tag;
use Tag\Model\GroupTag;
use Group\Model\Group;
use Admin\Form\AdminPlanetTagForm;
use Admin\Form\AdminPlanetTagFilter;   
use Admin\Form\AdminPlanetTagEditFilter;   
class AdminPlanetTagController extends AbstractActionController
{   
	protected $userTable;			#variable to hold the Group model configration 
	protected $userProfileTable;	#variable to hold the Group Profile model configration 
	protected $tagTable;			#variable to hold the Tag configration 
	protected $groupTagTable;		#variable to hold the Group Tag model configration 
	protected $groupTable;			#variable to hold the Group Group model configration 
   
 	#Displaying Tag Grid
    public function indexAction()
    {		 
		$error =array();	#Error variable
		$success =array();	#success message variable
		
		$select = new Select();
        $order_by = $this->params()->fromRoute('order_by') ?  $this->params()->fromRoute('order_by') : 'tag_id';
        $order = $this->params()->fromRoute('order') ? $this->params()->fromRoute('order') : Select::ORDER_ASCENDING;
        $select->order($order_by . ' ' . $order);		
		
		#fetch all users tag
		$allGroupTagData = array();	
		$allGroupTagData = $this->getGroupTagTable()->fetchAll();	
		  
        return array('allGroupTagData' => $allGroupTagData,'order_by' => $order_by,'order' => $order, 'error' => $error, 'success' => $success, 'flashMessages' => $this->flashMessenger()->getMessages());	 
    }
	
	public function addAction()
    {        
	    $error =array();	#Error variable
		$success =array();	#success message variable
		 
		#db connectivity
		$sm = $this->getServiceLocator();
		$dbAdapter = $sm->get('Zend\Db\Adapter\Adapter');			 
		
		#fetch all Planets  
		$allSubGroupData = array();	
		$allSubGroupData = $this->getGroupTable()->fetchAllSubGroups();
		$selectAllSubGroup =array();
		$selectAllSubGroup = Group::selectFormatAllGroupForPlanetTags($allSubGroupData);	
				 
		#fetch all tags  
		$allTagData = array();	
		$allTagData = $this->getTagTable()->fetchAll();
		$selectAllTag =array();
		$selectAllTag = Tag::selectFormatAllTag($allTagData);		 
		
		$form = new AdminPlanetTagForm($selectAllSubGroup, $selectAllTag);
        $form->get('submit')->setAttribute('value', 'Add');		

        $request = $this->getRequest();
        if ($request->isPost()) {
      		$groupTag = new GroupTag();
          	$form->setInputFilter(new AdminPlanetTagFilter($dbAdapter));					 
           	$form->setData($request->getPost());
            if ($form->isValid()) {
				
				#everthing is ok. Apply extra validator. Check the Unique combination of Group and tags
				 $tag_id = $this->params()->fromPost('group_tag_tag_id'); 
				 $group_id = $this->params()->fromPost('group_tag_group_id'); 
				 
				
				#check, if it is already exist, then show error since user can not add those
				$groupTagExist =array();
				$groupTagExist = $this->getGroupTagTable()->checkGroupTag($group_id, $tag_id);
				
				if(isset($groupTagExist->group_tag_id) && !empty($groupTagExist->group_tag_id)){
					 $error[] = 'Same Tag and Group already exist.Please choose a different one';
				}else{ //if(isset($groupTagExist['group_tag_id']) && !empty($groupTagExist['group_tag_id']))  				 	 
					$groupTag->exchangeArray($form->getData());								
                	$this->getGroupTagTable()->saveGroupTag($groupTag);
                	// Redirect to list of tags
                	return $this->redirect()->toRoute('admin/admin-planet-tags');
				}
            }else{
				 $error[] ='error in Form';
			}
        }
		 
        return array('form' => $form, 'error' => $error, 'success' => $success, 'flashMessages' => $this->flashMessenger()->getMessages());
    }

    public function editAction()
    {
        $error =array();	#Error variable
		$success =array();	#success message variable
		#db connectivity
		$sm = $this->getServiceLocator();
		$dbAdapter = $sm->get('Zend\Db\Adapter\Adapter');
		
		$id = (int)$this->params('id');
        if (!$id) {
            return $this->redirect()->toRoute('admin/admin-planet-tags', array('action'=>'add'));
        }
        $groupTag = $this->getGroupTagTable()->getGroupTag($id);	
		if(isset($groupTag->group_tag_id) && !empty($groupTag->group_tag_id)){
			
		}else{
			return $this->redirect()->toRoute('admin/admin-planet-tags', array('action'=>'index'));
		} 
		
		#fetch all users  
		$allGroupData = array();	
		$allGroupData = $this->getGroupTable()->fetchAllSubGroups();
		$selectAllGroup =array();
		$selectAllGroup = Group::selectFormatAllGroupForPlanetTags($allGroupData);	 
		#fetch all tags  
		$allTagData = array();	
		$allTagData = $this->getTagTable()->fetchAll();
		$selectAllTag =array();
		$selectAllTag = Tag::selectFormatAllTag($allTagData);		

        $form = new AdminPlanetTagForm($selectAllGroup, $selectAllTag);
        $form->bind($groupTag);
        $form->get('submit')->setAttribute('value', 'Edit');
        
        $request = $this->getRequest();
        if ($request->isPost()) {
			$groupTag = new GroupTag();
			$form->setInputFilter(new AdminPlanetTagEditFilter($dbAdapter));		
            $form->setData($request->getPost());
            if ($form->isValid()) {			
				#everthing is ok. Apply extra validator. Check the Unique combination of Group and tags
				$tag_id = $this->params()->fromPost('group_tag_tag_id'); 
				$group_id = $this->params()->fromPost('group_tag_group_id'); 
				                
				$groupTagExist =array();
				$groupTagExist =$this->getGroupTagTable()->checkGroupTagForEdit($group_id, $tag_id, $id);
				
				if(isset($groupTagExist->group_tag_id) && !empty($groupTagExist->group_tag_id)){
					//exit;
					$error[] = 'Same Tag and Group already exist.Please choose a different one';	
				}else{ //if(isset($groupTagExist['group_tag_id']) && !empty($groupTagExist['group_tag_id']))   
					$groupTag->exchangeArray($form->getData());			
					$this->getGroupTagTable()->saveGroupTag($groupTag);
					 // Redirect to list of tags
                	return $this->redirect()->toRoute('admin/admin-planet-tags');				
				}	              
            }else{
				 $error[] ='error in Form';
			}
        }
        return array('id' => $id, 'form' => $form, 'error' => $error, 'success' => $success, 'flashMessages' => $this->flashMessenger()->getMessages());
    }

    public function deleteAction()
    {
       	$error =array();	#Error variable
		$success =array();	#success message variable
	   // echo "hello";exit;
	    $id = (int)$this->params('id'); 
        if (!$id) {
            return $this->redirect()->toRoute('admin/admin-planet-tags');
        }
		$groupTag = $this->getGroupTagTable()->getGroupTag($id);	
		if(isset($groupTag->group_tag_id) && !empty($groupTag->group_tag_id)){
			
		}else{
			return $this->redirect()->toRoute('admin/admin-planet-tags', array('action'=>'index'));
		} 		
		
        $request = $this->getRequest();
        if ($request->isPost()) {
            $del = $request->getPost()->get('del', 'No');
            if ($del == 'Yes') {
                $id = (int)$request->getPost()->get('id');
                $this->getGroupTagTable()->deleteGroupTag($id);
            }
            // Redirect to list of tags
            return $this->redirect()->toRoute('admin/admin-planet-tags');
        } 	 
		$data = $this->getGroupTagTable()->getGroupTag($id);	
		 
        return array(
            'id' => $id, 'groupTag' => $groupTag,		 
			'error' => $error, 'success' => $success, 'flashMessages' => $this->flashMessenger()->getMessages()
        );
    }	 
	
	#accessing the user table module
	public function getUserTable()
    {
        if (!$this->userTable) {
            $sm = $this->getServiceLocator();
            $this->userTable = $sm->get('User\Model\UserTable');
        }
        return $this->userTable;
    }
	
	#accessing the user profile table module
	public function getUserProfileTable()
    {
        if (!$this->userProfileTable) {
            $sm = $this->getServiceLocator();
            $this->userProfileTable = $sm->get('User\Model\UserProfileTable');
        }
        return $this->userProfileTable;
    }
	
	#accessing the user table module
	public function getGroupTable()
    {
        if (!$this->groupTable) {
            $sm = $this->getServiceLocator();
            $this->groupTable = $sm->get('Group\Model\GroupTable');
        }
        return $this->groupTable;
    }
	
	#Accessing the tag table
	public function getTagTable()
    {
        if (!$this->tagTable) {
            $sm = $this->getServiceLocator();
            $this->tagTable = $sm->get('Tag\Model\TagTable');
        }
        return $this->tagTable;
    }
	
	#Accessing the Group tag table
	public function getGroupTagTable()
    {
        if (!$this->groupTagTable) {
            $sm = $this->getServiceLocator();
            $this->groupTagTable = $sm->get('Tag\Model\GroupTagTable');
        }
        return $this->groupTagTable;
    }
}