<?php 
namespace Groups\Controller;
use Zend\Authentication\AuthenticationService;
use Zend\Mvc\Controller\AbstractActionController;
use Zend\View\Model\ViewModel;	//Return model 
use Groups\Model\Groups; 
use User\Model\User; 
use Groups\Model\UserGroup;
use Notification\Model\UserNotification;
class GroupsController extends AbstractActionController
{
	protected $groupTable;
	protected $groupThumb ="";	
	protected $Group_Timeline_Path="";	//Image path of Group Timelime
	protected $Group_Thumb_Smaller ="";
	protected $photoTable="";
	protected $userGroupRequestTable;
	protected $userGroupTable;
	protected $groupTagTable=""; 
	protected $ActivityController;
	protected $userNotificationTable;
	public function __construct()
    {
        // do some stuff!
		$this->groupThumb = Groups::Group_Thumb_Path;  
		$this->Group_Timeline_Path = Groups::Group_Timeline_Path;  
		$this->Group_Thumb_Smaller = Groups::Group_Thumb_Smaller; 
    }
	public function indexAction()
    {			
		$auth = new AuthenticationService();
		if ($auth->hasIdentity()) {
			$identity = $auth->getIdentity();
			$this->layout()->identity = $identity;
			$allGroups = $this->getGroupTable()->fetchAllGroups();
			$viewModel = new ViewModel(array('allGroups' => $allGroups, 'groupThumb' => $this->groupThumb));
			return $viewModel;
		}
		else{	
			return $this->redirect()->toRoute('user/login', array('action' => 'login'));
		}
	}
	public function planetAction(){
		$auth = new AuthenticationService();
		if ($auth->hasIdentity()) {
			$identity = $auth->getIdentity();
			$this->layout()->identity = $identity;
			$group_seo = $this->getEvent()->getRouteMatch()->getParam('group_id'); 
			$planet_seo = $this->getEvent()->getRouteMatch()->getParam('planet_id'); 
			if($group_seo!=''){
			$groupdetails = $this->getGroupTable()->getGroupIdFromSEO($group_seo);
			$group_id = $groupdetails->group_id;
			$allplanet = $this->getGroupTable()->getPlanets($group_id);
			$viewModel = new ViewModel(array('allGroups' => $allplanet, 'groupThumb' => $this->groupThumb,'parent_details'=>$groupdetails));
				return $viewModel;
			}
			else{
				return $this->redirect()->toRoute('group', array('action' => 'index'));
			}
		}
		else{	
			return $this->redirect()->toRoute('user/login', array('action' => 'login'));
		}
	}
	public function planethomeAction(){
		$auth = new AuthenticationService();
		if ($auth->hasIdentity()) {
			$identity = $auth->getIdentity();
			$this->layout()->identity = $identity;
			$group_seo = $this->getEvent()->getRouteMatch()->getParam('group_id'); 
			$planet_seo = $this->getEvent()->getRouteMatch()->getParam('planet_id'); 
			if($group_seo!=''){
				$groupdetails = $this->getGroupTable()->getGroupIdFromSEO($group_seo);
				$group_id = $groupdetails->group_id;
				$planetdetails =  $this->getGroupTable()->getGroupIdFromSEO($planet_seo);
				$planet_id = $planetdetails->group_id;
				if($group_id && $planet_id){
					$subGroupPhotoData = $this->getPhotoTable()->getPhoto($planetdetails->group_photo_id);
					$groupTag =	$this->getGroupTagTable()->fetchAllTagsOfGroup($planetdetails->group_id);
					$userSubGroupData =$this->getUserGroupTable()->getUserGroup($identity->user_id, $planet_id);
					$groupActivityWidget = $this->forward()->dispatch('Activity\Controller\Activity', array('action' => 'activitydetail', 'group_id' => $planetdetails->group_id));	
					//$viewModel = new ViewModel(array('planetdetails' => $planetdetails, 'groupThumb' => $this->groupThumb,'parent_name'=>$groupdetails->group_title));
					$viewModel = new ViewModel(array('groupThumb' => $this->groupThumb, 'Group_Timeline_Path' => $this->Group_Timeline_Path, 'Group_Thumb_Smaller' => $this->Group_Thumb_Smaller, 'groupData' => $groupdetails, 'subGroupData' => $planetdetails, 'subGroupPhotoData' => $subGroupPhotoData,'userSubGroupData' => $userSubGroupData, 'groupTag' => $groupTag));
					if(!empty($groupActivityWidget)){	
						$viewModel->addChild($groupActivityWidget, 'groupActivityWidget');	
					}
					return $viewModel;
				}
				else{
					return $this->redirect()->toRoute('groups', array('action' => 'index'));
				}			
			}
			else{
				return $this->redirect()->toRoute('groups', array('action' => 'index'));
			}
		}
		else{	
			return $this->redirect()->toRoute('user/login', array('action' => 'login'));
		}
	}
	public function joinAction(){
		$group_id=  $this->params('gid');
		$auth = new AuthenticationService();
		if ($auth->hasIdentity()) {
			if($group_id){
				$identity = $auth->getIdentity();
			$subGroupData = $this->getGroupTable()->getSubGroup($group_id);
			if(isset($subGroupData->group_id) && !empty($subGroupData->group_id) && isset($subGroupData->group_parent_group_id) && trim($subGroupData->group_parent_group_id)!="0"){	
				$subGroupAlreadyRegisterInfo =$this->getUserGroupTable()->getUserGroup($identity->user_id, $subGroupData->group_id);
				if(isset($subGroupAlreadyRegisterInfo->user_group_id) && !empty($subGroupAlreadyRegisterInfo->user_group_id)){	 
					$arr = array('error' => "yes", 'status' => "You are already registered for this Planet");
					 						 
				}else{	
					$groupAlreadyRegisterInfo =array();
					$groupAlreadyRegisterInfo =$this->getUserGroupTable()->getUserGroup($identity->user_id, $subGroupData->group_parent_group_id);
					if(empty($groupAlreadyRegisterInfo->user_group_id)){
						$userGroupData = array();
						$userGroupData['user_group_user_id'] = $identity->user_id;
						$userGroupData['user_group_group_id'] = $subGroupData->group_parent_group_id;
						#create object of User class								  
						$userGroupData['user_group_added_ip_address'] = user::getUserIp();
						$userGroupData['user_group_status'] = "1";
						$userGroupData['user_group_is_owner'] = "0";
						$userGroup = new UserGroup();
						$userGroup->exchangeArray($userGroupData);
						$insertedUserGroupId ="";
						$insertedUserGroupId = $this->getUserGroupTable()->saveUserGroup($userGroup);
						if(isset($insertedUserGroupId) && !empty($insertedUserGroupId)){
							 #do Nothing
						}else{
							$arr = array('error' => "yes", 'status' => "An error is occured while saving Galaxy.Please try again");
						 
						}	
					}
					$userGroupData = array();
					$userGroupData['user_group_user_id'] = $identity->user_id;
					$userGroupData['user_group_group_id'] = $subGroupData->group_id;
					#create object of User class
					$userGroupData['user_group_added_ip_address'] = user::getUserIp();
					$userGroupData['user_group_status'] = "1";
					$userGroupData['user_group_is_owner'] = "0";
					#lets Save the User
					$userGroup = new UserGroup();
					$userGroup->exchangeArray($userGroupData);
					$insertedUserGroupId ="";	#this will hold the latest inserted id value
					$insertedUserGroupId = $this->getUserGroupTable()->saveUserGroup($userGroup); 
					
					
					
					#send the Notification to User
					$UserGroupNotificationData = array();						
					$UserGroupNotificationData['user_notification_user_id'] = $identity->user_id;									
					$UserGroupNotificationData['user_notification_content'] = "You have successfully <a href='/profile'><b>".$subGroupData->group_title."</b></a>";						$UserGroupNotificationData['user_notification_added_timestamp'] = date('Y-m-d H:i:s');
					$userObject = new user(array());
					$UserGroupNotificationData['user_notification_notification_type_id'] = "1";
					$UserGroupNotificationData['user_notification_status'] = 0;			
					
													 
													
					#lets Save the User Notification
					$UserGroupNotificationSaveObject = new UserNotification();
					$UserGroupNotificationSaveObject->exchangeArray($UserGroupNotificationData);							
					$insertedUserGroupNotificationId ="";	#this will hold the latest inserted id value
					$insertedUserGroupNotificationId = $this->getUserNotificationTable()->saveUserNotification($UserGroupNotificationSaveObject);
					if(isset($insertedUserGroupId) && !empty($insertedUserGroupId)){
						$arr = array('error' => "no", 'status' => "Planet added successfully to the user");					 
					}else{
						$arr = array('error' => "yes", 'status' => "An error is occured while saving Planet.Please try again");
					 
					}
				}
			}
			else { 
				$arr = array('error' => "yes", 'status' => "Invalid Access. Planet does not exist");
			}		
			}
			else { 
				$arr = array('error' => "yes", 'status' => "Invalid Access. Planet does not exist");
			}		
		}
		else{
			$arr = array('error' => "yes", 'status' => "Invalid Access. You need to login");				 	
		}
		echo json_encode($arr);die();
	}
	protected function loadPlanetMembersAction() {   
		try{
			$auth = new AuthenticationService();
			
			if ($auth->hasIdentity()) { 
				$error = array();
				$userData = array();
				$groupUsersList = array();
				$groupData = array();
				$subGroupData = array();
				$identity = $auth->getIdentity();
				$this->layout()->identity = $identity;
				$request   = $this->getRequest();
				$group_id = $this->params('group_id');
				$sm = $this->getServiceLocator(); 
				if($group_id!=''){
					$this->groupTable = $sm->get('Groups\Model\GroupsTable');
					$groupData = $this->groupTable->getGroupForName($group_id);
					if(!empty($groupData)){
						$sub_group_id = $this->params('sub_group_id');
						if($sub_group_id!=''){
							$subGroupData = $this->groupTable->getSubGroupForSEO($sub_group_id);
							if(!empty($subGroupData)){
								$this->userTable = $sm->get('User\Model\UserTable');
								$userData = $this->userTable->getUser($identity->user_id);              
								$this->userGroupTable = $sm->get('Groups\Model\UserGroupTable');
								$groupUsersList = $this->userGroupTable->fetchAllUserListForGroup($groupData->group_id);
							}else{
								$error[] = 'Invalid Planet';
							}
						}else{
							$error[] = 'Invalid Planet';
						}
					}
					else{
						$error[] = 'Invalid Planet';
					}
				}
				else{
					$error[] = 'Invalid access';
				}
			}else{
				return $this->redirect()->toRoute('user/login', array('action' => 'login'));
			}         
			$viewModel = new ViewModel(array('users' => $userData, 'groupUsersList' => $groupUsersList, 'groupData' => $groupData, 'subGroupData' => $subGroupData,'error'=>$error));
			$viewModel->setTerminal($request->isXmlHttpRequest());
			return $viewModel;
		} catch (\Exception $e) {
			//	echo "Caught exception: " . get_class($e) . "\n";
   			//	echo "Message: " . $e->getMessage() . "\n";			 
   		}   

    }
	public function getActivityController(){
		if (!$this->ActivityController) {
            $sm = $this->getServiceLocator();
            $this->ActivityController = $sm->get('Activity\Controller\Activity');
        }
        return $this->ActivityController;
	}
	 public function getGroupTagTable()
    {
        if (!$this->groupTagTable) {
            $sm = $this->getServiceLocator();
            $this->TagTable = $sm->get('Tag\Model\GroupTagTable');
        }
        return $this->TagTable;
    }
	public function getGroupTable()
    {
        if (!$this->groupTable) {
            $sm = $this->getServiceLocator();
			$this->groupTable = $sm->get('Groups\Model\GroupsTable');
        }
        return $this->groupTable;
    }
	 public function getPhotoTable()
    {
        if (!$this->photoTable) {
            $sm = $this->getServiceLocator();
            $this->photoTable = $sm->get('Photo\Model\PhotoTable');
        }
        return $this->photoTable;
    } 
	 public function getUserGroupTable()
    {
        if (!$this->userGroupTable) {
            $sm = $this->getServiceLocator();
			$this->userGroupTable = $sm->get('Groups\Model\UserGroupTable');
        }
        return $this->userGroupTable;
    }
	public function getUserNotificationTable()
    {
        if (!$this->userNotificationTable) {
            $sm = $this->getServiceLocator();
            $this->userNotificationTable = $sm->get('Notification\Model\UserNotificationTable');
        }
        return $this->userNotificationTable;
    }
	
}