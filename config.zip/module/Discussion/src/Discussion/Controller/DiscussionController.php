<?php   
####################Discussion Controller #################################

namespace Discussion\Controller;

use Zend\Mvc\Controller\AbstractActionController;
use Zend\View\Model\ViewModel;	//Return model 
use Zend\Session\Container; // We need this when using sessions     
use Zend\Authentication\AuthenticationService;	//Needed for checking User session
use Zend\Authentication\Adapter\DbTable as AuthAdapter;	//Db adapter
use Zend\Crypt\BlockCipher;		# For encryption

#Group class
use Groups\Model\Groups;  	#Planet/Galaxy class
use User\Model\User;  	#User class
use Groups\Model\GroupsTable; #Planet/Galaxy table class
use Groups\Model\UserGroup;	#user group class

#discussion form
use \Exception;		#Exception class for handling exception
use Discussion\Model\Discussion; #Discussion class for loading Discussion
use Comment\Model\Comment; #comment class for loading discussion comment
use Discussion\Form\DiscussionForm;
use Discussion\Form\DiscussionFilter;  

class DiscussionController extends AbstractActionController
{
    protected $groupTable;		#variable to hold the group model configuration
	protected $userGroupTable;	#variable to hold the user group model configuration
	protected $userTable;		#variable to hold the user model configuration
	protected $userProfileTable;	#variable to hold the user profile model configuration
	protected $discussionTable;		#variable to hold the discussion model configuration
	protected $commentTable;		#variable to hold the discussion model configuration
	protected $remoteAddr;
	
	public function __construct()
	{
		return $this;
	}
	
	#load the css and javascript need for particular action
	protected function getViewHelper($helperName)
	{
		return $this->getServiceLocator()->get('viewhelpermanager')->get($helperName);
	}
   
 	#It is not using right now
    public function indexAction()
    {		
		$error = array();
		$success = array();
		$subGroupId = "";
		$userData = array();
		$groupData = array();
		$subGroupData = array();
		$discussions = array();
		$auth = new AuthenticationService();	
		$sm = $this->getServiceLocator();
		$SystemTypeId = 'Discussion';
		$form = '';
		$identity = null;
		if ($auth->hasIdentity()) {
			$identity = $auth->getIdentity();				
			$this->layout()->identity = $identity;
			$request = $this->getRequest();
			$GroupId = $this->params('group_id'); 				
			$subGroupId = $this->params('sub_group_id');
			$groupData = array();
			$subGroupData = array();
			if($subGroupId!=''&&$GroupId!=''){
				$this->groupTable = $sm->get('Groups\Model\GroupsTable');
				$subGroupData = $this->groupTable->getSubGroupForName($subGroupId);	
				$form = new DiscussionForm();
				$form->setInputFilter(new DiscussionFilter());
				$form->setData($request->getPost());
				if ($request->isPost()) {
					$this->discussionTable = $sm->get('Discussion\Model\DiscussionTable');
					if ($form->isValid()) {
						$this->remoteAddr = $sm->get('ControllerPluginManager')->get('GenericPlugin')->getRemoteAddress();
						$post = $request->getPost();
						$group_discussion_content = $post->get('group_discussion_content');
						$discussionData = array();
						$discussionData['group_discussion_content'] = $group_discussion_content;
						$discussionData['group_discussion_owner_user_id'] = $identity->user_id;
						$discussionData['group_discussion_group_id'] = $subGroupData->group_id;
						#create object of User class
						$discussionData['group_discussion_added_ip_address'] =  $this->remoteAddr;
						$discussionData['group_discussion_modified_ip_address'] =  $this->remoteAddr;
						$discussionData['group_discussion_modified_timestamp'] = date("Y-m-d H:i:s");
						$discussionData['group_discussion_status'] = 1;						 						
						
						#lets Save the User
						$discussionObject = new discussion();
						$discussionObject->exchangeArray($discussionData);
						
						$inserteddiscussionId = "";	#this will hold the latest inserted id value
						$inserteddiscussionId = $this->discussionTable->saveDiscussion($discussionObject); 
						
						if(!isset($inserteddiscussionId) && empty($inserteddiscussionId)) {
							 $error[] = 'Oops an error has occured while posting discussion';	
						}
					}						
				}
				$groupData = $this->groupTable->getGroup($subGroupData->group_parent_group_id);
				$this->discussionTable = $sm->get('Discussion\Model\DiscussionTable');
				$SystemTypeData = $this->groupTable->fetchSystemType($SystemTypeId);
				$discussions = $this->discussionTable->getGroupAllDiscussionWithLikes($subGroupData->group_id,$SystemTypeData->system_type_id,$identity->user_id);
			}
			else{
				$error[] = "The roups you are requested is not existing in this system";
			}
			$viewModel = new ViewModel(array('form' => $form, 'groupData' => $groupData,'subGroupData' => $subGroupData,'discussions' =>$discussions,'error' => $error, 'success' => $success, 'flashMessages' => $this->flashMessenger()->getMessages(),'discussion_page'=>1));
			$viewModel->setTerminal($request->isXmlHttpRequest());
			return $viewModel;	
		}
		else{
			return $this->redirect()->toRoute('user/login', array('action' => 'login'));
		}		 
    }
	public function loadmoreAction(){
		$error = array();
		$success = array();
		$sm = $this->getServiceLocator();
		$auth = new AuthenticationService();
		if ($auth->hasIdentity()) {
			$identity = $auth->getIdentity();
			$planet_id= $this->params('planet_id');
			if(isset($identity->user_id) && !empty($identity->user_id) && isset($planet_id) && !empty($planet_id)){
				$this->groupTable = $sm->get('Groups\Model\GroupsTable');
				$subGroupData = $this->groupTable->getSubGroup($planet_id);
				$groupData = $this->groupTable->getGroup($subGroupData->group_parent_group_id);
				if(!empty($subGroupData)){
					$page = 0;
					$request   = $this->getRequest();				 		
					$post = $request->getPost();		
					if ($request->isPost()){
						$page =$post->get('page');
						if(!$page)
						$page = 0;
					}
					$offset = $page*10;
					$this->discussionTable = $sm->get('Discussion\Model\DiscussionTable');
					$SystemTypeData = $this->groupTable->fetchSystemType('Discussion');
					$discussions = $this->discussionTable->getGroupAllDiscussionWithLikes($subGroupData->group_id,$SystemTypeData->system_type_id,$identity->user_id,$offset);
					$viewModel = new ViewModel(array('groupData' => $groupData,'subGroupData' => $subGroupData,'discussions' =>$discussions,'error' => $error, 'success' => $success, 'flashMessages' => $this->flashMessenger()->getMessages(),'discussion_page'=>$page+1));
					$viewModel->setTerminal($request->isXmlHttpRequest());
					return $viewModel;
				}
				else{	
					$error[] = 'Unauthorized access';
				}
			}else{
				$error[] = 'Unauthorized access';
			}
		}
		else{
			return $this->redirect()->toRoute('user/login', array('action' => 'login'));
		}
	}
	
	#Fetch All the Discussion of a Planet .This will used in Profile page as ajax Call
    public function discussionAction()
    {	
		$sm = $this->getServiceLocator(); 
		$sm->get('ControllerPluginManager')->get('GenericPlugin')->getHeaderFiles();
		
		$error = array();	#Error variable
		$success = array();	#success message variable
		
		$subGroupId = "";	//Id of Planet 
		$userData = array();	///this will hold data from y2m_user table
		$groupData = array();	//This will hold data for Galaxy
		$subGroupData = array();	//This will hold the data for Planet
		$discussions = array();	//this will hold all the activites of Planet
		
		try {
		
			$request   = $this->getRequest();		
			$subGroupId= $this->params('group_id'); 			
			$auth = new AuthenticationService();	
			$identity = null; 
			
			if ($auth->hasIdentity()) {
            	// Identity exists get it
           		$identity = $auth->getIdentity();
				
				#check the identity against the DB
				$this->userTable = $sm->get('User\Model\UserTable');
				$userData = $this->userTable->getUser($identity->user_id);		

				$this->discussionTable = $sm->get('Discussion\Model\DiscussionTable');
				$this->groupTable = $sm->get('Group\Model\GroupTable');
							
				if(isset($userData->user_id) && !empty($userData->user_id) && isset($subGroupId) && !empty($subGroupId)){				
					#Get Planet Info
					$subGroupData = $this->groupTable->getSubGroup($subGroupId);	
					if(isset($subGroupData->group_id) && !empty($subGroupData->group_id) && isset($subGroupData->group_parent_group_id) && !empty($subGroupData->group_parent_group_id)){						
						#fetch the Galaxy Info
						$groupData = $this->groupTable->getGroup($subGroupData->group_parent_group_id);	
						
						#fetch all activity of Planet
						$discussions = $this->discussionTable->getGroupAlldiscussion($subGroupData->group_id);						
					} 
				} 
			} 	
		} catch (\Exception $e) {
			//	echo "Caught exception: " . get_class($e) . "\n";
   			//	echo "Message: " . $e->getMessage() . "\n";			 
   		}   		
   		$viewModel = new ViewModel(array('userData' => $userData,'groupData' => $groupData,'subGroupData' => $subGroupData,'discussions' =>$discussions,'error' => $error, 'success' => $success, 'flashMessages' => $this->flashMessenger()->getMessages()));
    	$viewModel->setTerminal($request->isXmlHttpRequest());
    	return $viewModel;	   
    }
	
}
