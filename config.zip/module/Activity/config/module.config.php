<?php
return array(
    'controllers' => array(
        'invokables' => array(
            'Activity\Controller\Activity' => 'Activity\Controller\ActivityController',
        ),
    ),

    // The following section is new and should be added to your file
    'router' => array(
        'routes' => array(
            'activity' => array(
                'type' => 'Literal',
                'priority' => 1000,
                'options' => array(
                    'route' => '/activity',
                    'defaults' => array(
						'__NAMESPACE__' => 'Activity\Controller',
                        'controller' => 'activity',
                        'action'     => 'index',
                    ),
                ),
                'may_terminate' => true,
                'child_routes' => array(
                    'activity-group' => array(
                        'type' => 'segment',
                        'options' => array(
                            'route' => '/group/[:group_id]',
                            'constraints' => array(
								'group_id' => '[a-zA-Z0-9_-]*',											 
							),
							'defaults' => array(
								'__NAMESPACE__' => 'Activity\Controller',
								'controller' => 'activity',
								'action'     => 'index',
							),
                        ),					 
                    ),
					'activity-rsvp' => array(
                        'type' => 'Literal',
                        'options' => array(
                            'route' => '/rsvp',
                            'defaults' => array(
								'__NAMESPACE__' => 'Activity\Controller',
								'controller' => 'activity',
								'action'     => 'activityrsvp',
							),
                        ),					 
                    ),
					'quit-rsvp' => array(
                        'type' => 'Literal',
                        'options' => array(
                            'route' => '/quitrsvp',
                            'defaults' => array(
								'__NAMESPACE__' => 'Activity\Controller',
								'controller' => 'activity',
								'action'     => 'quitrsvp',
							),
                        ),					 
                    ),
					
					'activity-view' => array(
                        'type' => 'segment',
						'options' => array(
                           	'route'    => '/view[/:action][/:id]',
							'constraints' => array(
								'action' => '[a-zA-Z][a-zA-Z0-9_-]*',
								'id'     => '[0-9]+',
							),
                            'defaults' => array(
								'__NAMESPACE__' => 'Activity\Controller',
                                'controller' => 'activity',
                                'action'     => 'view',
                            ),
                        ),
                      					 
                    ),
					'activity-calendar' => array(
                        'type' => 'Literal',
                        'options' => array(
                            'route' => '/calendar',
                            'defaults' => array(
								'__NAMESPACE__' => 'Activity\Controller',
								'controller' => 'activity',
								'action'     => 'calendar',
							),
                        ),					 
                    ),
					'join' => array(
                        'type' => 'segment',
                        'options' => array(
                            'route' => '/join/[:planet_id]',
                            'constraints' => array(
								'planet_id' => '[a-zA-Z0-9_-]*',											 
							),
							'defaults' => array(
								'__NAMESPACE__' => 'Activity\Controller',
								'controller' => 'activity',
								'action'     => 'join',
							),
                        ),					 
                    ),
					'loadmore' => array(
                        'type' => 'segment',
                        'options' => array(
                            'route' => '/loadpastevents/[:planet_id]',
                            'constraints' => array(
								'planet_id' => '[a-zA-Z0-9_-]*',											 
							),
							'defaults' => array(
								'__NAMESPACE__' => 'Activity\Controller',
								'controller' => 'activity',
								'action'     => 'loadpastevents',
							),
                        ),					 
                    ),
                ),
            ),
        ),
    ),

    'view_manager' => array(
        'template_path_stack' => array(
            'activity' => __DIR__ . '/../view',
        ),
    ),
);
