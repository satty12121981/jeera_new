var tag_page = 1;
$(document).ready(function(){
	$("#user_login").submit(function(e){		 
		e.preventDefault();
		$(".login-butn").html("<img src='"+baseurl+"/public/images/ajax_loader.gif' />");
		$(".login_error").html('');
		var url = $("#user_login").attr("action");
		$.ajax({
		type: "POST",
		url:url,
		data:$("#user_login").serialize(),
		dataType: "json", 
		success:function(result) {
			if(result.error){
				$(".login-butn").html('<input type="image" src="'+baseurl+'/public/images/signin-butn.png" alt="Login" />');
				$(".login_error").html(result.msg);
			}
			else{
				window.location.reload();
			}
		}});
	});
	$("#user_profile_country_id").change(function(){
		var country_id = $(this).val();
		var url = baseurl+'/city/cities';
		 $(".signup-location-right").html("<img src='"+baseurl+"/public/images/ajax_loader.gif' />");
		$.ajax({
		type: "POST",
		url:url,
		data:{country_id:country_id},		
		success:function(result) {
			 $(".signup-location-right").html(result);
			$('select.styled').customSelect();			 
		}});		
	});
	$("#tag_list .add-option").live("click",function(){
		var selected_tag_id = $(this).attr('id');
		var selected_tag	= $(this).text();
		var search_string = $("#tag_search").val();
		$(this).remove();
		$("#added_items").append('<a class="add-option" href="javascript:void(0)" id="'+selected_tag_id+'">'+selected_tag+'</a>');
		var url = baseurl+'/user/ajaxgettag';
		$.ajax({
		type: "POST",
		url:url,
		data:{page:tag_page,search_string:search_string},		
		success:function(result) {
			$("#tag_list").append(result);
			tag_page=tag_page+1;
		}});
	});
	$("#added_items .add-option").live("click",function(){
		$(this).remove();
	});
	$("#btn_search_tag").live("click",function(){
		var url = baseurl+'/user/tagsearch';
		var search_string = $("#tag_search").val();
		$.ajax({
		type: "POST",
		url:url,
		data:{search_string:search_string},		
		success:function(result) {
			$("#tag_list .add-option").remove();
			$("#tag_list").append(result);
			tag_page=1;
		}});
	});
	$("#tag_submit").live("click",function(){
		var id = $("#added_items .add-option").attr('id').substring(1);
		var tags = new Array();
		var i=0;
		$.each($('#added_items .add-option'), function() {
			tags[i] = this.id ;i++;
		});
		var str_tag = tags.join('~');
		var url = baseurl+'/user/register';
		 var form = document.createElement("form");
			$(form).attr("action", url)
				   .attr("method", "post");
			$(form).html('<input type="hidden" name="tags" value="' + str_tag + '" />');
			document.body.appendChild(form);
			$(form).submit();
			document.body.removeChild(form);
	});
});
