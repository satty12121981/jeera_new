<?php
####################Activity Table Model #################################

#########################################################################
namespace Activity\Model;
use Zend\Db\Sql\Select , \Zend\Db\Sql\Where;

use Zend\Db\TableGateway\AbstractTableGateway;
use Zend\Db\Adapter\Adapter;
use Zend\Db\ResultSet\ResultSet;
use Zend\Db\Sql\Expression;
class ActivityTable extends AbstractTableGateway
{
    protected $table = 'y2m_group_activity'; 	
    public function __construct(Adapter $adapter)
    {
        $this->adapter = $adapter;
        $this->resultSetPrototype = new ResultSet();
        $this->resultSetPrototype->setArrayObjectPrototype(new Activity());
        $this->initialize();
    }
	
	public function fetchAll($where=Null, $order=Null, $limit=Null, $offset=Null)
    { 	  
		$resultSet = $this->select(function (Select $select) use ($where, $order, $limit, $offset) {		 
			$select->join('y2m_user', 'y2m_user.user_id = y2m_group_activity.group_activity_owner_user_id', array('user_id','user_given_name', 'user_first_name', 'user_middle_name', 'user_last_name', 'user_email'));				
			$select->join('y2m_photo', 'y2m_photo.photo_id = y2m_user.user_profile_photo_id', array('photo_name'),$select::JOIN_LEFT);	
			$select->join('y2m_group', 'y2m_group.group_id = y2m_group_activity.group_activity_group_id', array('group_title', 'group_seo_title'));		
			$select->join(array('p' => 'y2m_group'), 'p.group_id = y2m_group.group_parent_group_id', array('parent_group_id' => 'group_id', 'parent_group_title' => 'group_title', 'parent_group_seo_title' => 'group_seo_title'));
			//$select->columns(array('parent_title' => 'group_title'));	
			if($where){	$select->where($where); }
			if($order){ $select->order($order); }
			if($limit){ $select->limit($limit); }
			if($offset){ $select->offset($offset);  }		
			//echo $select->getSqlString();exit;
		});		 
		return $resultSet;
    }
		public function fetchAll_upcoming($where=Null, $order=Null, $limit=Null, $offset=Null)
    { 	  $current_date = date('Y-m-d H:i:s');	
		$resultSet = $this->select(function (Select $select) use ($where, $order, $limit, $offset,$current_date) {		 
			$select->join('y2m_user', 'y2m_user.user_id = y2m_group_activity.group_activity_owner_user_id', array('user_id','user_given_name', 'user_first_name', 'user_middle_name', 'user_last_name', 'user_email'));				
			$select->join('y2m_photo', 'y2m_photo.photo_id = y2m_user.user_profile_photo_id', array('photo_name'),$select::JOIN_LEFT);	
			$select->join('y2m_group', 'y2m_group.group_id = y2m_group_activity.group_activity_group_id', array('group_title', 'group_seo_title'));		
			$select->join(array('p' => 'y2m_group'), 'p.group_id = y2m_group.group_parent_group_id', array('parent_group_id' => 'group_id', 'parent_group_title' => 'group_title', 'parent_group_seo_title' => 'group_seo_title'));
			//$select->join('y2m_group_activity_invite', 'y2m_group_activity_invite.group_activity_invite_activity_id = y2m_group_activity.group_activity_id', array('group_activity_invite_sender_user_id', 'group_activity_invite_receiver_user_id'));	

			//$select->columns(array('parent_title' => 'group_title'));	
			$select->where->greaterThan('y2m_group_activity.group_activity_start_timestamp' , $current_date);
			if($where){	$select->where($where); }
			if($order){ $select->order($order); }
			if($limit){ $select->limit($limit); }
			if($offset){ $select->offset($offset);  }		
			//echo $select->getSqlString();exit;
		});		 
		return $resultSet;
    }
		public function fetchAll_past($where=Null, $order=Null, $limit=Null, $offset=Null)
    { 	  $current_date = date('Y-m-d H:i:s');	
		$resultSet = $this->select(function (Select $select) use ($where, $order, $limit, $offset,$current_date) {		 
			$select->join('y2m_user', 'y2m_user.user_id = y2m_group_activity.group_activity_owner_user_id', array('user_id','user_given_name', 'user_first_name', 'user_middle_name', 'user_last_name', 'user_email'));				
			$select->join('y2m_photo', 'y2m_photo.photo_id = y2m_user.user_profile_photo_id', array('photo_name'),$select::JOIN_LEFT);	
			$select->join('y2m_group', 'y2m_group.group_id = y2m_group_activity.group_activity_group_id', array('group_title', 'group_seo_title'));		
			$select->join(array('p' => 'y2m_group'), 'p.group_id = y2m_group.group_parent_group_id', array('parent_group_id' => 'group_id', 'parent_group_title' => 'group_title', 'parent_group_seo_title' => 'group_seo_title'));
			//$select->columns(array('parent_title' => 'group_title'));	
			$select->where->lessThan('y2m_group_activity.group_activity_start_timestamp' , $current_date);
			if($where){	$select->where($where); }
			if($order){ $select->order($order); }
			if($limit){ $select->limit($limit); }
			if($offset){ $select->offset($offset);  }		
			//echo $select->getSqlString();exit;
		});		 
		return $resultSet;
    }
	
	//=====================Admin Actions==========================
	
	public function Admin_get_activity($activity_id)
	{ 
	
	    $activity_id  = (int) $activity_id;

	    $resultSet = $this->select(function (Select $select) use ($activity_id) {
            $select
                ->join('y2m_user','y2m_user.user_id = y2m_group_activity.group_activity_owner_user_id', array('user_id','user_given_name'))
                ->join('y2m_group','y2m_group.group_id = y2m_group_activity.group_activity_group_id', array('group_id','group_title'))
                ->where('group_activity_id = '.$activity_id);
        });

        $result = $resultSet->current();
	
	    return $result;

	}
	
	public function Admin_block_activity($activity_id)
	{
	   $activity_id  = (int) $activity_id;
       $data = array('group_activity_status' => 2);
       $result = '';	   
	   if($this->update($data, array('group_activity_id' => $activity_id)))
	   {
	    $result = 'success';
	   }else{
		$result = 'fail';
	   }
	   return $result;
	   
	}
	
	public function Admin_unblock_activity($activity_id)
	{ 
       $data = array('group_activity_status' => 1);
       $result = '';	   
	   if($this->update($data, array('group_activity_id' => $activity_id)))
	   {
	    $result = 'success';
	   }else{
		$result = 'fail';
	   }
	   return $result;
	}
	
	//=====================Admin Actions========================
	#this will fetch activity details based primary key. Group Activity Id
    public function getActivity($group_activity_id)
    {
        $group_activity_id  = (int) $group_activity_id;
        $rowset = $this->select(array('group_activity_id' => $group_activity_id));
        $row = $rowset->current();
        return $row;
    }
	
	//this will fetch the activites of a Galaxy
	public function getGroupAllActivity($group_id){        
       	$group_id = (int) $group_id; 
		$resultSet = $this->select(function (Select $select) use ($group_id) {
			$select->where(array('group_activity_group_id', $group_id));
			$select->order('group_activity_added_timestamp DESC');
		});			 	
		return $resultSet;	 
    }
	
	//THis function will be used for calender for fetching activites of User register
	public function getUserJoinedActivityForCalender($year, $month, $user_id)
    {
		$year = (int) $year;
		$month = (int) $month;
		$user_id = (int) $user_id;
		
		$startDate ='';
		$endDate ='';	#it will be 30 days after the start date
		
		#create start date
		$date = new \DateTime($year.'-'.$month.'-01');
		$startDate =$date->format('Y-m-d H:i:s');
		
		#create end date
		$date = new \DateTime($year.'-'.$month.'-01');
		$date->add(new \DateInterval('P1M'));#it will make make next mont date
		$endDate =$date->format('Y-m-d  H:i:s');		
		$year = (int) $year; 
		$month = (int) $month; 
		$user_id = (int) $user_id; 
		$predicate = new  \Zend\Db\Sql\Where();
		$resultSet = $this->select(function (Select $select) use ($year, $month, $user_id, $predicate, $startDate, $endDate ) {
			$select->join('y2m_group_activity_rsvp', 'y2m_group_activity_rsvp.group_activity_rsvp_activity_id = y2m_group_activity.group_activity_id', array('group_activity_rsvp_user_id'));
			$select->join('y2m_group', 'y2m_group.group_id = y2m_group_activity_rsvp.group_activity_rsvp_group_id', array('group_id'));
			$select->join('y2m_user', 'y2m_user.user_id = y2m_group_activity_rsvp.group_activity_rsvp_user_id', array('user_id'));
			$select->where(array($predicate->between('group_parent_group_id' , "$startDate", "$endDate"), 'y2m_group_activity_rsvp.group_activity_rsvp_user_id', $user_id));
			$select->order('group_activity_added_timestamp DESC');
		});	
	 
		$eventDispayInCalender = array();
		$i=0;
			foreach($resultSet as $row) {
				// echo "<li>".$timestamp = mktime(0,0,0,$cMonth,1,$cYear);
				$tmpArray =array();	//This variable will hold the variables of Date format comming from db for Events
				$tmpArray = explode(" ", $row['group_activity_start_timestamp']);	#seperate date and time
				#we dont need date. Now we will seperate date, time and year
				$tmpArrayDate =array();	
				$tmpArrayDate =explode("-", $tmpArray[0]);		
				$eventDispayInCalender[$i]['date'] = $tmpArrayDate[2];
				$eventDispayInCalender[$i]['month'] = $tmpArrayDate[1];
				$eventDispayInCalender[$i]['year'] = $tmpArrayDate[0];
				$eventDispayInCalender[$i]['even_data'] = $row;					
				$i++;
				//print_r($row);
			}	
			return $eventDispayInCalender;
    }

	// this function will save activity in database
    public function saveActivity(Activity $activity)
    {        
	   $data = array(
            'group_activity_content' => $activity->group_activity_content,
            'group_activity_owner_user_id'  => $activity->group_activity_owner_user_id,
			'group_activity_group_id'  => $activity->group_activity_group_id,
			'group_activity_status'  => $activity->group_activity_status,
			'group_activity_added_timestamp'  => $activity->group_activity_added_timestamp,
			'group_activity_added_ip_address'  => $activity->group_activity_added_ip_address,	
			'group_activity_start_timestamp'  => $activity->group_activity_start_timestamp,		
			'group_activity_title'  => $activity->group_activity_title,		
			'group_activity_location'  => $activity->group_activity_location,		
			'group_activity_modifed_timestamp'  => $activity->group_activity_modifed_timestamp,		
			'group_activity_modified_ip_address'  => $activity->group_activity_modified_ip_address			
        );

        $group_activity_id = (int)$activity->group_activity_id;
        if ($group_activity_id == 0) {
            $this->insert($data);
			return $this->adapter->getDriver()->getConnection()->getLastGeneratedValue();
        } else {
            if ($this->getActivity($group_activity_id)) {
                $this->update($data, array('group_activity_id' => $group_activity_id));
            } else {
                throw new \Exception('Form id does not exist');
            }
        }
    }

	#this function will delete activity in database
    public function deleteActivity($group_activity_id)
    {   $result = "";
        if($this->delete(array('group_activity_id' => $group_activity_id)))
		{
		$result = 'success';
	    }else{
		$result = 'fail';
	    }
	    return $result;
    }
	public function getAllActivityWithLikes($GroupId,$SystemTypeId,$LikeUserId,$offset=0){ 
		$GroupId = (int) $GroupId; 
		$SystemTypeId  = (int) $SystemTypeId;
		$LikeUserId  = (int) $LikeUserId;
		$subselect = new Select;
		$adapter = $this->getAdapter();
		$platform = $adapter->getPlatform();
		$quoteId = $platform->quoteIdentifier($LikeUserId);
		$subselect->from('y2m_group_activity')
			->columns(array(new Expression('COUNT(y2m_like.like_id) as likes_count'),'group_activity_id'=>'group_activity_id'))
			->join('y2m_like', 'y2m_like.like_refer_id = y2m_group_activity.group_activity_id',array())
			->join('y2m_system_type', 'y2m_system_type.system_type_id = y2m_like.like_system_type_id',array())
			->where(array('y2m_group_activity.group_activity_group_id' => $GroupId,'y2m_like.like_system_type_id' => $SystemTypeId))
			->group(array('y2m_group_activity.group_activity_id'))
			->order(array('y2m_group_activity.group_activity_added_timestamp ASC'));
		//echo $subselect->getSqlString();die();
		$commentscount_subselect = new Select;
		$commentscount_subselect->from('y2m_group_activity')
			->columns(array(new Expression('COUNT(y2m_comment.comment_id) as comments_count'),'group_activity_id'=>'group_activity_id'))
			->join('y2m_comment', 'y2m_comment.comment_refer_id = y2m_group_activity.group_activity_id',array())
			->join('y2m_system_type', 'y2m_system_type.system_type_id = y2m_comment.comment_system_type_id',array())
			->where(array('y2m_group_activity.group_activity_group_id' => $GroupId,'y2m_comment.comment_system_type_id' => $SystemTypeId))
			->group(array('y2m_group_activity.group_activity_id'))
			->order(array('y2m_group_activity.group_activity_added_timestamp ASC'));
							
		//sub query to check user exist for the specific discussion of the planet liked
		$alias_subselect = new Select;
		$alias_subselect->from('y2m_group_activity')
			->columns(array('group_activity_id'=>'group_activity_id'))
			->join('y2m_like', 'y2m_like.like_refer_id = y2m_group_activity.group_activity_id',array())
			->join('y2m_system_type', 'y2m_system_type.system_type_id = y2m_like.like_system_type_id',array())
			->join('y2m_user', 'y2m_user.user_id = y2m_like.like_by_user_id',array())
			->where(array('y2m_group_activity.group_activity_id' => new Expression('`final`.`group_activity_id`'),'y2m_user.user_id' => $LikeUserId));
		$expression = new Expression(
		  "IF ( EXISTS(" . @$alias_subselect->getSqlString($adapter->getPlatform()) . ") , `final`.`group_activity_id`, 0)"
		);
		
		//sub query to check user spammed for the specific discussion of the planet
		$alias_subspamselect = new Select;
		$alias_subspamselect->from('y2m_group_activity')
			->columns(array('group_activity_id'=>'group_activity_id'))
			->join('y2m_spam', 'y2m_spam.spam_refer_id = y2m_group_activity.group_activity_id',array())
			->join('y2m_system_type', 'y2m_system_type.system_type_id = y2m_spam.spam_system_type_id',array())
			->join('y2m_problem', 'y2m_problem.problem_id = y2m_spam.spam_problem_id',array())
			->join('y2m_user', 'y2m_user.user_id = y2m_spam.spam_report_user_id',array())
			->where(array('y2m_group_activity.group_activity_id' => new Expression('`final`.`group_activity_id`'),'y2m_user.user_id' => $LikeUserId));
		//user query to select picture
		$alias_subuserprofileselect = new Select;
		$alias_subuserprofileselect->from('y2m_group_activity')
			->columns(array('group_activity_id'=>'group_activity_id','user_id' => new Expression('`y2m_user`.`user_id`'),'user_given_name' => new Expression('`y2m_user`.`user_given_name`'),'photo_location'=> new Expression('`y2m_photo`.`photo_location`'),'photo_name'=> new Expression('`y2m_photo`.`photo_name`')))
			->join('y2m_user', 'y2m_user.user_id = y2m_group_activity.group_activity_owner_user_id',array(),'left')
			->join('y2m_photo', 'y2m_photo.photo_id = y2m_user.user_profile_photo_id',array(),'left')
			->where(array('y2m_group_activity.group_activity_group_id' => $GroupId))
			->group(array('y2m_group_activity.group_activity_id'))
			->order(array('y2m_group_activity.group_activity_added_timestamp ASC'));
		
		$expression1 = new Expression(
		  "IF ( EXISTS(" . @$alias_subspamselect->getSqlString($adapter->getPlatform()) . ") , `final`.`group_activity_id`, 0)"
		);
		//main query
		$current_date = date('Y-m-d H:i:s');
		$mainSelect = new Select;
		$mainSelect->from('y2m_group_activity')
			->join(array('temp' => $subselect), 'temp.group_activity_id = y2m_group_activity.group_activity_id',array('likes_count',"user_check"=>$expression,"spam_user_check"=>$expression1),'left')
			->join(array('temp_comment' => $commentscount_subselect), 'temp_comment.group_activity_id = y2m_group_activity.group_activity_id',array('comments_count'),'left')
			->join(array('temp1' => $alias_subuserprofileselect), 'temp1.group_activity_id = y2m_group_activity.group_activity_id',array('photo_location','photo_name','user_id','user_given_name'),'left')
			->join(array('final'=>'y2m_group_activity'), 'final.group_activity_id = y2m_group_activity.group_activity_id','group_activity_id','left')
			->columns(array('group_activity_content'=>'group_activity_content','group_activity_owner_user_id'=>'group_activity_owner_user_id','group_activity_title'=>'group_activity_title','group_activity_location'=>'group_activity_location','group_activity_start_timestamp'=>'group_activity_start_timestamp'))
            ->where(array('final.group_activity_group_id' => $GroupId))
			->where->lessThan('y2m_group_activity.group_activity_start_timestamp' , $current_date);	   
		$statement = $this->adapter->createStatement();
		$mainSelect->order(array('y2m_group_activity.group_activity_start_timestamp DESC'));
		$mainSelect->limit(10);
		$mainSelect->offset($offset);
		$mainSelect->prepareStatement($this->adapter, $statement);
	//echo $mainSelect->getSqlString();die();
		$resultSet = new ResultSet();
		$resultSet->initialize($statement->execute());	  
		
		return $resultSet;	
	}
	public function fetchAll_upcomingWithLikes($GroupId,$SystemTypeId,$LikeUserId,$offset=0){
		$GroupId = (int) $GroupId; 
		$SystemTypeId  = (int) $SystemTypeId;
		$LikeUserId  = (int) $LikeUserId;
		$subselect = new Select;
		$adapter = $this->getAdapter();
		$platform = $adapter->getPlatform();
		$quoteId = $platform->quoteIdentifier($LikeUserId);
		$subselect->from('y2m_group_activity')
			->columns(array(new Expression('COUNT(y2m_like.like_id) as likes_count'),'group_activity_id'=>'group_activity_id'))
			->join('y2m_like', 'y2m_like.like_refer_id = y2m_group_activity.group_activity_id',array())
			->join('y2m_system_type', 'y2m_system_type.system_type_id = y2m_like.like_system_type_id',array())
			->where(array('y2m_group_activity.group_activity_group_id' => $GroupId,'y2m_like.like_system_type_id' => $SystemTypeId))
			->group(array('y2m_group_activity.group_activity_id'))
			->order(array('y2m_group_activity.group_activity_added_timestamp ASC'));
		//echo $subselect->getSqlString();die();
		$commentscount_subselect = new Select;
		$commentscount_subselect->from('y2m_group_activity')
			->columns(array(new Expression('COUNT(y2m_comment.comment_id) as comments_count'),'group_activity_id'=>'group_activity_id'))
			->join('y2m_comment', 'y2m_comment.comment_refer_id = y2m_group_activity.group_activity_id',array())
			->join('y2m_system_type', 'y2m_system_type.system_type_id = y2m_comment.comment_system_type_id',array())
			->where(array('y2m_group_activity.group_activity_group_id' => $GroupId,'y2m_comment.comment_system_type_id' => $SystemTypeId))
			->group(array('y2m_group_activity.group_activity_id'))
			->order(array('y2m_group_activity.group_activity_added_timestamp ASC'));
							
		//sub query to check user exist for the specific discussion of the planet liked
		$alias_subselect = new Select;
		$alias_subselect->from('y2m_group_activity')
			->columns(array('group_activity_id'=>'group_activity_id'))
			->join('y2m_like', 'y2m_like.like_refer_id = y2m_group_activity.group_activity_id',array())
			->join('y2m_system_type', 'y2m_system_type.system_type_id = y2m_like.like_system_type_id',array())
			->join('y2m_user', 'y2m_user.user_id = y2m_like.like_by_user_id',array())
			->where(array('y2m_group_activity.group_activity_id' => new Expression('`final`.`group_activity_id`'),'y2m_user.user_id' => $LikeUserId));
		$expression = new Expression(
		  "IF ( EXISTS(" . @$alias_subselect->getSqlString($adapter->getPlatform()) . ") , `final`.`group_activity_id`, 0)"
		);
		
		//sub query to check user spammed for the specific discussion of the planet
		$alias_subspamselect = new Select;
		$alias_subspamselect->from('y2m_group_activity')
			->columns(array('group_activity_id'=>'group_activity_id'))
			->join('y2m_spam', 'y2m_spam.spam_refer_id = y2m_group_activity.group_activity_id',array())
			->join('y2m_system_type', 'y2m_system_type.system_type_id = y2m_spam.spam_system_type_id',array())
			->join('y2m_problem', 'y2m_problem.problem_id = y2m_spam.spam_problem_id',array())
			->join('y2m_user', 'y2m_user.user_id = y2m_spam.spam_report_user_id',array())
			->where(array('y2m_group_activity.group_activity_id' => new Expression('`final`.`group_activity_id`'),'y2m_user.user_id' => $LikeUserId));
		//user query to select picture
		$alias_subuserprofileselect = new Select;
		$alias_subuserprofileselect->from('y2m_group_activity')
			->columns(array('group_activity_id'=>'group_activity_id','user_id' => new Expression('`y2m_user`.`user_id`'),'user_given_name' => new Expression('`y2m_user`.`user_given_name`'),'photo_location'=> new Expression('`y2m_photo`.`photo_location`'),'photo_name'=> new Expression('`y2m_photo`.`photo_name`')))
			->join('y2m_user', 'y2m_user.user_id = y2m_group_activity.group_activity_owner_user_id',array(),'left')
			->join('y2m_photo', 'y2m_photo.photo_id = y2m_user.user_profile_photo_id',array(),'left')
			->where(array('y2m_group_activity.group_activity_group_id' => $GroupId))
			->group(array('y2m_group_activity.group_activity_id'))
			->order(array('y2m_group_activity.group_activity_added_timestamp ASC'));
		
		$expression1 = new Expression(
		  "IF ( EXISTS(" . @$alias_subspamselect->getSqlString($adapter->getPlatform()) . ") , `final`.`group_activity_id`, 0)"
		);
		//main query
		$current_date = date('Y-m-d H:i:s');
		$mainSelect = new Select;
		$mainSelect->from('y2m_group_activity')
			->join(array('temp' => $subselect), 'temp.group_activity_id = y2m_group_activity.group_activity_id',array('likes_count',"user_check"=>$expression,"spam_user_check"=>$expression1),'left')
			->join(array('temp_comment' => $commentscount_subselect), 'temp_comment.group_activity_id = y2m_group_activity.group_activity_id',array('comments_count'),'left')
			->join(array('temp1' => $alias_subuserprofileselect), 'temp1.group_activity_id = y2m_group_activity.group_activity_id',array('photo_location','photo_name','user_id','user_given_name'),'left')
			->join(array('final'=>'y2m_group_activity'), 'final.group_activity_id = y2m_group_activity.group_activity_id','group_activity_id','left')
			->columns(array('group_activity_content'=>'group_activity_content','group_activity_owner_user_id'=>'group_activity_owner_user_id','group_activity_title'=>'group_activity_title','group_activity_location'=>'group_activity_location','group_activity_start_timestamp'=>'group_activity_start_timestamp'))
            ->where(array('final.group_activity_group_id' => $GroupId))			
			->where->greaterThan('y2m_group_activity.group_activity_start_timestamp' , $current_date)			 
			;
			$mainSelect->order(array('y2m_group_activity.group_activity_start_timestamp DESC'));
			$mainSelect->limit(10);
			$mainSelect->offset($offset);
			 
		$statement = $this->adapter->createStatement();
		
		$mainSelect->prepareStatement($this->adapter, $statement);
	//echo $mainSelect->getSqlString();die();
		$resultSet = new ResultSet();
		$resultSet->initialize($statement->execute());	  
		
		return $resultSet;	
	}
	 
	
}
