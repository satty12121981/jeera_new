<?php
return array(
    'controllers' => array(
        'invokables' => array(
            'Notification\Controller\Notification' => 'Notification\Controller\NotificationController',
			'Notification\Controller\UserNotification' => 'Notification\Controller\UserNotificationController',
        ),
    ),

    // The following section is router to route controller
    'router' => array(
        'routes' => array(
            'usernotification' => array(
                'type' => 'Literal',
                'priority' => 1000,
                'options' => array(
                    'route' => '/usernotification',
                    'defaults' => array(
						'__NAMESPACE__' => 'Notification\Controller',
                        'controller' => 'usernotification',
                        'action'     => 'index',
                    ),
                ),
                  'child_routes' => array(
                    'usernotificationspopup' => array(
                        'type' => 'Literal',
                        'options' => array(
                            'route' => '/usernotificationspopup',
                            'defaults' => array(
								'__NAMESPACE__' => 'Notification\Controller',
                                'controller' => 'UserNotification',
                                'action'     => 'usernotificationspopup',
                            ),
                        ),
                    ),
					'usernotificationslist' => array(
                        'type' => 'Literal',
                        'options' => array(
                            'route' => '/usernotificationslist',
                            'defaults' => array(
								'__NAMESPACE__' => 'Notification\Controller',
                                'controller' => 'usernotification',
                                'action'     => 'usernotificationslist',
                            ),
                        ),
                    ),
                ),
			),
		),
    ),

    'view_manager' => array(
        'template_path_stack' => array(
            'notification' => __DIR__ . '/../view',
        ),
    ),
);

